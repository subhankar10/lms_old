<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-01 22:38:41 --> Severity: Warning --> mysqli::__construct(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) /var/www/html/onlineclassroom/application/config/config.php 515
ERROR - 2020-04-01 23:05:52 --> Severity: Warning --> mysqli::__construct(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) /var/www/html/onlineclassroom/application/config/config.php 515
