<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-31 10:40:40 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 294
ERROR - 2019-12-31 10:48:16 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 294
ERROR - 2019-12-31 10:48:19 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 294
ERROR - 2019-12-31 10:54:17 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 294
ERROR - 2019-12-31 10:54:24 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 294
ERROR - 2019-12-31 10:54:26 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 294
ERROR - 2019-12-31 10:56:23 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 294
ERROR - 2019-12-31 10:56:40 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 294
ERROR - 2019-12-31 11:00:47 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 294
ERROR - 2019-12-31 11:02:04 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 294
ERROR - 2019-12-31 11:17:09 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 294
ERROR - 2019-12-31 11:18:44 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 294
ERROR - 2019-12-31 11:18:48 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 294
ERROR - 2019-12-31 12:08:29 --> Could not find the language line "exam_type"
ERROR - 2019-12-31 12:08:29 --> Could not find the language line "exam_type"
ERROR - 2019-12-31 12:23:44 --> Could not find the language line "examtype_select"
ERROR - 2019-12-31 12:23:44 --> Could not find the language line "examtype_pilots"
ERROR - 2019-12-31 12:23:44 --> Could not find the language line "examtype_rampagents"
ERROR - 2019-12-31 12:23:44 --> Could not find the language line "examtype_atcos"
ERROR - 2019-12-31 12:23:44 --> Could not find the language line "examtype_airtechnicians"
ERROR - 2019-12-31 12:23:47 --> Could not find the language line "examtype_select"
ERROR - 2019-12-31 12:23:47 --> Could not find the language line "examtype_pilots"
ERROR - 2019-12-31 12:23:47 --> Could not find the language line "examtype_rampagents"
ERROR - 2019-12-31 12:23:47 --> Could not find the language line "examtype_atcos"
ERROR - 2019-12-31 12:23:47 --> Could not find the language line "examtype_airtechnicians"
ERROR - 2019-12-31 12:27:09 --> Could not find the language line "examcategory_pilots"
ERROR - 2019-12-31 12:41:44 --> Could not find the language line "examcategory_pilots"
ERROR - 2019-12-31 12:42:48 --> Could not find the language line "examcategory_pilots"
ERROR - 2019-12-31 12:43:12 --> Could not find the language line "examcategory_pilots"
ERROR - 2019-12-31 12:44:59 --> Could not find the language line "examcategory_pilots"
ERROR - 2019-12-31 12:50:17 --> Could not find the language line "examcategory_pilots"
ERROR - 2019-12-31 12:50:17 --> Could not find the language line "exam_module"
ERROR - 2019-12-31 12:50:17 --> Could not find the language line "module_english"
ERROR - 2019-12-31 12:50:17 --> Could not find the language line "question_nos"
ERROR - 2019-12-31 12:50:45 --> Could not find the language line "examcategory_pilots"
ERROR - 2019-12-31 12:50:45 --> Could not find the language line "exam_module"
ERROR - 2019-12-31 12:50:45 --> Could not find the language line "module_english"
ERROR - 2019-12-31 12:50:45 --> Could not find the language line "question_nos"
ERROR - 2019-12-31 12:51:35 --> Could not find the language line "examcategory_pilots"
ERROR - 2019-12-31 12:53:50 --> Could not find the language line "examcategory_pilots"
ERROR - 2019-12-31 12:54:13 --> Could not find the language line "examcategory_pilots"
ERROR - 2019-12-31 12:54:47 --> Could not find the language line "examcategory_pilots"
ERROR - 2019-12-31 12:55:18 --> Could not find the language line "examcategory_pilots"
ERROR - 2019-12-31 12:55:32 --> Could not find the language line "examcategory_pilots"
ERROR - 2019-12-31 12:57:29 --> Could not find the language line "examcategory_pilots"
ERROR - 2019-12-31 12:57:39 --> Could not find the language line "examcategory_pilots"
ERROR - 2019-12-31 12:58:06 --> Could not find the language line "examcategory_pilots"
ERROR - 2019-12-31 12:58:17 --> Could not find the language line "examcategory_pilots"
ERROR - 2019-12-31 12:58:55 --> Could not find the language line "examcategory_pilots"
ERROR - 2019-12-31 13:01:56 --> Could not find the language line "examcategory_pilots"
ERROR - 2019-12-31 13:04:15 --> Could not find the language line "examcategory_pilots"
ERROR - 2019-12-31 13:13:56 --> Could not find the language line "examcategory_pilots"
ERROR - 2019-12-31 15:35:07 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 294
ERROR - 2019-12-31 15:53:50 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 294
ERROR - 2019-12-31 16:38:52 --> Query error: Column 'exam_category' cannot be null - Invalid query: INSERT INTO `kams_quiz` (`exam_category`, `exam_type`, `quiz_name`, `description`, `start_date`, `end_date`, `maximum_attempts`, `pass_percentage`, `correct_score`, `incorrect_score`, `view_answer`, `quiz_price`, `show_chart_rank`, `gids`, `question_selection`, `gen_certificate`, `inserted_by`, `inserted_by_name`, `module_english`, `module_general`, `add_date`) VALUES (NULL, '1', 'Australia Quiz New', '<p>Do not use this attribute as a validation tool. File uploads should be validated on the server. Do not use this attribute as a validation tool. File uploads should be validated on the server.</p>', '2020-01-07', '2020-01-13', '10', '50', '1', '0', '1', '0', '1', '1', '0', '0', '1', 'Admin Admin', '9', '7', '2019-12-31 04:38:52')
ERROR - 2019-12-31 16:50:42 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equiz/application/models/Quiz_model.php 167
ERROR - 2019-12-31 16:50:42 --> Query error: Column 'exam_category' cannot be null - Invalid query: INSERT INTO `kams_quiz` (`exam_category`, `exam_type`, `quiz_name`, `description`, `start_date`, `end_date`, `maximum_attempts`, `pass_percentage`, `correct_score`, `incorrect_score`, `view_answer`, `quiz_price`, `show_chart_rank`, `gids`, `question_selection`, `gen_certificate`, `inserted_by`, `inserted_by_name`, `add_date`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Admin Admin', '2019-12-31 04:50:42')
ERROR - 2019-12-31 16:52:41 --> Query error: Column 'exam_category' cannot be null - Invalid query: INSERT INTO `kams_quiz` (`exam_category`, `exam_type`, `quiz_name`, `description`, `start_date`, `end_date`, `maximum_attempts`, `pass_percentage`, `correct_score`, `incorrect_score`, `view_answer`, `quiz_price`, `show_chart_rank`, `gids`, `question_selection`, `gen_certificate`, `inserted_by`, `inserted_by_name`, `module_english`, `module_general`, `add_date`) VALUES (NULL, '1', 'Australia Quiz New', '<div class=\"alert alert-success\">Quiz created successfully! Now add some question into the quiz. Quiz created successfully! Now add some question into the quiz.</div>', '2020-01-03', '2020-01-13', '10', '50', '1', '0', '1', '0', '1', '1', '0', '0', '1', 'Admin Admin', '9', '7', '2019-12-31 04:52:41')
ERROR - 2019-12-31 16:54:59 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equiz/application/models/Quiz_model.php 167
ERROR - 2019-12-31 16:54:59 --> Query error: Column 'exam_category' cannot be null - Invalid query: INSERT INTO `kams_quiz` (`exam_category`, `exam_type`, `quiz_name`, `description`, `start_date`, `end_date`, `maximum_attempts`, `pass_percentage`, `correct_score`, `incorrect_score`, `view_answer`, `quiz_price`, `show_chart_rank`, `gids`, `question_selection`, `gen_certificate`, `inserted_by`, `inserted_by_name`, `add_date`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Admin Admin', '2019-12-31 04:54:59')
