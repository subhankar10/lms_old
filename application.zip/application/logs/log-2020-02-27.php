<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-27 10:43:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: select * from kams_students_exam_subscription where qid in () 
ERROR - 2020-02-27 10:43:27 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-27 10:43:27 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-27 10:43:27 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-27 10:43:27 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-27 10:43:29 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-27 10:43:29 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-27 10:43:29 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-27 10:43:29 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-27 11:02:24 --> Severity: Warning --> include(/var/www/html/equizAdmindesign/application/views/mockexam_result_list.php): failed to open stream: Permission denied /var/www/html/equizAdmindesign/system/core/Loader.php 968
ERROR - 2020-02-27 11:02:24 --> Severity: Warning --> include(): Failed opening '/var/www/html/equizAdmindesign/application/views/mockexam_result_list.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/equizAdmindesign/system/core/Loader.php 968
ERROR - 2020-02-27 11:15:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/new_agency.php 73
ERROR - 2020-02-27 11:16:06 --> Severity: Warning --> include(/var/www/html/equizAdmindesign/application/views/mockexam_result_list.php): failed to open stream: Permission denied /var/www/html/equizAdmindesign/system/core/Loader.php 968
ERROR - 2020-02-27 11:16:06 --> Severity: Warning --> include(): Failed opening '/var/www/html/equizAdmindesign/application/views/mockexam_result_list.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/equizAdmindesign/system/core/Loader.php 968
ERROR - 2020-02-27 11:19:02 --> Severity: Warning --> include(/var/www/html/equizAdmindesign/application/views/mockexam_result_list.php): failed to open stream: Permission denied /var/www/html/equizAdmindesign/system/core/Loader.php 968
ERROR - 2020-02-27 11:19:02 --> Severity: Warning --> include(): Failed opening '/var/www/html/equizAdmindesign/application/views/mockexam_result_list.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/equizAdmindesign/system/core/Loader.php 968
ERROR - 2020-02-27 12:27:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 184
ERROR - 2020-02-27 13:17:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/new_agency.php 73
ERROR - 2020-02-27 13:19:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/new_agency.php 73
ERROR - 2020-02-27 13:20:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/new_agency.php 73
ERROR - 2020-02-27 13:20:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/new_agency.php 73
ERROR - 2020-02-27 13:21:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/new_agency.php 73
ERROR - 2020-02-27 13:21:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/new_agency.php 73
ERROR - 2020-02-27 15:58:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 184
ERROR - 2020-02-27 15:58:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/new_agency.php 73
ERROR - 2020-02-27 16:02:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 184
ERROR - 2020-02-27 16:02:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/new_agency.php 73
ERROR - 2020-02-27 16:10:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/new_agency.php 73
ERROR - 2020-02-27 16:15:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/new_agency.php 73
ERROR - 2020-02-27 16:19:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/new_agency.php 73
ERROR - 2020-02-27 16:21:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/new_agency.php 73
ERROR - 2020-02-27 16:22:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 184
ERROR - 2020-02-27 16:22:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 184
ERROR - 2020-02-27 16:22:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/new_agency.php 73
ERROR - 2020-02-27 16:33:05 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmindesign/application/views/view_result.php 400
ERROR - 2020-02-27 16:33:05 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmindesign/application/views/view_result.php 403
ERROR - 2020-02-27 16:33:05 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmindesign/application/views/view_result.php 409
ERROR - 2020-02-27 16:34:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/new_agency.php 73
ERROR - 2020-02-27 16:36:07 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-27 16:36:07 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-27 16:36:07 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-27 16:36:07 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-27 16:36:10 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-27 16:36:10 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-27 16:36:10 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-27 16:36:10 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-27 16:36:12 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-27 16:36:12 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-27 16:36:12 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-27 16:36:12 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-27 16:38:02 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-27 16:38:02 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-27 16:38:02 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-27 16:38:02 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-27 16:41:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/new_agency.php 73
ERROR - 2020-02-27 16:42:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/new_agency.php 73
ERROR - 2020-02-27 16:43:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/new_agency.php 73
ERROR - 2020-02-27 18:52:53 --> Severity: Warning --> Use of undefined constant tableEvents - assumed 'tableEvents' (this will throw an Error in a future version of PHP) /var/www/html/equizAdmindesign/application/views/student_subscription.php 319
ERROR - 2020-02-27 18:52:53 --> Severity: Warning --> Use of undefined constant i - assumed 'i' (this will throw an Error in a future version of PHP) /var/www/html/equizAdmindesign/application/views/student_subscription.php 319
ERROR - 2020-02-27 18:52:53 --> Severity: Warning --> Illegal string offset 'i' /var/www/html/equizAdmindesign/application/views/student_subscription.php 319
ERROR - 2020-02-27 18:52:53 --> Severity: Warning --> Illegal string offset 'start' /var/www/html/equizAdmindesign/application/views/student_subscription.php 319
ERROR - 2020-02-27 18:53:58 --> Severity: Warning --> Use of undefined constant tableEvents - assumed 'tableEvents' (this will throw an Error in a future version of PHP) /var/www/html/equizAdmindesign/application/views/student_subscription.php 319
ERROR - 2020-02-27 18:53:58 --> Severity: Warning --> Use of undefined constant i - assumed 'i' (this will throw an Error in a future version of PHP) /var/www/html/equizAdmindesign/application/views/student_subscription.php 319
ERROR - 2020-02-27 18:53:58 --> Severity: Warning --> Illegal string offset 'i' /var/www/html/equizAdmindesign/application/views/student_subscription.php 319
ERROR - 2020-02-27 18:53:58 --> Severity: Warning --> Illegal string offset 'start' /var/www/html/equizAdmindesign/application/views/student_subscription.php 319
ERROR - 2020-02-27 18:53:58 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/views/student_subscription.php 319
ERROR - 2020-02-27 18:53:58 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/views/student_subscription.php 319
ERROR - 2020-02-27 18:53:58 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/views/student_subscription.php 319
