<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-02 11:41:21 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/equiz/system/database/DB_driver.php 1471
ERROR - 2019-12-02 11:41:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' 'wt5twe', 'w4t4t', '25452', 'wt@fetetg.f', NULL)' at line 1 - Invalid query: INSERT INTO `kams_users` (`company`, `license_type`, `license_number`, `license_country`, `vat`, `address`, `postal_code`, `city`, `country`, `dob`, `payment_method`, `first_name`, `last_name`, `contact_no`, `email`, `password`) VALUES ('w34e4t', 'w34e4t', 'w34e4t', 'w34e4t', '254wdsfs', 'asfsf', 'atw4535', 'atetaet', 'age', NULL, , 'wt5twe', 'w4t4t', '25452', 'wt@fetetg.f', NULL)
ERROR - 2019-12-02 11:44:14 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/equiz/system/database/DB_driver.php 1471
ERROR - 2019-12-02 11:44:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' 'wt5twe', 'w4t4t', '25452', 'wt@fetetg.f', NULL)' at line 1 - Invalid query: INSERT INTO `kams_users` (`company`, `license_type`, `license_number`, `license_country`, `vat`, `address`, `postal_code`, `city`, `country`, `dob`, `payment_method`, `first_name`, `last_name`, `contact_no`, `email`, `password`) VALUES ('w34e4t', 'w34e4t', 'w34e4t', 'w34e4t', '254wdsfs', 'asfsf', 'atw4535', 'atetaet', 'age', NULL, , 'wt5twe', 'w4t4t', '25452', 'wt@fetetg.f', NULL)
ERROR - 2019-12-02 11:59:00 --> Query error: Column 'password' cannot be null - Invalid query: INSERT INTO `kams_users` (`company`, `license_type`, `license_number`, `license_country`, `vat`, `address`, `postal_code`, `city`, `country`, `dob`, `payment_method`, `first_name`, `last_name`, `contact_no`, `email`, `password`) VALUES ('w34e4t', NULL, NULL, NULL, '254wdsfs', 'asfsf', NULL, 'atetaet', 'age', NULL, NULL, NULL, NULL, NULL, 'wt@fetetg.f', NULL)
ERROR - 2019-12-02 12:21:42 --> Query error: Column 'password' cannot be null - Invalid query: INSERT INTO `kams_users` (`company`, `license_type`, `license_number`, `license_country`, `vat`, `address`, `postal_code`, `city`, `country`, `dob`, `payment_method`, `first_name`, `last_name`, `contact_no`, `email`, `password`) VALUES ('w34e4t', NULL, NULL, NULL, '254wdsfs', 'asfsf', NULL, 'atetaet', 'age', NULL, NULL, NULL, NULL, NULL, 'wt@fetetg.f', NULL)
ERROR - 2019-12-02 12:22:25 --> Query error: Column 'password' cannot be null - Invalid query: INSERT INTO `kams_users` (`company`, `license_type`, `license_number`, `license_country`, `vat`, `address`, `postal_code`, `city`, `country`, `dob`, `payment_method`, `first_name`, `last_name`, `contact_no`, `email`, `password`) VALUES ('w34e4t', NULL, NULL, NULL, '254wdsfs', 'asfsf', NULL, 'atetaet', 'age', NULL, NULL, NULL, NULL, NULL, 'wt@fetetg.f', NULL)
ERROR - 2019-12-02 15:25:38 --> Language file contains no data: language/english/masterdata_lang.php
ERROR - 2019-12-02 15:26:07 --> Language file contains no data: language/english/masterdata_lang.php
ERROR - 2019-12-02 15:26:07 --> Severity: error --> Exception: Too few arguments to function CI_Config::item(), 0 passed in /var/www/html/equiz/application/controllers/Api.php on line 57 and at least 1 expected /var/www/html/equiz/system/core/Config.php 197
ERROR - 2019-12-02 15:28:36 --> Language file contains no data: language/english/masterdata_lang.php
ERROR - 2019-12-02 15:28:36 --> Could not find the language line "license_type1"
ERROR - 2019-12-02 15:28:51 --> Language file contains no data: language/english/masterdata_lang.php
ERROR - 2019-12-02 15:30:04 --> Severity: error --> Exception: Call to a member function line() on null /var/www/html/equiz/application/controllers/Api.php 57
ERROR - 2019-12-02 15:30:11 --> Language file contains no data: language/english/masterdata_lang.php
ERROR - 2019-12-02 15:30:11 --> Severity: error --> Exception: Call to a member function line() on null /var/www/html/equiz/application/controllers/Api.php 57
ERROR - 2019-12-02 15:30:47 --> Language file contains no data: language/english/masterdata_lang.php
ERROR - 2019-12-02 15:30:47 --> Severity: error --> Exception: Call to a member function line() on null /var/www/html/equiz/application/controllers/Api.php 57
ERROR - 2019-12-02 15:30:48 --> Language file contains no data: language/english/masterdata_lang.php
ERROR - 2019-12-02 15:30:48 --> Severity: error --> Exception: Call to a member function line() on null /var/www/html/equiz/application/controllers/Api.php 57
ERROR - 2019-12-02 15:31:34 --> Severity: error --> Exception: Call to a member function line() on null /var/www/html/equiz/application/controllers/Api.php 57
ERROR - 2019-12-02 15:31:35 --> Severity: error --> Exception: Call to a member function line() on null /var/www/html/equiz/application/controllers/Api.php 57
ERROR - 2019-12-02 15:31:46 --> Severity: error --> Exception: Call to a member function line() on null /var/www/html/equiz/application/controllers/Api.php 57
ERROR - 2019-12-02 15:32:37 --> Language file contains no data: language/english/masterdata_lang.php
ERROR - 2019-12-02 15:32:37 --> Severity: error --> Exception: Call to a member function line() on null /var/www/html/equiz/application/controllers/Api.php 57
ERROR - 2019-12-02 15:33:02 --> Language file contains no data: language/english/masterdata_lang.php
ERROR - 2019-12-02 15:33:37 --> Language file contains no data: language/english/masterdata_lang.php
ERROR - 2019-12-02 15:33:37 --> Could not find the language line "license_type1"
ERROR - 2019-12-02 15:33:52 --> Language file contains no data: language/english/masterdata_lang.php
ERROR - 2019-12-02 15:33:52 --> Could not find the language line "license_type1"
