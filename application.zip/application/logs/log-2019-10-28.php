<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-28 12:45:49 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 237
ERROR - 2019-10-28 13:07:42 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 237
ERROR - 2019-10-28 13:09:32 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equiz/application/models/Quiz_model.php 193
ERROR - 2019-10-28 13:10:34 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equiz/application/models/Quiz_model.php 193
ERROR - 2019-10-28 13:10:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/models/Quiz_model.php 878
ERROR - 2019-10-28 13:11:17 --> Could not find the language line "hello"
ERROR - 2019-10-28 13:11:17 --> Could not find the language line "user_id"
ERROR - 2019-10-28 13:11:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equiz/application/views/view_result.php 356
ERROR - 2019-10-28 13:13:36 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equiz/application/models/Quiz_model.php 193
ERROR - 2019-10-28 13:14:20 --> Could not find the language line "hello"
ERROR - 2019-10-28 13:14:20 --> Could not find the language line "user_id"
ERROR - 2019-10-28 13:14:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equiz/application/views/view_result.php 356
ERROR - 2019-10-28 13:17:33 --> Could not find the language line "hello"
ERROR - 2019-10-28 13:17:33 --> Could not find the language line "user_id"
ERROR - 2019-10-28 13:17:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equiz/application/views/view_result.php 356
ERROR - 2019-10-28 15:08:26 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 237
ERROR - 2019-10-28 15:15:39 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 237
ERROR - 2019-10-28 16:03:32 --> Severity: error --> Exception: Call to undefined method Qbank_model::insert_question_6() /var/www/html/equiz/application/controllers/Qbank.php 330
ERROR - 2019-10-28 17:42:57 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 237
