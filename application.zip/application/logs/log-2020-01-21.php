<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-21 11:20:46 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-01-21 11:42:39 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-01-21 13:45:18 --> Severity: error --> Exception: Unable to locate the model you have specified: Scheduletime_model /var/www/html/equizAdmin/system/core/Loader.php 348
ERROR - 2020-01-21 14:54:09 --> Severity: error --> Exception: Unable to locate the model you have specified: Scheduletime_model /var/www/html/equizAdmin/system/core/Loader.php 348
ERROR - 2020-01-21 14:54:11 --> Severity: error --> Exception: Unable to locate the model you have specified: Scheduletime_model /var/www/html/equizAdmin/system/core/Loader.php 348
ERROR - 2020-01-21 16:39:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/profile.php 231
ERROR - 2020-01-21 16:39:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/profile.php 320
ERROR - 2020-01-21 19:11:37 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/equizAdmin/application/controllers/Schedule_time.php 55
ERROR - 2020-01-21 19:11:37 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/equizAdmin/application/controllers/Schedule_time.php 55
ERROR - 2020-01-21 19:12:09 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/equizAdmin/application/controllers/Schedule_time.php 55
ERROR - 2020-01-21 19:12:09 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/equizAdmin/application/controllers/Schedule_time.php 55
ERROR - 2020-01-21 19:26:17 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
