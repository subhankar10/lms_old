<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-22 12:39:39 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 263
ERROR - 2019-12-22 12:59:32 --> Could not find the language line "action"
ERROR - 2019-12-22 13:00:14 --> Could not find the language line "action"
ERROR - 2019-12-22 13:20:39 --> Could not find the language line "action"
ERROR - 2019-12-22 13:24:33 --> Could not find the language line "action"
ERROR - 2019-12-22 13:31:13 --> Could not find the language line "action"
ERROR - 2019-12-22 13:31:32 --> Could not find the language line "action"
ERROR - 2019-12-22 13:34:02 --> Could not find the language line "action"
ERROR - 2019-12-22 13:35:13 --> Could not find the language line "action"
ERROR - 2019-12-22 13:35:35 --> Could not find the language line "action"
ERROR - 2019-12-22 13:36:03 --> Could not find the language line "action"
ERROR - 2019-12-22 13:37:58 --> Could not find the language line "action"
ERROR - 2019-12-22 13:38:51 --> Could not find the language line "action"
ERROR - 2019-12-22 13:42:14 --> Could not find the language line "action"
ERROR - 2019-12-22 13:42:17 --> Could not find the language line "action"
ERROR - 2019-12-22 13:42:20 --> Could not find the language line "action"
ERROR - 2019-12-22 13:43:43 --> Could not find the language line "action"
ERROR - 2019-12-22 14:29:26 --> Could not find the language line "action"
ERROR - 2019-12-22 14:29:34 --> Could not find the language line "action"
ERROR - 2019-12-22 14:30:36 --> Could not find the language line "action"
ERROR - 2019-12-22 14:32:22 --> Could not find the language line "action"
ERROR - 2019-12-22 14:33:53 --> Could not find the language line "action"
ERROR - 2019-12-22 14:45:54 --> Could not find the language line "action"
ERROR - 2019-12-22 14:56:53 --> Could not find the language line "action"
ERROR - 2019-12-22 14:57:08 --> Could not find the language line "action"
ERROR - 2019-12-22 14:57:10 --> Could not find the language line "action"
ERROR - 2019-12-22 14:57:48 --> Could not find the language line "action"
ERROR - 2019-12-22 15:25:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 110
ERROR - 2019-12-22 15:25:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 199
ERROR - 2019-12-22 16:05:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 122
ERROR - 2019-12-22 16:05:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 211
ERROR - 2019-12-22 16:06:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 122
ERROR - 2019-12-22 16:06:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 211
ERROR - 2019-12-22 16:09:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 124
ERROR - 2019-12-22 16:09:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 213
ERROR - 2019-12-22 16:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 124
ERROR - 2019-12-22 16:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 213
ERROR - 2019-12-22 16:15:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 124
ERROR - 2019-12-22 16:15:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 213
ERROR - 2019-12-22 16:15:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 124
ERROR - 2019-12-22 16:15:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 213
ERROR - 2019-12-22 17:04:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 124
ERROR - 2019-12-22 17:04:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 213
ERROR - 2019-12-22 17:06:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 124
ERROR - 2019-12-22 17:06:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 213
ERROR - 2019-12-22 17:07:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 124
ERROR - 2019-12-22 17:07:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 213
ERROR - 2019-12-22 17:08:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 124
ERROR - 2019-12-22 17:08:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 213
ERROR - 2019-12-22 17:09:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 124
ERROR - 2019-12-22 17:09:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 213
ERROR - 2019-12-22 17:10:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 124
ERROR - 2019-12-22 17:10:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 213
ERROR - 2019-12-22 17:10:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 126
ERROR - 2019-12-22 17:10:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 215
ERROR - 2019-12-22 17:11:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 127
ERROR - 2019-12-22 17:11:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 216
ERROR - 2019-12-22 17:11:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 124
ERROR - 2019-12-22 17:11:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 213
ERROR - 2019-12-22 17:11:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 124
ERROR - 2019-12-22 17:11:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 213
ERROR - 2019-12-22 17:29:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 136
ERROR - 2019-12-22 17:29:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 225
ERROR - 2019-12-22 17:29:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 136
ERROR - 2019-12-22 17:29:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 225
ERROR - 2019-12-22 17:30:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 131
ERROR - 2019-12-22 17:30:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 220
ERROR - 2019-12-22 17:30:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 136
ERROR - 2019-12-22 17:30:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 225
ERROR - 2019-12-22 17:32:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 136
ERROR - 2019-12-22 17:32:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 225
ERROR - 2019-12-22 17:32:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 136
ERROR - 2019-12-22 17:32:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 225
ERROR - 2019-12-22 17:34:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 136
ERROR - 2019-12-22 17:34:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 225
ERROR - 2019-12-22 17:34:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 136
ERROR - 2019-12-22 17:34:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 225
ERROR - 2019-12-22 17:35:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 136
ERROR - 2019-12-22 17:35:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 225
ERROR - 2019-12-22 17:41:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 144
ERROR - 2019-12-22 17:41:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 233
ERROR - 2019-12-22 17:44:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 156
ERROR - 2019-12-22 17:44:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 245
ERROR - 2019-12-22 17:45:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 156
ERROR - 2019-12-22 17:45:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 245
ERROR - 2019-12-22 17:46:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 156
ERROR - 2019-12-22 17:46:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 245
ERROR - 2019-12-22 17:46:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 156
ERROR - 2019-12-22 17:46:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 245
ERROR - 2019-12-22 17:46:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 156
ERROR - 2019-12-22 17:46:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 245
ERROR - 2019-12-22 17:46:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 156
ERROR - 2019-12-22 17:46:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 245
ERROR - 2019-12-22 17:47:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 156
ERROR - 2019-12-22 17:47:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 245
ERROR - 2019-12-22 17:48:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 156
ERROR - 2019-12-22 17:48:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 245
ERROR - 2019-12-22 17:49:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 162
ERROR - 2019-12-22 17:49:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 251
ERROR - 2019-12-22 17:49:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 162
ERROR - 2019-12-22 17:49:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 251
ERROR - 2019-12-22 17:49:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 162
ERROR - 2019-12-22 17:49:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 251
ERROR - 2019-12-22 17:49:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 162
ERROR - 2019-12-22 17:49:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 251
ERROR - 2019-12-22 17:50:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 162
ERROR - 2019-12-22 17:50:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 251
ERROR - 2019-12-22 17:50:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 162
ERROR - 2019-12-22 17:50:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 251
ERROR - 2019-12-22 17:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 162
ERROR - 2019-12-22 17:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 251
ERROR - 2019-12-22 17:52:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 162
ERROR - 2019-12-22 17:52:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 251
ERROR - 2019-12-22 17:52:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 163
ERROR - 2019-12-22 17:52:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 252
ERROR - 2019-12-22 17:52:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 163
ERROR - 2019-12-22 17:52:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 252
ERROR - 2019-12-22 17:53:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 163
ERROR - 2019-12-22 17:53:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 252
ERROR - 2019-12-22 17:53:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 162
ERROR - 2019-12-22 17:53:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 251
