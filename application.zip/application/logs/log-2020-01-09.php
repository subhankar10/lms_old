<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-09 15:55:45 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-01-09 15:56:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/new_question_1.php 28
ERROR - 2020-01-09 15:56:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/new_question_1.php 41
ERROR - 2020-01-09 15:56:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/new_question_1.php 54
ERROR - 2020-01-09 16:31:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/new_question_1.php 28
ERROR - 2020-01-09 16:31:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/new_question_1.php 41
ERROR - 2020-01-09 16:31:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/new_question_1.php 54
ERROR - 2020-01-09 16:32:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/new_question_1.php 28
ERROR - 2020-01-09 16:32:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/new_question_1.php 41
ERROR - 2020-01-09 16:32:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/new_question_1.php 54
ERROR - 2020-01-09 17:55:26 --> Query error: Unknown column 'qtype' in 'field list' - Invalid query: UPDATE `kams_qbank` SET `paragraph` = NULL, `qtype` = 1, `question` = '2+10 = ?', `description` = 'Sum of two numbers', `question_type` = 'Multiple Choice Single Answer', `cid` = '2', `lid` = '1', `question_category` = '1', `test_type` = '1', `question_module` = '1', `time` = '30'
WHERE `qid` = '137'
ERROR - 2020-01-09 18:03:09 --> Query error: Unknown column 'qtype' in 'field list' - Invalid query: UPDATE `kams_qbank` SET `paragraph` = NULL, `qtype` = 1, `question` = '2+10 = ?', `description` = 'Sum of two numbers', `question_type` = 'Multiple Choice Single Answer', `cid` = '2', `lid` = '1', `question_category` = '1', `test_type` = '1', `question_module` = '1', `time` = '30'
WHERE `qid` = '137'
ERROR - 2020-01-09 18:07:31 --> Query error: Unknown column 'qtype' in 'field list' - Invalid query: UPDATE `kams_qbank` SET `paragraph` = NULL, `qtype` = 1, `question` = '2+10 = ?', `description` = 'Sum of two numbers', `question_type` = 'Multiple Choice Single Answer', `cid` = '2', `lid` = '1', `question_category` = '1', `test_type` = '1', `question_module` = '2', `time` = '30'
WHERE `qid` = '137'
