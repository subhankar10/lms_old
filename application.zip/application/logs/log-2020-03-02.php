<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-02 13:11:44 --> Query error: Unknown column 'q.quiz_id' in 'where clause' - Invalid query: SELECT `q`.`quiz_name`, `q`.`quiz_price`, `s`.*, CONCAT(ue.first_name, " ", ue.last_name) AS examiner_name, CONCAT(us.first_name, " ", us.last_name) AS scorer_name
FROM `kams_students_exam_subscription` `s`
LEFT JOIN `kams_quiz` `q` ON `q`.`quid` = `s`.`quiz_id`
LEFT JOIN `kams_users` `ue` ON `ue`.`uid` = `s`.`examiner_id`
LEFT JOIN `kams_users` `us` ON `us`.`uid` = `s`.`scorer_id`
WHERE `q`.`quiz_id` = '3'
ERROR - 2020-03-02 13:11:44 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmindesign/application/controllers/Student_subscriptionexam.php 84
ERROR - 2020-03-02 13:16:40 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-02 13:16:40 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-02 13:16:40 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-02 13:16:40 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-02 13:16:46 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-02 13:16:46 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-02 13:16:46 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-02 13:16:46 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-02 13:16:47 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-02 13:16:47 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-02 13:16:47 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-02 13:16:47 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
