<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-12 17:52:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/subject/subjectList.php 174
ERROR - 2020-04-12 17:53:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 215
ERROR - 2020-04-12 17:53:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 215
ERROR - 2020-04-12 17:53:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 215
ERROR - 2020-04-12 17:54:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 215
ERROR - 2020-04-12 17:56:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 215
ERROR - 2020-04-12 17:57:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/models/User_model.php 422
ERROR - 2020-04-12 17:59:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/userupcomingliveclassList.php 206
ERROR - 2020-04-12 17:59:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 215
ERROR - 2020-04-12 18:34:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/examiner_list.php 204
ERROR - 2020-04-12 18:35:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/examiner_list.php 204
ERROR - 2020-04-12 18:35:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 215
ERROR - 2020-04-12 18:35:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/examiner_list.php 204
ERROR - 2020-04-12 18:37:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/userupcomingliveclassList.php 206
