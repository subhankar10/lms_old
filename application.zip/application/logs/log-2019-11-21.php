<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-21 09:58:15 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 237
ERROR - 2019-11-21 12:01:24 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equiz/application/models/Quiz_model.php 204
ERROR - 2019-11-21 12:01:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/models/Quiz_model.php 254
ERROR - 2019-11-21 12:12:26 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equiz/application/models/Quiz_model.php 204
ERROR - 2019-11-21 12:12:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/models/Quiz_model.php 254
ERROR - 2019-11-21 13:14:50 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 237
