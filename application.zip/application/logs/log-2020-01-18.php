<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-18 10:09:36 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-01-18 10:36:09 --> Could not find the language line "cotact_no"
ERROR - 2020-01-18 11:38:58 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmin/application/controllers/Examiner.php 122
ERROR - 2020-01-18 11:53:14 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmin/application/controllers/Examiner.php 122
ERROR - 2020-01-18 11:53:17 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmin/application/controllers/Examiner.php 122
ERROR - 2020-01-18 11:53:27 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmin/application/controllers/Examiner.php 122
ERROR - 2020-01-18 12:05:01 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmin/application/controllers/Examiner.php 122
ERROR - 2020-01-18 12:10:53 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmin/application/controllers/Examiner.php 122
ERROR - 2020-01-18 12:11:39 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmin/application/controllers/Examiner.php 122
ERROR - 2020-01-18 12:11:52 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmin/application/controllers/Examiner.php 122
ERROR - 2020-01-18 12:29:01 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmin/application/controllers/Examiner.php 123
ERROR - 2020-01-18 12:29:11 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmin/application/controllers/Examiner.php 123
ERROR - 2020-01-18 12:29:46 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmin/application/controllers/Examiner.php 123
ERROR - 2020-01-18 16:12:31 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-01-18 16:21:00 --> Could not find the language line "hello"
ERROR - 2020-01-18 16:21:00 --> Could not find the language line "user_id"
ERROR - 2020-01-18 16:21:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 16:21:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 782
ERROR - 2020-01-18 16:21:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1085
ERROR - 2020-01-18 16:29:32 --> Could not find the language line "hello"
ERROR - 2020-01-18 16:29:32 --> Could not find the language line "user_id"
ERROR - 2020-01-18 16:29:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 324
ERROR - 2020-01-18 16:29:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 779
ERROR - 2020-01-18 16:29:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1082
ERROR - 2020-01-18 16:45:09 --> Could not find the language line "hello"
ERROR - 2020-01-18 16:45:09 --> Could not find the language line "user_id"
ERROR - 2020-01-18 16:45:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 16:45:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 777
ERROR - 2020-01-18 16:45:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1080
ERROR - 2020-01-18 17:00:50 --> Severity: Warning --> require_once(/var/www/html/equizAdmin/application/controllers/Api.php): failed to open stream: Permission denied /var/www/html/equizAdmin/system/core/CodeIgniter.php 411
ERROR - 2020-01-18 17:00:50 --> Severity: Compile Error --> require_once(): Failed opening required '/var/www/html/equizAdmin/application/controllers/Api.php' (include_path='.:/usr/share/php') /var/www/html/equizAdmin/system/core/CodeIgniter.php 411
ERROR - 2020-01-18 17:01:07 --> Severity: Warning --> require_once(/var/www/html/equizAdmin/application/controllers/Api.php): failed to open stream: Permission denied /var/www/html/equizAdmin/system/core/CodeIgniter.php 411
ERROR - 2020-01-18 17:01:07 --> Severity: Compile Error --> require_once(): Failed opening required '/var/www/html/equizAdmin/application/controllers/Api.php' (include_path='.:/usr/share/php') /var/www/html/equizAdmin/system/core/CodeIgniter.php 411
ERROR - 2020-01-18 17:08:28 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 17:08:28 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 17:08:28 --> Could not find the language line "hello"
ERROR - 2020-01-18 17:08:28 --> Could not find the language line "user_id"
ERROR - 2020-01-18 17:08:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 17:08:28 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 17:08:28 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 17:08:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 796
ERROR - 2020-01-18 17:08:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1099
ERROR - 2020-01-18 17:19:40 --> Could not find the language line "hello"
ERROR - 2020-01-18 17:19:40 --> Could not find the language line "user_id"
ERROR - 2020-01-18 17:19:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 17:19:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 795
ERROR - 2020-01-18 17:19:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1098
ERROR - 2020-01-18 17:33:32 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 17:33:32 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 17:33:32 --> Could not find the language line "hello"
ERROR - 2020-01-18 17:33:32 --> Could not find the language line "user_id"
ERROR - 2020-01-18 17:33:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 17:33:32 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 17:33:32 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 17:33:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 795
ERROR - 2020-01-18 17:33:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1098
ERROR - 2020-01-18 17:34:40 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 17:34:40 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 17:34:40 --> Could not find the language line "hello"
ERROR - 2020-01-18 17:34:40 --> Could not find the language line "user_id"
ERROR - 2020-01-18 17:34:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 17:34:40 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 17:34:40 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 17:34:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 795
ERROR - 2020-01-18 17:34:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1098
ERROR - 2020-01-18 17:38:39 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 17:38:39 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 17:38:39 --> Could not find the language line "hello"
ERROR - 2020-01-18 17:38:39 --> Could not find the language line "user_id"
ERROR - 2020-01-18 17:38:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 17:38:39 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 17:38:39 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 17:38:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 795
ERROR - 2020-01-18 17:38:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1098
ERROR - 2020-01-18 17:42:54 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 17:42:54 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 17:42:54 --> Could not find the language line "hello"
ERROR - 2020-01-18 17:42:54 --> Could not find the language line "user_id"
ERROR - 2020-01-18 17:42:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 17:42:54 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 17:42:54 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 17:42:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 797
ERROR - 2020-01-18 17:42:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1100
ERROR - 2020-01-18 17:43:49 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 17:43:49 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 17:43:49 --> Could not find the language line "hello"
ERROR - 2020-01-18 17:43:49 --> Could not find the language line "user_id"
ERROR - 2020-01-18 17:43:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 17:43:49 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 17:43:49 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 17:43:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 797
ERROR - 2020-01-18 17:43:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1100
ERROR - 2020-01-18 17:44:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 17:44:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 17:44:04 --> Could not find the language line "hello"
ERROR - 2020-01-18 17:44:04 --> Could not find the language line "user_id"
ERROR - 2020-01-18 17:44:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 17:44:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 17:44:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 17:44:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 797
ERROR - 2020-01-18 17:44:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1100
ERROR - 2020-01-18 17:45:32 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 17:45:32 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 17:45:32 --> Could not find the language line "hello"
ERROR - 2020-01-18 17:45:32 --> Could not find the language line "user_id"
ERROR - 2020-01-18 17:45:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 17:45:32 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 17:45:32 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 17:45:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 797
ERROR - 2020-01-18 17:45:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1100
ERROR - 2020-01-18 17:46:36 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 17:46:36 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 17:46:36 --> Could not find the language line "hello"
ERROR - 2020-01-18 17:46:36 --> Could not find the language line "user_id"
ERROR - 2020-01-18 17:46:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 17:46:36 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 17:46:36 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 17:46:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 797
ERROR - 2020-01-18 17:46:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1100
ERROR - 2020-01-18 17:48:34 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 17:48:34 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 17:48:34 --> Could not find the language line "hello"
ERROR - 2020-01-18 17:48:34 --> Could not find the language line "user_id"
ERROR - 2020-01-18 17:48:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 17:48:34 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 17:48:34 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 17:48:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 798
ERROR - 2020-01-18 17:48:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1101
ERROR - 2020-01-18 17:49:26 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 17:49:26 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 17:49:26 --> Could not find the language line "hello"
ERROR - 2020-01-18 17:49:26 --> Could not find the language line "user_id"
ERROR - 2020-01-18 17:49:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 17:49:26 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 17:49:26 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 17:49:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 799
ERROR - 2020-01-18 17:49:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1102
ERROR - 2020-01-18 17:49:48 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 17:49:48 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 17:49:48 --> Could not find the language line "hello"
ERROR - 2020-01-18 17:49:48 --> Could not find the language line "user_id"
ERROR - 2020-01-18 17:49:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 17:49:48 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 17:49:48 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 17:49:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 800
ERROR - 2020-01-18 17:49:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1103
ERROR - 2020-01-18 17:50:36 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 17:50:36 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 17:50:36 --> Could not find the language line "hello"
ERROR - 2020-01-18 17:50:36 --> Could not find the language line "user_id"
ERROR - 2020-01-18 17:50:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 17:50:36 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 17:50:36 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 17:50:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 799
ERROR - 2020-01-18 17:50:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1102
ERROR - 2020-01-18 17:53:03 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 17:53:03 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 17:53:03 --> Could not find the language line "hello"
ERROR - 2020-01-18 17:53:03 --> Could not find the language line "user_id"
ERROR - 2020-01-18 17:53:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 17:53:03 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 17:53:03 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 17:53:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 799
ERROR - 2020-01-18 17:53:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1102
ERROR - 2020-01-18 17:53:17 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 17:53:17 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 17:53:17 --> Could not find the language line "hello"
ERROR - 2020-01-18 17:53:17 --> Could not find the language line "user_id"
ERROR - 2020-01-18 17:53:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 17:53:17 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 17:53:17 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 17:53:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 799
ERROR - 2020-01-18 17:53:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1102
ERROR - 2020-01-18 17:54:49 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 17:54:49 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 17:54:49 --> Could not find the language line "hello"
ERROR - 2020-01-18 17:54:49 --> Could not find the language line "user_id"
ERROR - 2020-01-18 17:54:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 17:54:49 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 17:54:49 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 17:54:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 799
ERROR - 2020-01-18 17:54:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1102
ERROR - 2020-01-18 17:55:47 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 17:55:47 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 17:55:47 --> Could not find the language line "hello"
ERROR - 2020-01-18 17:55:47 --> Could not find the language line "user_id"
ERROR - 2020-01-18 17:55:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 17:55:47 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 17:55:47 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 17:55:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 799
ERROR - 2020-01-18 17:55:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1102
ERROR - 2020-01-18 17:56:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 17:56:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 17:56:11 --> Could not find the language line "hello"
ERROR - 2020-01-18 17:56:11 --> Could not find the language line "user_id"
ERROR - 2020-01-18 17:56:11 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 17:56:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 17:56:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 17:56:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 799
ERROR - 2020-01-18 17:56:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1102
ERROR - 2020-01-18 17:57:49 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 17:57:49 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 17:57:49 --> Could not find the language line "hello"
ERROR - 2020-01-18 17:57:49 --> Could not find the language line "user_id"
ERROR - 2020-01-18 17:57:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 17:57:49 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 17:57:49 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 17:57:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 799
ERROR - 2020-01-18 17:57:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1102
ERROR - 2020-01-18 17:58:02 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 17:58:02 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 17:58:02 --> Could not find the language line "hello"
ERROR - 2020-01-18 17:58:02 --> Could not find the language line "user_id"
ERROR - 2020-01-18 17:58:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 17:58:02 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 17:58:02 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 17:58:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 799
ERROR - 2020-01-18 17:58:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1102
ERROR - 2020-01-18 17:58:23 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 17:58:23 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 17:58:23 --> Could not find the language line "hello"
ERROR - 2020-01-18 17:58:23 --> Could not find the language line "user_id"
ERROR - 2020-01-18 17:58:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 17:58:23 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 17:58:23 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 17:58:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 799
ERROR - 2020-01-18 17:58:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1102
ERROR - 2020-01-18 17:58:48 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 17:58:48 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 17:58:48 --> Could not find the language line "hello"
ERROR - 2020-01-18 17:58:48 --> Could not find the language line "user_id"
ERROR - 2020-01-18 17:58:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 17:58:48 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 17:58:48 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 17:58:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 799
ERROR - 2020-01-18 17:58:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1102
ERROR - 2020-01-18 17:59:55 --> Could not find the language line "hello"
ERROR - 2020-01-18 17:59:55 --> Could not find the language line "user_id"
ERROR - 2020-01-18 17:59:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 17:59:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 806
ERROR - 2020-01-18 17:59:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1109
ERROR - 2020-01-18 18:02:22 --> Could not find the language line "hello"
ERROR - 2020-01-18 18:02:22 --> Could not find the language line "user_id"
ERROR - 2020-01-18 18:02:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 18:02:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 806
ERROR - 2020-01-18 18:02:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1109
ERROR - 2020-01-18 18:06:06 --> Could not find the language line "hello"
ERROR - 2020-01-18 18:06:06 --> Could not find the language line "user_id"
ERROR - 2020-01-18 18:06:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 18:06:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 809
ERROR - 2020-01-18 18:06:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1112
ERROR - 2020-01-18 18:06:37 --> Could not find the language line "hello"
ERROR - 2020-01-18 18:06:37 --> Could not find the language line "user_id"
ERROR - 2020-01-18 18:06:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 18:06:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 809
ERROR - 2020-01-18 18:06:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1112
ERROR - 2020-01-18 18:09:23 --> Could not find the language line "hello"
ERROR - 2020-01-18 18:09:23 --> Could not find the language line "user_id"
ERROR - 2020-01-18 18:09:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 18:09:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 807
ERROR - 2020-01-18 18:09:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1110
ERROR - 2020-01-18 18:11:46 --> Could not find the language line "hello"
ERROR - 2020-01-18 18:11:46 --> Could not find the language line "user_id"
ERROR - 2020-01-18 18:11:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 18:11:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 801
ERROR - 2020-01-18 18:11:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1104
ERROR - 2020-01-18 18:12:31 --> Could not find the language line "hello"
ERROR - 2020-01-18 18:12:31 --> Could not find the language line "user_id"
ERROR - 2020-01-18 18:12:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 18:12:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 799
ERROR - 2020-01-18 18:12:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1102
ERROR - 2020-01-18 18:20:07 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 18:20:07 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 18:20:07 --> Could not find the language line "hello"
ERROR - 2020-01-18 18:20:07 --> Could not find the language line "user_id"
ERROR - 2020-01-18 18:20:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 18:20:07 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 18:20:07 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 18:20:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 807
ERROR - 2020-01-18 18:20:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1110
ERROR - 2020-01-18 18:26:05 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 18:26:05 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 18:26:05 --> Could not find the language line "hello"
ERROR - 2020-01-18 18:26:05 --> Could not find the language line "user_id"
ERROR - 2020-01-18 18:26:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 18:26:05 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 18:26:05 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 18:26:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 807
ERROR - 2020-01-18 18:26:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1110
ERROR - 2020-01-18 18:26:45 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 18:26:45 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 18:26:45 --> Could not find the language line "hello"
ERROR - 2020-01-18 18:26:45 --> Could not find the language line "user_id"
ERROR - 2020-01-18 18:26:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 18:26:45 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 18:26:45 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 18:26:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 807
ERROR - 2020-01-18 18:26:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1110
ERROR - 2020-01-18 18:27:48 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 18:27:48 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 18:27:48 --> Could not find the language line "hello"
ERROR - 2020-01-18 18:27:48 --> Could not find the language line "user_id"
ERROR - 2020-01-18 18:27:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 18:27:48 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 18:27:48 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 18:27:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 807
ERROR - 2020-01-18 18:27:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1110
ERROR - 2020-01-18 18:28:13 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 18:28:13 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 18:28:13 --> Could not find the language line "hello"
ERROR - 2020-01-18 18:28:13 --> Could not find the language line "user_id"
ERROR - 2020-01-18 18:28:13 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 18:28:13 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 18:28:13 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 18:28:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 807
ERROR - 2020-01-18 18:28:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1110
ERROR - 2020-01-18 18:29:18 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 18:29:18 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 18:29:18 --> Could not find the language line "hello"
ERROR - 2020-01-18 18:29:18 --> Could not find the language line "user_id"
ERROR - 2020-01-18 18:29:18 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 18:29:18 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 18:29:18 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 18:29:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 807
ERROR - 2020-01-18 18:29:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1110
ERROR - 2020-01-18 18:30:55 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 18:30:55 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 18:30:55 --> Could not find the language line "hello"
ERROR - 2020-01-18 18:30:55 --> Could not find the language line "user_id"
ERROR - 2020-01-18 18:30:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 18:30:55 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 18:30:55 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 18:30:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 807
ERROR - 2020-01-18 18:30:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1110
ERROR - 2020-01-18 19:13:52 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 19:13:52 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 19:13:52 --> Could not find the language line "hello"
ERROR - 2020-01-18 19:13:52 --> Could not find the language line "user_id"
ERROR - 2020-01-18 19:13:52 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 19:13:52 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 19:13:52 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 19:13:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 828
ERROR - 2020-01-18 19:13:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1131
ERROR - 2020-01-18 19:14:26 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 19:14:26 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 19:14:26 --> Could not find the language line "hello"
ERROR - 2020-01-18 19:14:26 --> Could not find the language line "user_id"
ERROR - 2020-01-18 19:14:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 19:14:26 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 19:14:26 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 19:14:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 828
ERROR - 2020-01-18 19:14:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1131
ERROR - 2020-01-18 19:14:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '12
LEFT JOIN `kams_qbank` `q` ON `q`.`qid``in` 12
WHERE `r`.`rid` = '13'' at line 3 - Invalid query: SELECT `r`.`quid`, `a`.`score_u`, `q`.`question`
FROM `kams_result` `r`
LEFT JOIN `kams_answers` `a` ON `r`.`rid` = `a`.`rid` and `a`.`qid``in` 12
LEFT JOIN `kams_qbank` `q` ON `q`.`qid``in` 12
WHERE `r`.`rid` = '13'
ERROR - 2020-01-18 19:17:10 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 19:17:10 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 19:17:10 --> Could not find the language line "hello"
ERROR - 2020-01-18 19:17:10 --> Could not find the language line "user_id"
ERROR - 2020-01-18 19:17:10 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 19:17:10 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 19:17:10 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 19:17:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 828
ERROR - 2020-01-18 19:17:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1131
ERROR - 2020-01-18 19:17:57 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 19:17:57 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 19:17:57 --> Could not find the language line "hello"
ERROR - 2020-01-18 19:17:57 --> Could not find the language line "user_id"
ERROR - 2020-01-18 19:17:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 19:17:57 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 19:17:57 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 19:17:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 828
ERROR - 2020-01-18 19:17:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1131
ERROR - 2020-01-18 19:18:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '12
LEFT JOIN `kams_qbank` `q` ON `q`.`qid``in` 12
WHERE `r`.`rid` = '153'' at line 3 - Invalid query: SELECT `r`.`quid`, `a`.`score_u`, `q`.`question`
FROM `kams_result` `r`
LEFT JOIN `kams_answers` `a` ON `r`.`rid` = `a`.`rid` and `a`.`qid``in` 12
LEFT JOIN `kams_qbank` `q` ON `q`.`qid``in` 12
WHERE `r`.`rid` = '153'
ERROR - 2020-01-18 19:18:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '18
LEFT JOIN `kams_qbank` `q` ON `q`.`qid``in` 18
WHERE `r`.`rid` = '153'' at line 3 - Invalid query: SELECT `r`.`quid`, `a`.`score_u`, `q`.`question`
FROM `kams_result` `r`
LEFT JOIN `kams_answers` `a` ON `r`.`rid` = `a`.`rid` and `a`.`qid``in` 18
LEFT JOIN `kams_qbank` `q` ON `q`.`qid``in` 18
WHERE `r`.`rid` = '153'
ERROR - 2020-01-18 19:18:49 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 19:18:49 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 19:18:49 --> Could not find the language line "hello"
ERROR - 2020-01-18 19:18:49 --> Could not find the language line "user_id"
ERROR - 2020-01-18 19:18:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 19:18:49 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 19:18:49 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 19:18:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 828
ERROR - 2020-01-18 19:18:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1131
ERROR - 2020-01-18 19:22:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 19:22:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 19:22:21 --> Could not find the language line "hello"
ERROR - 2020-01-18 19:22:21 --> Could not find the language line "user_id"
ERROR - 2020-01-18 19:22:21 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 19:22:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 19:22:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 19:22:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 828
ERROR - 2020-01-18 19:22:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1131
ERROR - 2020-01-18 19:22:36 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 19:22:36 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 19:22:36 --> Could not find the language line "hello"
ERROR - 2020-01-18 19:22:36 --> Could not find the language line "user_id"
ERROR - 2020-01-18 19:22:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 19:22:36 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 19:22:36 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 19:22:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 828
ERROR - 2020-01-18 19:22:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1131
ERROR - 2020-01-18 19:23:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`12,13,14`
LEFT JOIN `kams_qbank` `q` ON `q`.`qid``in` `12,13,14`
WHERE `r`.`rid' at line 3 - Invalid query: SELECT `r`.`quid`, `a`.`score_u`, `q`.`question`
FROM `kams_result` `r`
LEFT JOIN `kams_answers` `a` ON `r`.`rid` = `a`.`rid` and `a`.`qid``in` `12,13,14`
LEFT JOIN `kams_qbank` `q` ON `q`.`qid``in` `12,13,14`
WHERE `r`.`rid` = '153'
ERROR - 2020-01-18 22:22:42 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-01-18 22:22:47 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-01-18 22:23:09 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 22:23:09 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 22:23:09 --> Could not find the language line "hello"
ERROR - 2020-01-18 22:23:09 --> Could not find the language line "user_id"
ERROR - 2020-01-18 22:23:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 22:23:09 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 22:23:09 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 22:23:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 828
ERROR - 2020-01-18 22:23:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1131
ERROR - 2020-01-18 22:34:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`12,13,14`
WHERE `a`.`qid` IN('12,13,14')
AND `r`.`rid` = '153'
GROUP BY `q`.`qi' at line 4 - Invalid query: SELECT `r`.`quid`, `a`.`score_u`, `q`.`question`
FROM `kams_result` `r`
LEFT JOIN `kams_answers` `a` ON `r`.`rid` = `a`.`rid`
LEFT JOIN `kams_qbank` `q` ON `q`.`qid``IN` `12,13,14`
WHERE `a`.`qid` IN('12,13,14')
AND `r`.`rid` = '153'
GROUP BY `q`.`qid`
ERROR - 2020-01-18 22:34:47 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-18 22:34:47 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-18 22:34:47 --> Could not find the language line "hello"
ERROR - 2020-01-18 22:34:47 --> Could not find the language line "user_id"
ERROR - 2020-01-18 22:34:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-18 22:34:47 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-18 22:34:47 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-18 22:34:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 828
ERROR - 2020-01-18 22:34:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1131
ERROR - 2020-01-18 22:34:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`12,13,14`
WHERE `a`.`qid` IN('12,13,14')
AND `r`.`rid` = '153'
GROUP BY `q`.`qi' at line 4 - Invalid query: SELECT `r`.`quid`, `a`.`score_u`, `q`.`question`
FROM `kams_result` `r`
LEFT JOIN `kams_answers` `a` ON `r`.`rid` = `a`.`rid`
LEFT JOIN `kams_qbank` `q` ON `q`.`qid``IN` `12,13,14`
WHERE `a`.`qid` IN('12,13,14')
AND `r`.`rid` = '153'
GROUP BY `q`.`qid`
