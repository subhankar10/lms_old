<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-05 11:06:03 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-02-05 11:52:46 --> Severity: Warning --> mysqli::__construct(): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/equizAdmin/application/config/config.php 515
ERROR - 2020-02-05 11:52:46 --> Severity: Warning --> mysqli::__construct(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /var/www/html/equizAdmin/application/config/config.php 515
ERROR - 2020-02-05 11:59:45 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-05 11:59:45 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-05 11:59:45 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-05 11:59:45 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-05 11:59:45 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-05 11:59:45 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-05 12:22:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
WHERE  IS NULL' at line 4 - Invalid query: SELECT `q`.`quiz_name`, `s`.*, CONCAT(u.first_name, " ", u.last_name) AS user_name
FROM `kams_students_exam_subscription` `s`
LEFT JOIN `kams_quiz` `q` ON `q`.`quid` = `s`.`quiz_id`
LEFT JOIN `kams_users` `u` USING ()
WHERE  IS NULL
ERROR - 2020-02-05 12:22:52 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/controllers/Student_subscriptionexam.php 60
ERROR - 2020-02-05 12:23:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
WHERE  IS NULL' at line 4 - Invalid query: SELECT `q`.`quiz_name`, `s`.*, CONCAT(u.first_name, " ", u.last_name) AS user_name
FROM `kams_students_exam_subscription` `s`
LEFT JOIN `kams_quiz` `q` ON `q`.`quid` = `s`.`quiz_id`
LEFT JOIN `kams_users` `u` USING ()
WHERE  IS NULL
ERROR - 2020-02-05 12:23:16 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/controllers/Student_subscriptionexam.php 61
ERROR - 2020-02-05 12:23:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
WHERE  IS NULL' at line 4 - Invalid query: SELECT `q`.`quiz_name`, `s`.*, CONCAT(u.first_name, " ", u.last_name) AS user_name
FROM `kams_students_exam_subscription` `s`
LEFT JOIN `kams_quiz` `q` ON `q`.`quid` = `s`.`quiz_id`
LEFT JOIN `kams_users` `u` USING ()
WHERE  IS NULL
ERROR - 2020-02-05 12:23:43 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/controllers/Student_subscriptionexam.php 61
ERROR - 2020-02-05 12:23:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
WHERE  IS NULL' at line 4 - Invalid query: SELECT `q`.`quiz_name`, `s`.*, CONCAT(u.first_name, " ", u.last_name) AS user_name
FROM `kams_students_exam_subscription` `s`
LEFT JOIN `kams_quiz` `q` ON `q`.`quid` = `s`.`quiz_id`
LEFT JOIN `kams_users` `u` USING ()
WHERE  IS NULL
ERROR - 2020-02-05 12:23:57 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/controllers/Student_subscriptionexam.php 62
ERROR - 2020-02-05 12:23:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
WHERE  IS NULL' at line 4 - Invalid query: SELECT `q`.`quiz_name`, `s`.*, CONCAT(u.first_name, " ", u.last_name) AS user_name
FROM `kams_students_exam_subscription` `s`
LEFT JOIN `kams_quiz` `q` ON `q`.`quid` = `s`.`quiz_id`
LEFT JOIN `kams_users` `u` USING ()
WHERE  IS NULL
ERROR - 2020-02-05 12:23:58 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/controllers/Student_subscriptionexam.php 62
ERROR - 2020-02-05 12:24:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
WHERE  IS NULL' at line 4 - Invalid query: SELECT `q`.`quiz_name`, `s`.*, CONCAT(u.first_name, " ", u.last_name) AS user_name
FROM `kams_students_exam_subscription` `s`
LEFT JOIN `kams_quiz` `q` ON `q`.`quid` = `s`.`quiz_id`
LEFT JOIN `kams_users` `u` USING ()
WHERE  IS NULL
ERROR - 2020-02-05 12:24:00 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/controllers/Student_subscriptionexam.php 62
ERROR - 2020-02-05 12:24:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
WHERE  IS NULL' at line 4 - Invalid query: SELECT `q`.`quiz_name`, `s`.*, CONCAT(u.first_name, " ", u.last_name) AS user_name
FROM `kams_students_exam_subscription` `s`
LEFT JOIN `kams_quiz` `q` ON `q`.`quid` = `s`.`quiz_id`
LEFT JOIN `kams_users` `u` USING ()
WHERE  IS NULL
ERROR - 2020-02-05 12:24:27 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/controllers/Student_subscriptionexam.php 63
ERROR - 2020-02-05 12:28:49 --> Query error: Unknown column 's.agency_id,74' in 'where clause' - Invalid query: SELECT `q`.`quiz_name`, `s`.*, CONCAT(u.first_name, " ", u.last_name) AS user_name
FROM `kams_students_exam_subscription` `s`
LEFT JOIN `kams_quiz` `q` ON `q`.`quid` = `s`.`quiz_id`
LEFT JOIN `kams_users` `u` ON `u`.`uid` = `s`.`agency_id`
WHERE `s`.`agency_id,74` IS NULL
ERROR - 2020-02-05 12:28:49 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/controllers/Student_subscriptionexam.php 65
ERROR - 2020-02-05 12:28:54 --> Query error: Unknown column 's.agency_id,74' in 'where clause' - Invalid query: SELECT `q`.`quiz_name`, `s`.*, CONCAT(u.first_name, " ", u.last_name) AS user_name
FROM `kams_students_exam_subscription` `s`
LEFT JOIN `kams_quiz` `q` ON `q`.`quid` = `s`.`quiz_id`
LEFT JOIN `kams_users` `u` ON `u`.`uid` = `s`.`agency_id`
WHERE `s`.`agency_id,74` IS NULL
ERROR - 2020-02-05 12:28:54 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/controllers/Student_subscriptionexam.php 66
ERROR - 2020-02-05 12:33:35 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-05 12:33:35 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-05 12:33:35 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-05 12:33:35 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-05 12:33:35 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-05 12:33:35 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-05 12:34:28 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-02-05 12:34:33 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-05 12:34:33 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-05 12:34:33 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-05 12:34:33 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-05 12:34:33 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-05 12:34:33 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-05 12:34:38 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-05 12:34:38 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-05 12:34:38 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-05 12:34:38 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-05 12:34:38 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-05 12:34:38 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-05 12:35:42 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-05 12:35:42 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-05 12:35:42 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-05 12:35:42 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-05 12:36:26 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-05 12:36:26 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-05 12:36:26 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-05 12:36:26 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-05 12:36:26 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-05 12:36:26 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-05 12:37:10 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-05 12:37:10 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-05 12:37:10 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-05 12:37:10 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-05 12:37:10 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-05 12:37:10 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-05 12:37:16 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-05 12:37:16 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-05 12:37:16 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-05 12:37:16 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-05 12:37:16 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-05 12:37:16 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-05 12:37:19 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-05 12:37:19 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-05 12:37:19 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-05 12:37:19 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-05 12:37:19 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-05 12:37:19 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-05 12:37:25 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-05 12:37:25 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-05 12:37:25 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-05 12:37:25 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-05 12:37:25 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmin/application/models/Quiz_model.php 255
ERROR - 2020-02-05 12:37:25 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmin/application/models/Quiz_model.php 256
ERROR - 2020-02-05 12:37:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/models/Quiz_model.php 316
ERROR - 2020-02-05 12:37:26 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-05 12:37:26 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-05 12:37:26 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-05 12:37:26 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-05 12:37:26 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-05 12:37:26 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-05 12:37:32 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-05 12:37:32 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-05 12:37:32 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-05 12:37:32 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-05 12:37:32 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-05 12:37:32 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-05 12:39:35 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-05 12:39:35 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-05 12:39:35 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-05 12:39:35 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-05 12:39:35 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-05 12:39:35 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-05 12:39:40 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-05 12:39:40 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-05 12:39:40 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-05 12:39:40 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-05 12:39:41 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-05 12:39:41 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-05 12:39:46 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-05 12:39:46 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-05 12:39:46 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-05 12:39:46 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-05 12:39:46 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmin/application/models/Quiz_model.php 255
ERROR - 2020-02-05 12:39:46 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmin/application/models/Quiz_model.php 256
ERROR - 2020-02-05 12:39:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/models/Quiz_model.php 316
ERROR - 2020-02-05 12:39:46 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-05 12:39:46 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-05 12:39:46 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-05 12:39:46 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-05 12:39:46 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-05 12:39:46 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-05 12:39:52 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-05 12:39:52 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-05 12:39:52 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-05 12:39:52 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-05 12:39:52 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-05 12:39:52 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-05 15:31:22 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-02-05 15:31:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 206
ERROR - 2020-02-05 15:37:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 206
ERROR - 2020-02-05 15:38:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 206
ERROR - 2020-02-05 15:38:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 206
ERROR - 2020-02-05 15:38:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 206
ERROR - 2020-02-05 15:39:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 206
ERROR - 2020-02-05 15:41:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 206
ERROR - 2020-02-05 15:41:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 206
ERROR - 2020-02-05 15:46:09 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-02-05 15:49:31 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-05 15:49:31 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-05 15:49:31 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-05 15:49:31 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-05 15:49:31 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-05 15:49:31 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-05 15:50:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 206
ERROR - 2020-02-05 15:52:54 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/equizAdmin/application/models/Examiner_model.php 150
ERROR - 2020-02-05 15:52:56 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/equizAdmin/application/models/Examiner_model.php 150
ERROR - 2020-02-05 15:53:20 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/equizAdmin/application/models/Examiner_model.php 150
ERROR - 2020-02-05 15:53:22 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/equizAdmin/application/models/Examiner_model.php 150
ERROR - 2020-02-05 15:53:40 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/equizAdmin/application/models/Examiner_model.php 150
ERROR - 2020-02-05 15:54:06 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/equizAdmin/application/models/Examiner_model.php 150
ERROR - 2020-02-05 15:54:06 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/equizAdmin/application/models/Examiner_model.php 150
ERROR - 2020-02-05 17:19:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 206
ERROR - 2020-02-05 17:19:56 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-05 17:19:56 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-05 17:19:56 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-05 17:19:56 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-05 17:19:56 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-05 17:19:56 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-05 17:34:30 --> Could not find the language line "scorer_name"
ERROR - 2020-02-05 17:34:50 --> Could not find the language line "scorer_name"
ERROR - 2020-02-05 17:57:56 --> Could not find the language line "scorer_name"
ERROR - 2020-02-05 18:01:24 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-05 18:01:24 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-05 18:01:24 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-05 18:01:24 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-05 18:01:24 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-05 18:01:24 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-05 18:38:17 --> Query error: Unknown column 'p1.quidLEFT' in 'on clause' - Invalid query: SELECT ku.first_name, ku.last_name,kq.quiz_name, p1.rid,p1.quid,p1.uid,p1.result_status,p1.video_conference_flag FROM kams_result p1 INNER JOIN (SELECT pi.rid, MAX(pi.rid) AS maxpostid FROM kams_result pi GROUP BY pi.quid) p2 ON (p1.rid = p2.maxpostid)LEFT JOIN kams_users AS ku ON ku.uid = p1.uid LEFT JOIN kams_quiz AS kq ON kq.quid = p1.quidLEFT JOIN kams_students_exam_subscription AS ks ON ks.subscription_id = p1.subscription_id
ERROR - 2020-02-05 18:38:17 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/controllers/Examiner.php 237
ERROR - 2020-02-05 18:39:42 --> Query error: Unknown column 'p1.quidLEFT' in 'on clause' - Invalid query: SELECT ku.first_name, ku.last_name,kq.quiz_name, p1.rid,p1.quid,p1.uid,p1.result_status,p1.video_conference_flag FROM kams_result p1 INNER JOIN (SELECT pi.rid, MAX(pi.rid) AS maxpostid FROM kams_result pi GROUP BY pi.quid) p2 ON (p1.rid = p2.maxpostid)LEFT JOIN kams_users AS ku ON ku.uid = p1.uid LEFT JOIN kams_quiz AS kq ON kq.quid = p1.quidLEFT JOIN kams_students_exam_subscription AS ks ON ks.subscription_id = p1.subscription_id
ERROR - 2020-02-05 18:39:42 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/controllers/Examiner.php 237
ERROR - 2020-02-05 18:39:44 --> Query error: Unknown column 'p1.quidLEFT' in 'on clause' - Invalid query: SELECT ku.first_name, ku.last_name,kq.quiz_name, p1.rid,p1.quid,p1.uid,p1.result_status,p1.video_conference_flag FROM kams_result p1 INNER JOIN (SELECT pi.rid, MAX(pi.rid) AS maxpostid FROM kams_result pi GROUP BY pi.quid) p2 ON (p1.rid = p2.maxpostid)LEFT JOIN kams_users AS ku ON ku.uid = p1.uid LEFT JOIN kams_quiz AS kq ON kq.quid = p1.quidLEFT JOIN kams_students_exam_subscription AS ks ON ks.subscription_id = p1.subscription_id
ERROR - 2020-02-05 18:39:44 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/controllers/Examiner.php 237
ERROR - 2020-02-05 18:40:11 --> Query error: Unknown column 'p1.quidLEFT' in 'on clause' - Invalid query: SELECT ku.first_name, ku.last_name,kq.quiz_name, p1.rid,p1.quid,p1.uid,p1.result_status,p1.video_conference_flag FROM kams_result p1 INNER JOIN (SELECT pi.rid, MAX(pi.rid) AS maxpostid FROM kams_result pi GROUP BY pi.quid) p2 ON (p1.rid = p2.maxpostid)LEFT JOIN kams_users AS ku ON ku.uid = p1.uid LEFT JOIN kams_quiz AS kq ON kq.quid = p1.quidLEFT JOIN kams_students_exam_subscription AS ks ON ks.subscription_id = p1.subscription_id
ERROR - 2020-02-05 18:40:11 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/controllers/Examiner.php 238
