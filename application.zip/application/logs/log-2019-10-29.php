<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-29 12:31:28 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 237
ERROR - 2019-10-29 15:32:34 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 237
