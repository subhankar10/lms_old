<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-30 12:36:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 182
ERROR - 2020-03-30 12:36:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 182
ERROR - 2020-03-30 12:36:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 182
ERROR - 2020-03-30 12:36:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 182
ERROR - 2020-03-30 13:56:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/examiner_list.php 204
ERROR - 2020-03-30 14:21:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/models/User_model.php 414
ERROR - 2020-03-30 14:22:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/onlineclassroom/application/views/dashboard.php 197
ERROR - 2020-03-30 14:22:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/dashboard.php 202
ERROR - 2020-03-30 14:22:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/onlineclassroom/application/views/dashboard.php 197
ERROR - 2020-03-30 14:22:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/dashboard.php 202
ERROR - 2020-03-30 14:28:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/examiner_list.php 204
ERROR - 2020-03-30 14:34:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/class/classroomList.php 174
ERROR - 2020-03-30 14:35:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/class/classroomList.php 174
ERROR - 2020-03-30 14:35:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/class/classroomList.php 174
ERROR - 2020-03-30 14:36:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/class/classroomList.php 174
ERROR - 2020-03-30 14:36:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 182
ERROR - 2020-03-30 14:37:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/onlineclassroom/application/views/dashboard.php 197
ERROR - 2020-03-30 14:37:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/dashboard.php 202
ERROR - 2020-03-30 14:37:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 182
ERROR - 2020-03-30 14:52:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/examiner_list.php 204
ERROR - 2020-03-30 15:00:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 182
ERROR - 2020-03-30 15:00:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 182
ERROR - 2020-03-30 15:00:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 182
ERROR - 2020-03-30 15:00:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 182
ERROR - 2020-03-30 15:00:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 182
ERROR - 2020-03-30 15:00:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 182
ERROR - 2020-03-30 15:00:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 182
ERROR - 2020-03-30 15:01:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 182
ERROR - 2020-03-30 15:04:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 182
ERROR - 2020-03-30 15:04:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 182
ERROR - 2020-03-30 15:41:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 182
ERROR - 2020-03-30 15:41:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 182
ERROR - 2020-03-30 15:50:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 182
ERROR - 2020-03-30 15:53:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 182
ERROR - 2020-03-30 15:55:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 182
ERROR - 2020-03-30 15:55:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 182
ERROR - 2020-03-30 16:06:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 193
ERROR - 2020-03-30 16:06:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 194
ERROR - 2020-03-30 16:07:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 194
ERROR - 2020-03-30 16:07:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 194
ERROR - 2020-03-30 16:10:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 206
ERROR - 2020-03-30 16:15:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 207
ERROR - 2020-03-30 17:22:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 207
ERROR - 2020-03-30 17:22:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 182
ERROR - 2020-03-30 17:24:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 182
ERROR - 2020-03-30 17:25:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 182
ERROR - 2020-03-30 17:26:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 182
ERROR - 2020-03-30 17:26:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 207
ERROR - 2020-03-30 17:26:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 182
ERROR - 2020-03-30 17:27:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 182
ERROR - 2020-03-30 17:29:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 182
ERROR - 2020-03-30 17:29:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/class/classroomList.php 174
ERROR - 2020-03-30 17:29:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 182
ERROR - 2020-03-30 17:30:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 182
ERROR - 2020-03-30 17:31:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 207
ERROR - 2020-03-30 17:31:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 182
ERROR - 2020-03-30 17:36:49 --> Severity: error --> Exception: Too few arguments to function User::update_user(), 0 passed in /var/www/html/onlineclassroom/system/core/CodeIgniter.php on line 532 and exactly 1 expected /var/www/html/onlineclassroom/application/controllers/User.php 270
ERROR - 2020-03-30 17:36:58 --> Severity: error --> Exception: Too few arguments to function User::update_user(), 0 passed in /var/www/html/onlineclassroom/system/core/CodeIgniter.php on line 532 and exactly 1 expected /var/www/html/onlineclassroom/application/controllers/User.php 270
ERROR - 2020-03-30 17:37:06 --> Severity: error --> Exception: Too few arguments to function User::update_user(), 0 passed in /var/www/html/onlineclassroom/system/core/CodeIgniter.php on line 532 and exactly 1 expected /var/www/html/onlineclassroom/application/controllers/User.php 270
ERROR - 2020-03-30 17:39:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/models/User_model.php 607
ERROR - 2020-03-30 17:39:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/models/User_model.php 607
ERROR - 2020-03-30 17:46:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: select * from kams_students_exam_subscription where qid in () 
ERROR - 2020-03-30 17:47:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/onlineclassroom/application/views/dashboard.php 197
ERROR - 2020-03-30 17:47:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/dashboard.php 202
ERROR - 2020-03-30 17:47:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/userupcomingliveclassList.php 200
ERROR - 2020-03-30 17:47:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/userupcomingliveclassList.php 200
ERROR - 2020-03-30 17:55:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 207
ERROR - 2020-03-30 17:55:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/onlineclassroom/application/views/dashboard.php 197
ERROR - 2020-03-30 17:55:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/dashboard.php 202
ERROR - 2020-03-30 17:55:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/userupcomingliveclassList.php 200
ERROR - 2020-03-30 18:03:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/userupcomingliveclassList.php 200
ERROR - 2020-03-30 18:04:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/userupcomingliveclassList.php 200
ERROR - 2020-03-30 18:06:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/userupcomingliveclassList.php 198
ERROR - 2020-03-30 18:07:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/userupcomingliveclassList.php 198
ERROR - 2020-03-30 18:07:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/userupcomingliveclassList.php 198
ERROR - 2020-03-30 18:08:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 182
ERROR - 2020-03-30 18:09:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 182
ERROR - 2020-03-30 18:11:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 182
ERROR - 2020-03-30 18:11:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 182
ERROR - 2020-03-30 18:12:15 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/onlineclassroom/application/views/dashboard.php 197
ERROR - 2020-03-30 18:12:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/dashboard.php 202
ERROR - 2020-03-30 18:12:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 182
ERROR - 2020-03-30 18:14:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 182
ERROR - 2020-03-30 18:17:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 182
ERROR - 2020-03-30 18:17:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 182
ERROR - 2020-03-30 19:40:17 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/onlineclassroom/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-30 19:40:17 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/onlineclassroom/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-30 19:40:17 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/onlineclassroom/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-30 19:40:17 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/onlineclassroom/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-30 19:40:20 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/onlineclassroom/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-30 19:40:20 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/onlineclassroom/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-30 19:40:20 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/onlineclassroom/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-30 19:40:20 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/onlineclassroom/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-30 19:40:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 221
ERROR - 2020-03-30 19:41:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 221
ERROR - 2020-03-30 19:43:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 222
ERROR - 2020-03-30 19:44:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 222
ERROR - 2020-03-30 19:45:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 222
ERROR - 2020-03-30 19:45:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 222
ERROR - 2020-03-30 19:45:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 222
ERROR - 2020-03-30 19:45:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 222
ERROR - 2020-03-30 19:45:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 222
ERROR - 2020-03-30 19:46:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 214
ERROR - 2020-03-30 19:46:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 220
ERROR - 2020-03-30 19:47:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 220
ERROR - 2020-03-30 19:47:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 220
ERROR - 2020-03-30 19:47:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 220
ERROR - 2020-03-30 19:49:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 237
ERROR - 2020-03-30 19:50:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 237
ERROR - 2020-03-30 19:50:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 237
ERROR - 2020-03-30 19:56:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 239
ERROR - 2020-03-30 19:56:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 239
ERROR - 2020-03-30 19:56:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 239
ERROR - 2020-03-30 19:57:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 239
ERROR - 2020-03-30 19:57:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 239
ERROR - 2020-03-30 19:57:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 239
ERROR - 2020-03-30 19:59:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 239
ERROR - 2020-03-30 20:03:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 239
ERROR - 2020-03-30 20:12:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 245
ERROR - 2020-03-30 20:15:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/class/classroomList.php 174
ERROR - 2020-03-30 20:15:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/subject/subjectList.php 174
ERROR - 2020-03-30 20:16:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 207
ERROR - 2020-03-30 20:16:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 245
ERROR - 2020-03-30 20:16:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 207
ERROR - 2020-03-30 20:18:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 207
ERROR - 2020-03-30 20:18:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 207
ERROR - 2020-03-30 20:19:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/onlineclassroom/application/views/dashboard.php 197
ERROR - 2020-03-30 20:19:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/dashboard.php 202
ERROR - 2020-03-30 20:19:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/userupcomingliveclassList.php 198
ERROR - 2020-03-30 20:19:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 245
ERROR - 2020-03-30 20:21:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/onlineclassroom/application/views/dashboard.php 197
ERROR - 2020-03-30 20:21:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/dashboard.php 202
