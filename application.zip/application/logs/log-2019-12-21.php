<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-21 10:42:39 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 237
ERROR - 2019-12-21 10:47:12 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 237
ERROR - 2019-12-21 10:48:27 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 237
ERROR - 2019-12-21 10:52:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 110
ERROR - 2019-12-21 10:52:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 199
ERROR - 2019-12-21 11:36:45 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 237
ERROR - 2019-12-21 12:08:24 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 230
ERROR - 2019-12-21 12:10:59 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 265
ERROR - 2019-12-21 12:11:46 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 265
ERROR - 2019-12-21 12:12:03 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 265
ERROR - 2019-12-21 12:13:38 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 265
ERROR - 2019-12-21 12:14:34 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 267
ERROR - 2019-12-21 12:20:15 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 267
ERROR - 2019-12-21 13:02:39 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 286
ERROR - 2019-12-21 13:04:02 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 286
ERROR - 2019-12-21 13:04:58 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 286
ERROR - 2019-12-21 13:06:08 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 286
ERROR - 2019-12-21 13:06:26 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 286
ERROR - 2019-12-21 13:36:55 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 286
ERROR - 2019-12-21 13:38:24 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 260
ERROR - 2019-12-21 13:38:36 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 260
ERROR - 2019-12-21 13:38:48 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 260
ERROR - 2019-12-21 13:40:06 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 265
ERROR - 2019-12-21 14:48:09 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 265
ERROR - 2019-12-21 14:55:44 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 268
ERROR - 2019-12-21 14:55:50 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 268
ERROR - 2019-12-21 14:57:40 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 268
ERROR - 2019-12-21 14:57:44 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 268
ERROR - 2019-12-21 14:57:58 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 265
ERROR - 2019-12-21 15:05:57 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 263
ERROR - 2019-12-21 15:19:57 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 263
ERROR - 2019-12-21 17:56:53 --> Severity: Warning --> strtotime() expects parameter 1 to be string, array given /var/www/html/equiz/application/models/User_model.php 343
ERROR - 2019-12-21 17:58:37 --> The upload path does not appear to be valid.
ERROR - 2019-12-21 18:04:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/models/User_model.php 385
ERROR - 2019-12-21 21:39:47 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 263
ERROR - 2019-12-21 21:40:08 --> The upload path does not appear to be valid.
ERROR - 2019-12-21 21:41:00 --> The upload path does not appear to be valid.
ERROR - 2019-12-21 21:42:03 --> The upload path does not appear to be valid.
ERROR - 2019-12-21 21:42:30 --> The upload path does not appear to be valid.
ERROR - 2019-12-21 21:43:08 --> The upload path does not appear to be valid.
ERROR - 2019-12-21 21:43:25 --> The upload path does not appear to be valid.
ERROR - 2019-12-21 21:44:56 --> The upload path does not appear to be valid.
ERROR - 2019-12-21 21:45:19 --> The upload path does not appear to be valid.
ERROR - 2019-12-21 21:45:56 --> The upload path does not appear to be valid.
ERROR - 2019-12-21 21:47:05 --> The upload path does not appear to be valid.
ERROR - 2019-12-21 21:47:05 --> The upload path does not appear to be valid.
ERROR - 2019-12-21 21:50:05 --> The upload path does not appear to be valid.
ERROR - 2019-12-21 21:50:05 --> The upload path does not appear to be valid.
ERROR - 2019-12-21 21:51:39 --> The upload path does not appear to be valid.
ERROR - 2019-12-21 21:51:39 --> The upload path does not appear to be valid.
ERROR - 2019-12-21 22:07:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/models/User_model.php 377
ERROR - 2019-12-21 22:09:09 --> Could not find the language line "action"
