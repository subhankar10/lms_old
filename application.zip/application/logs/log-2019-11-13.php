<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-13 12:12:59 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 237
ERROR - 2019-11-13 12:13:45 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 237
