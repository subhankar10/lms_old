<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-06 10:29:51 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-02-06 11:40:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IS NULL' at line 6 - Invalid query: SELECT `q`.`quiz_name`, `s`.*, CONCAT(ue.first_name, " ", ue.last_name) AS examiner_name, CONCAT(us.first_name, " ", us.last_name) AS scorer_name
FROM `kams_students_exam_subscription` `s`
LEFT JOIN `kams_quiz` `q` ON `q`.`quid` = `s`.`quiz_id`
LEFT JOIN `kams_users` `ue` ON `ue`.`uid` = `s`.`examiner_id`
LEFT JOIN `kams_users` `us` ON `us`.`uid` = `s`.`scorer_id`
WHERE  IS NULL
ERROR - 2020-02-06 11:40:55 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/controllers/Student_subscriptionexam.php 60
ERROR - 2020-02-06 11:40:58 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-02-06 11:41:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IS NULL' at line 6 - Invalid query: SELECT `q`.`quiz_name`, `s`.*, CONCAT(ue.first_name, " ", ue.last_name) AS examiner_name, CONCAT(us.first_name, " ", us.last_name) AS scorer_name
FROM `kams_students_exam_subscription` `s`
LEFT JOIN `kams_quiz` `q` ON `q`.`quid` = `s`.`quiz_id`
LEFT JOIN `kams_users` `ue` ON `ue`.`uid` = `s`.`examiner_id`
LEFT JOIN `kams_users` `us` ON `us`.`uid` = `s`.`scorer_id`
WHERE  IS NULL
ERROR - 2020-02-06 11:41:01 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/controllers/Student_subscriptionexam.php 60
ERROR - 2020-02-06 11:41:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IS NULL' at line 6 - Invalid query: SELECT `q`.`quiz_name`, `s`.*, CONCAT(ue.first_name, " ", ue.last_name) AS examiner_name, CONCAT(us.first_name, " ", us.last_name) AS scorer_name
FROM `kams_students_exam_subscription` `s`
LEFT JOIN `kams_quiz` `q` ON `q`.`quid` = `s`.`quiz_id`
LEFT JOIN `kams_users` `ue` ON `ue`.`uid` = `s`.`examiner_id`
LEFT JOIN `kams_users` `us` ON `us`.`uid` = `s`.`scorer_id`
WHERE  IS NULL
ERROR - 2020-02-06 11:41:46 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/controllers/Student_subscriptionexam.php 62
ERROR - 2020-02-06 11:41:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IS NULL' at line 6 - Invalid query: SELECT `q`.`quiz_name`, `s`.*, CONCAT(ue.first_name, " ", ue.last_name) AS examiner_name, CONCAT(us.first_name, " ", us.last_name) AS scorer_name
FROM `kams_students_exam_subscription` `s`
LEFT JOIN `kams_quiz` `q` ON `q`.`quid` = `s`.`quiz_id`
LEFT JOIN `kams_users` `ue` ON `ue`.`uid` = `s`.`examiner_id`
LEFT JOIN `kams_users` `us` ON `us`.`uid` = `s`.`scorer_id`
WHERE  IS NULL
ERROR - 2020-02-06 11:41:47 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/controllers/Student_subscriptionexam.php 62
ERROR - 2020-02-06 11:42:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IS NULL' at line 6 - Invalid query: SELECT `q`.`quiz_name`, `s`.*, CONCAT(ue.first_name, " ", ue.last_name) AS examiner_name, CONCAT(us.first_name, " ", us.last_name) AS scorer_name
FROM `kams_students_exam_subscription` `s`
LEFT JOIN `kams_quiz` `q` ON `q`.`quid` = `s`.`quiz_id`
LEFT JOIN `kams_users` `ue` ON `ue`.`uid` = `s`.`examiner_id`
LEFT JOIN `kams_users` `us` ON `us`.`uid` = `s`.`scorer_id`
WHERE  IS NULL
ERROR - 2020-02-06 11:42:08 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/controllers/Student_subscriptionexam.php 63
ERROR - 2020-02-06 16:36:37 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-02-06 16:39:35 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-06 16:39:35 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-06 16:39:35 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-06 16:39:35 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-06 16:39:35 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-06 16:39:35 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-06 16:41:17 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-02-06 17:45:57 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-02-06 17:46:02 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-02-06 18:02:14 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-02-06 18:03:32 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-02-06 18:15:08 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 288
ERROR - 2020-02-06 18:15:41 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 287
ERROR - 2020-02-06 18:15:51 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 290
ERROR - 2020-02-06 18:16:20 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 292
ERROR - 2020-02-06 18:16:53 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 291
ERROR - 2020-02-06 18:26:37 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 284
ERROR - 2020-02-06 18:30:20 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 284
ERROR - 2020-02-06 18:30:52 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 284
ERROR - 2020-02-06 18:32:24 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 284
ERROR - 2020-02-06 18:33:34 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 284
ERROR - 2020-02-06 18:35:04 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 284
ERROR - 2020-02-06 18:52:30 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 284
ERROR - 2020-02-06 19:11:09 --> Could not find the language line "type"
ERROR - 2020-02-06 19:12:47 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 284
ERROR - 2020-02-06 19:33:07 --> Query error: Table 'equiz.kams_students_exam_subscription' doesn't exist - Invalid query: SELECT `q`.`quid`, `q`.`exam_category`, `q`.`exam_type`, `q`.`quiz_name`, `q`.`description`, `qs`.`approved_status`, `qs`.`start_date` AS `examstartdate`, `qs`.`start_time` AS `examstarttime`
FROM `kams_quiz` AS `q`
JOIN `kams_students_exam_subscription` AS `qs` ON `qs`.`quiz_id` = `q`.`quid`
WHERE `q`.`exam_type` = 2
AND `q`.`exam_category` IS NULL
AND `qs`.`student_id` = '52'
ERROR - 2020-02-06 19:33:07 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/controllers/Api.php 2679
ERROR - 2020-02-06 19:34:08 --> Query error: Table 'equiz.kams_students_exam_subscription' doesn't exist - Invalid query: SELECT `q`.`quid`, `q`.`exam_category`, `q`.`exam_type`, `q`.`quiz_name`, `q`.`description`, `qs`.`approved_status`, `qs`.`start_date` AS `examstartdate`, `qs`.`start_time` AS `examstarttime`
FROM `kams_quiz` AS `q`
JOIN `kams_students_exam_subscription` AS `qs` ON `qs`.`quiz_id` = `q`.`quid`
WHERE `q`.`exam_type` = 2
AND `q`.`exam_category` IS NULL
AND `qs`.`student_id` = '52'
ERROR - 2020-02-06 19:34:08 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/controllers/Api.php 2679
ERROR - 2020-02-06 19:34:11 --> Query error: Table 'equiz.kams_students_exam_subscription' doesn't exist - Invalid query: SELECT `q`.`quid`, `q`.`exam_category`, `q`.`exam_type`, `q`.`quiz_name`, `q`.`description`, `qs`.`approved_status`, `qs`.`start_date` AS `examstartdate`, `qs`.`start_time` AS `examstarttime`
FROM `kams_quiz` AS `q`
JOIN `kams_students_exam_subscription` AS `qs` ON `qs`.`quiz_id` = `q`.`quid`
WHERE `q`.`exam_type` = 2
AND `q`.`exam_category` IS NULL
AND `qs`.`student_id` = '52'
ERROR - 2020-02-06 19:34:11 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/controllers/Api.php 2679
ERROR - 2020-02-06 19:35:07 --> Query error: Table 'equiz.kams_students_exam_subscription' doesn't exist - Invalid query: SELECT `q`.`quid`, `q`.`exam_category`, `q`.`exam_type`, `q`.`quiz_name`, `q`.`description`, `qs`.`approved_status`, `qs`.`start_date` AS `examstartdate`, `qs`.`start_time` AS `examstarttime`
FROM `kams_quiz` AS `q`
JOIN `kams_students_exam_subscription` AS `qs` ON `qs`.`quiz_id` = `q`.`quid`
WHERE `q`.`exam_type` = 2
AND `q`.`exam_category` IS NULL
AND `qs`.`student_id` = '52'
ERROR - 2020-02-06 19:35:07 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/controllers/Api.php 2679
ERROR - 2020-02-06 19:36:16 --> Query error: Table 'equiz.kams_students_exam_subscription' doesn't exist - Invalid query: SELECT `q`.`quid`, `q`.`exam_category`, `q`.`exam_type`, `q`.`quiz_name`, `q`.`description`, `qs`.`approved_status`, `qs`.`start_date` AS `examstartdate`, `qs`.`start_time` AS `examstarttime`
FROM `kams_quiz` AS `q`
JOIN `kams_students_exam_subscription` AS `qs` ON `qs`.`quiz_id` = `q`.`quid`
WHERE `q`.`exam_type` = 2
AND `q`.`exam_category` IS NULL
AND `qs`.`student_id` = '52'
ERROR - 2020-02-06 19:36:16 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/controllers/Api.php 2679
ERROR - 2020-02-06 19:36:58 --> Query error: Table 'equiz.kams_students_exam_subscription' doesn't exist - Invalid query: SELECT `q`.`quid`, `q`.`exam_category`, `q`.`exam_type`, `q`.`quiz_name`, `q`.`description`, `qs`.`approved_status`, `qs`.`start_date` AS `examstartdate`, `qs`.`start_time` AS `examstarttime`
FROM `kams_quiz` AS `q`
JOIN `kams_students_exam_subscription` AS `qs` ON `qs`.`quiz_id` = `q`.`quid`
WHERE `q`.`exam_type` = 2
AND `q`.`exam_category` IS NULL
AND `qs`.`student_id` = '52'
ERROR - 2020-02-06 19:36:58 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/controllers/Api.php 2679
ERROR - 2020-02-06 19:38:38 --> Query error: Table 'equiz.kams_students_exam_subscription' doesn't exist - Invalid query: SELECT `q`.`quid`, `q`.`exam_category`, `q`.`exam_type`, `q`.`quiz_name`, `q`.`description`, `qs`.`approved_status`, `qs`.`start_date` AS `examstartdate`, `qs`.`start_time` AS `examstarttime`
FROM `kams_quiz` AS `q`
JOIN `kams_students_exam_subscription` AS `qs` ON `qs`.`quiz_id` = `q`.`quid`
WHERE `q`.`exam_type` = 2
AND `q`.`exam_category` IS NULL
AND `qs`.`student_id` = '52'
ERROR - 2020-02-06 19:38:38 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/controllers/Api.php 2680
ERROR - 2020-02-06 19:39:02 --> Query error: Table 'equiz.kams_students_exam_subscription' doesn't exist - Invalid query: SELECT `q`.`quid`, `q`.`exam_category`, `q`.`exam_type`, `q`.`quiz_name`, `q`.`description`, `qs`.`approved_status`, `qs`.`start_date` AS `examstartdate`, `qs`.`start_time` AS `examstarttime`
FROM `kams_quiz` AS `q`
JOIN `kams_students_exam_subscription` AS `qs` ON `qs`.`quiz_id` = `q`.`quid`
WHERE `q`.`exam_type` = 2
AND `q`.`exam_category` IS NULL
AND `qs`.`student_id` = '52'
ERROR - 2020-02-06 19:39:02 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/controllers/Api.php 2681
ERROR - 2020-02-06 19:40:10 --> Query error: Table 'equiz.kams_students_exam_subscription' doesn't exist - Invalid query: SELECT `q`.`quid`, `q`.`exam_category`, `q`.`exam_type`, `q`.`quiz_name`, `q`.`description`, `qs`.`approved_status`, `qs`.`start_date` AS `examstartdate`, `qs`.`start_time` AS `examstarttime`
FROM `kams_quiz` AS `q`
JOIN `kams_students_exam_subscription` AS `qs` ON `qs`.`quiz_id` = `q`.`quid`
WHERE `q`.`exam_type` = 2
AND `q`.`exam_category` IS NULL
AND `qs`.`student_id` = '52'
ERROR - 2020-02-06 19:40:10 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/controllers/Api.php 2681
ERROR - 2020-02-06 19:40:30 --> Query error: Table 'equiz.kams_students_exam_subscription' doesn't exist - Invalid query: SELECT `q`.`quid`, `q`.`exam_category`, `q`.`exam_type`, `q`.`quiz_name`, `q`.`description`, `qs`.`approved_status`, `qs`.`start_date` AS `examstartdate`, `qs`.`start_time` AS `examstarttime`
FROM `kams_quiz` AS `q`
JOIN `kams_students_exam_subscription` AS `qs` ON `qs`.`quiz_id` = `q`.`quid`
WHERE `q`.`exam_type` = 2
AND `q`.`exam_category` IS NULL
AND `qs`.`student_id` = '52'
ERROR - 2020-02-06 19:40:30 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/controllers/Api.php 2682
ERROR - 2020-02-06 19:45:00 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 284
ERROR - 2020-02-06 19:45:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 206
ERROR - 2020-02-06 19:50:12 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-06 19:50:12 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-06 19:50:12 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-06 19:50:12 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-06 19:50:12 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-06 19:50:21 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-06 19:50:21 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-06 19:50:21 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-06 19:50:21 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-06 19:50:21 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-06 19:50:21 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-06 19:50:32 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-06 19:50:32 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-06 19:50:32 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-06 19:50:32 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-06 19:50:32 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-06 19:50:32 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-06 19:50:32 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-06 19:50:32 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-06 19:50:32 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-06 19:50:32 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-06 19:50:38 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-06 19:50:38 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-06 19:50:38 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-06 19:50:38 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-06 19:50:38 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-06 19:50:38 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-06 19:51:17 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-06 19:51:17 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-06 19:51:17 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-06 19:51:17 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-06 19:51:17 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-06 19:51:17 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-06 19:51:17 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-06 19:51:17 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-06 19:51:17 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-06 19:51:17 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-06 19:51:40 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-06 19:51:40 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-06 19:51:40 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-06 19:51:40 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-06 19:51:40 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-06 19:51:40 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-06 19:51:47 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-06 19:51:47 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-06 19:51:47 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-06 19:51:47 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-06 19:51:47 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-06 19:51:47 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-06 19:51:47 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-06 19:51:47 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-06 19:51:47 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-06 19:51:47 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-06 19:53:13 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-06 19:53:13 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-06 19:53:13 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-06 19:53:13 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-06 19:53:13 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-06 19:53:13 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-06 19:53:17 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-06 19:53:17 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-06 19:53:17 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-06 19:53:17 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-06 19:53:17 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-06 19:53:17 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-06 19:53:17 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-06 19:53:17 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-06 19:53:17 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-06 19:53:17 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-06 19:54:36 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-06 19:54:36 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-06 19:54:36 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-06 19:54:36 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-06 19:54:36 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-06 19:54:36 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-06 19:58:11 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 284
ERROR - 2020-02-06 20:20:12 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 284
ERROR - 2020-02-06 20:20:15 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 284
ERROR - 2020-02-06 20:20:23 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-06 20:20:23 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-06 20:20:23 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-06 20:20:23 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-06 20:20:23 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-06 20:20:23 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-06 20:20:28 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-06 20:20:28 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-06 20:20:28 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-06 20:20:28 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-06 20:20:28 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-06 20:20:28 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-06 20:23:31 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-06 20:23:31 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-06 20:23:31 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-06 20:23:31 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-06 20:23:31 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-06 20:23:37 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-06 20:23:37 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-06 20:23:37 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-06 20:23:37 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-06 20:23:37 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-06 20:23:37 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-06 20:23:45 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-06 20:23:45 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-06 20:23:45 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-06 20:23:45 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-06 20:23:45 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-06 20:23:45 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-06 20:23:45 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-06 20:23:45 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-06 20:23:45 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-06 20:23:45 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-06 20:42:41 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 284
ERROR - 2020-02-06 20:42:42 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 284
