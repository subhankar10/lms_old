<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-14 11:37:22 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-01-14 11:56:56 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-01-14 16:45:18 --> Severity: Error --> Allowed memory size of 1048576000 bytes exhausted (tried to allocate 534790144 bytes) /var/www/html/equizAdmin/application/views/edit_question_1.php 277
ERROR - 2020-01-14 16:45:21 --> Severity: Error --> Allowed memory size of 1048576000 bytes exhausted (tried to allocate 534790144 bytes) /var/www/html/equizAdmin/application/views/edit_question_1.php 277
