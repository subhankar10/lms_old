<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-24 15:46:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 193
ERROR - 2020-03-24 15:47:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 193
ERROR - 2020-03-24 15:47:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 193
ERROR - 2020-03-24 15:47:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 193
ERROR - 2020-03-24 15:48:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 193
ERROR - 2020-03-24 15:48:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 193
ERROR - 2020-03-24 15:52:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 193
ERROR - 2020-03-24 15:52:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-24 15:52:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-24 15:52:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-24 15:52:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-24 15:52:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-24 15:52:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-24 15:52:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-24 15:52:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-24 15:52:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-24 15:52:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-24 15:52:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-24 15:52:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-24 15:52:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-24 15:52:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-24 15:52:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-24 15:52:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-24 15:52:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-24 15:52:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-24 15:52:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-24 15:52:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-24 15:52:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-24 15:52:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-24 15:52:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-24 15:52:40 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-24 15:52:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 193
ERROR - 2020-03-24 15:59:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 193
ERROR - 2020-03-24 16:03:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 193
ERROR - 2020-03-24 16:03:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 193
ERROR - 2020-03-24 16:04:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 193
ERROR - 2020-03-24 16:06:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 193
ERROR - 2020-03-24 16:06:34 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:06:34 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:06:34 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:06:34 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:06:34 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:06:34 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:06:34 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:06:34 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:06:34 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:06:34 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:06:34 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:06:34 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:06:34 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:06:34 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:06:34 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:06:34 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:06:34 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:06:34 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:06:34 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:06:34 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:06:34 --> Query error: Unknown column 'qid' in 'where clause' - Invalid query: select * from kams_students_exam_subscription where qid in (0) 
ERROR - 2020-03-24 16:22:51 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:22:51 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:22:51 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:22:51 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:22:51 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:22:51 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:22:51 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:22:51 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:22:51 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:22:51 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:22:51 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:22:51 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:22:51 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:22:51 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:22:51 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:22:51 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:22:51 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:22:51 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:22:51 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:22:51 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:22:51 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:22:51 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:22:51 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:22:51 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:22:51 --> Query error: Unknown column 'qid' in 'where clause' - Invalid query: select * from kams_students_exam_subscription where qid in (0) 
ERROR - 2020-03-24 16:24:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:24:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:24:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:24:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:24:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:24:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:24:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:24:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:24:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:24:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:24:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:24:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:24:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:24:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:24:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:24:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:24:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:24:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:24:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:24:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:24:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:24:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:24:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:24:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:24:21 --> Query error: Unknown column 'qid' in 'where clause' - Invalid query: select * from kams_students_exam_subscription where qid in (0) 
ERROR - 2020-03-24 16:25:01 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:25:01 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:25:01 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:25:01 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:25:01 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:25:01 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:25:01 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:25:01 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:25:01 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:25:01 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:25:01 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:25:01 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:25:01 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:25:01 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:25:01 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:25:01 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:25:01 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:25:01 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:25:01 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:25:01 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:25:01 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:25:01 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:25:01 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:25:01 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:25:01 --> Query error: Unknown column 'qid' in 'where clause' - Invalid query: select * from kams_students_exam_subscription where qid in (0) 
ERROR - 2020-03-24 16:25:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:25:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:25:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:25:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:25:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:25:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:25:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:25:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:25:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:25:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:25:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:25:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:25:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:25:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:25:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:25:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:25:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:25:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:25:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:25:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:25:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:25:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:25:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:25:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:25:04 --> Query error: Unknown column 'qid' in 'where clause' - Invalid query: select * from kams_students_exam_subscription where qid in (0) 
ERROR - 2020-03-24 16:26:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:26:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:26:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:26:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:26:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:26:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:26:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:26:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:26:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:26:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:26:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:26:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:26:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:26:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:26:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:26:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:26:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:26:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:26:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:26:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:26:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:26:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:26:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:26:04 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:26:04 --> Query error: Unknown column 'qid' in 'where clause' - Invalid query: select * from kams_students_exam_subscription where qid in (0) 
ERROR - 2020-03-24 16:26:41 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:26:41 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:26:41 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:26:41 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:26:41 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:26:41 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:26:41 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:26:41 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:26:41 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:26:41 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:26:41 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:26:41 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:26:41 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:26:41 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:26:41 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:26:41 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:26:41 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:26:41 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:26:41 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:26:41 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:26:41 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:26:41 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:26:41 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:26:41 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:26:41 --> Query error: Unknown column 'qid' in 'where clause' - Invalid query: select * from kams_students_exam_subscription where qid in (0) 
ERROR - 2020-03-24 16:27:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:27:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:27:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:27:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:27:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:27:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:27:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:27:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:27:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:27:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:27:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:27:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:27:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:27:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:27:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:27:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:27:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:27:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:27:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:27:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:27:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:27:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:27:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 70
ERROR - 2020-03-24 16:27:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/controllers/User2.php 82
ERROR - 2020-03-24 16:27:29 --> Query error: Unknown column 'qid' in 'where clause' - Invalid query: select * from kams_students_exam_subscription where qid in (0) 
ERROR - 2020-03-24 16:28:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: select * from kams_students_exam_subscription where qid in () 
ERROR - 2020-03-24 16:30:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: select * from kams_students_exam_subscription where qid in () 
ERROR - 2020-03-24 16:30:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 204
ERROR - 2020-03-24 16:31:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 204
ERROR - 2020-03-24 16:32:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 204
ERROR - 2020-03-24 16:39:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 204
ERROR - 2020-03-24 16:39:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 204
ERROR - 2020-03-24 16:40:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 204
ERROR - 2020-03-24 16:42:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 204
ERROR - 2020-03-24 16:42:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/new_agency.php 73
ERROR - 2020-03-24 16:43:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/new_agency.php 73
ERROR - 2020-03-24 16:46:38 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-24 16:46:38 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-24 16:46:38 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-24 16:46:38 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-24 16:46:43 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-24 16:46:43 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-24 16:46:43 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-24 16:46:43 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-24 16:46:43 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-24 16:46:43 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-24 16:46:43 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-24 16:46:43 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-24 16:48:05 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-24 16:48:05 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-24 16:48:05 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-24 16:48:05 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-24 16:48:06 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-24 16:48:06 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-24 16:48:06 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-24 16:48:06 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-24 16:48:09 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-24 16:48:09 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-24 16:48:09 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-24 16:48:09 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-24 16:48:17 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-24 16:48:17 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-24 16:48:17 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-24 16:48:17 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-24 16:48:31 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-24 16:48:31 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-24 16:48:31 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-24 16:48:31 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-24 16:48:39 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-24 16:48:39 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-24 16:48:39 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-24 16:48:39 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-24 16:48:42 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-24 16:48:42 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-24 16:48:42 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-24 16:48:42 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-24 16:48:48 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-24 16:48:48 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-24 16:48:48 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-24 16:48:48 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-24 17:01:55 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-24 17:01:55 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-24 17:01:55 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-24 17:01:55 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-24 17:02:08 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-24 17:02:08 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-24 17:02:08 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-24 17:02:08 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-24 17:02:12 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-24 17:02:12 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-24 17:02:12 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-24 17:02:12 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-24 17:02:24 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-24 17:02:24 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-24 17:02:24 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-24 17:02:24 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-24 17:02:27 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-24 17:02:27 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-24 17:02:27 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-24 17:02:27 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-24 17:05:02 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-24 17:05:02 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-24 17:05:02 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-24 17:05:02 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-24 17:05:10 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-24 17:05:10 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-24 17:05:10 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-24 17:05:10 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-24 17:05:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/models/Quiz_model.php 272
ERROR - 2020-03-24 17:05:10 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given /var/www/html/equizAdmindesign/application/models/Quiz_model.php 292
ERROR - 2020-03-24 17:05:10 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-24 17:05:10 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-24 17:05:10 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-24 17:05:10 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-24 17:05:15 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-24 17:05:15 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-24 17:05:15 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-24 17:05:15 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-24 17:05:18 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-24 17:05:18 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-24 17:05:18 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-24 17:05:18 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-24 17:05:23 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-24 17:05:23 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-24 17:05:23 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-24 17:05:23 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-24 17:05:24 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-24 17:05:24 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-24 17:05:24 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-24 17:05:24 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-24 17:05:46 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-24 17:05:46 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-24 17:05:46 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-24 17:05:46 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-24 17:05:46 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-24 17:05:46 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-24 17:05:46 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-24 17:05:46 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-24 17:05:49 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-24 17:05:49 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-24 17:05:49 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-24 17:05:49 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-24 17:05:57 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-24 17:05:57 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-24 17:05:57 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-24 17:05:57 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-24 17:05:59 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-24 17:05:59 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-24 17:05:59 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-24 17:05:59 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-24 17:07:06 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmindesign/application/views/view_result.php 400
ERROR - 2020-03-24 17:07:06 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmindesign/application/views/view_result.php 403
ERROR - 2020-03-24 17:07:06 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmindesign/application/views/view_result.php 409
ERROR - 2020-03-24 17:08:06 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmindesign/application/views/view_result.php 400
ERROR - 2020-03-24 17:08:06 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmindesign/application/views/view_result.php 403
ERROR - 2020-03-24 17:08:06 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmindesign/application/views/view_result.php 409
ERROR - 2020-03-24 17:08:22 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmindesign/application/views/view_result.php 400
ERROR - 2020-03-24 17:08:22 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmindesign/application/views/view_result.php 403
ERROR - 2020-03-24 17:08:22 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmindesign/application/views/view_result.php 409
ERROR - 2020-03-24 17:52:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 204
ERROR - 2020-03-24 18:02:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 193
ERROR - 2020-03-24 18:06:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/view_result.php 255
ERROR - 2020-03-24 18:16:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 193
ERROR - 2020-03-24 18:17:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 193
ERROR - 2020-03-24 18:17:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 193
ERROR - 2020-03-24 18:17:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:17:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:17:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:17:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:17:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:17:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:17:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:17:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:17:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:17:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:17:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:17:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:17:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:55 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:57 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:17:57 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:17:57 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:17:57 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:17:57 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:57 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:57 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:57 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:57 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:57 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:57 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:57 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:57 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:57 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:57 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:59 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:17:59 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:17:59 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:17:59 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:17:59 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:59 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:59 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:59 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:59 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:59 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:59 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:59 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:59 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:59 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:17:59 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:18:01 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-24 18:18:01 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-24 18:18:01 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-24 18:18:01 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-24 18:18:01 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:18:01 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:18:01 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:18:01 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:18:01 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:18:01 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:18:01 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:18:01 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:18:01 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:18:01 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:18:01 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:18:01 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:18:01 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:18:01 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:18:01 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:18:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:18:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:18:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:18:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:18:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:18:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:18:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:18:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:18:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:18:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:18:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:18:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:18:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:18:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:18:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:18:08 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:18:08 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:18:08 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:18:08 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:18:08 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:18:08 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:18:08 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:18:08 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:18:08 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:18:08 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:18:08 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:18:08 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:18:08 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:18:08 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:18:08 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-24 18:24:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: select wallet_balance from kams_users where uid = 
ERROR - 2020-03-24 18:24:04 --> Severity: error --> Exception: Call to a member function row_array() on boolean /var/www/html/equizAdmindesign/application/controllers/Dashboard.php 58
ERROR - 2020-03-24 18:24:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: select wallet_balance from kams_users where uid = 
ERROR - 2020-03-24 18:24:09 --> Severity: error --> Exception: Call to a member function row_array() on boolean /var/www/html/equizAdmindesign/application/controllers/Dashboard.php 58
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:12 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: select wallet_balance from kams_users where uid = 
ERROR - 2020-03-24 18:24:14 --> Severity: error --> Exception: Call to a member function row_array() on boolean /var/www/html/equizAdmindesign/application/controllers/Dashboard.php 58
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:27 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:24:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:24:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:25:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:25:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:25:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:25:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:25:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:25:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:25:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:25:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:25:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:25:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:25:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:25:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:25:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:25:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:25:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:25:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:25:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:25:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:25:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:25:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:25:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:25:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:25:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:25:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:25:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:25:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:25:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:25:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:25:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:25:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:25:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:25:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:26:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:26:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:26:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:26:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:26:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:26:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:26:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:26:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:26:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:26:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:26:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:26:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:26:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:26:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:26:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:26:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:26:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:26:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:26:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:26:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:26:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:26:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:26:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:26:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:26:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:26:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:26:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:26:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:26:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:26:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:26:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:26:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:26:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: select wallet_balance from kams_users where uid = 
ERROR - 2020-03-24 18:26:13 --> Severity: error --> Exception: Call to a member function row_array() on boolean /var/www/html/equizAdmindesign/application/controllers/Dashboard.php 58
ERROR - 2020-03-24 18:28:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: select wallet_balance from kams_users where uid = 
ERROR - 2020-03-24 18:28:05 --> Severity: error --> Exception: Call to a member function row_array() on boolean /var/www/html/equizAdmindesign/application/controllers/Dashboard.php 60
ERROR - 2020-03-24 18:29:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: select wallet_balance from kams_users where uid = 
ERROR - 2020-03-24 18:29:14 --> Severity: error --> Exception: Call to a member function row_array() on boolean /var/www/html/equizAdmindesign/application/controllers/Dashboard.php 58
ERROR - 2020-03-24 18:29:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: select wallet_balance from kams_users where uid = 
ERROR - 2020-03-24 18:29:17 --> Severity: error --> Exception: Call to a member function row_array() on boolean /var/www/html/equizAdmindesign/application/controllers/Dashboard.php 58
ERROR - 2020-03-24 18:29:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: select wallet_balance from kams_users where uid = 
ERROR - 2020-03-24 18:29:53 --> Severity: error --> Exception: Call to a member function row_array() on boolean /var/www/html/equizAdmindesign/application/controllers/Dashboard.php 58
ERROR - 2020-03-24 18:30:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: select wallet_balance from kams_users where uid = 
ERROR - 2020-03-24 18:30:32 --> Severity: error --> Exception: Call to a member function row_array() on boolean /var/www/html/equizAdmindesign/application/controllers/Dashboard.php 58
ERROR - 2020-03-24 18:30:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: select wallet_balance from kams_users where uid = 
ERROR - 2020-03-24 18:30:42 --> Severity: error --> Exception: Call to a member function row_array() on boolean /var/www/html/equizAdmindesign/application/controllers/Dashboard.php 58
ERROR - 2020-03-24 18:31:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: select wallet_balance from kams_users where uid = 
ERROR - 2020-03-24 18:31:20 --> Severity: error --> Exception: Call to a member function row_array() on boolean /var/www/html/equizAdmindesign/application/controllers/Dashboard.php 58
ERROR - 2020-03-24 18:31:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: select wallet_balance from kams_users where uid = 
ERROR - 2020-03-24 18:31:23 --> Severity: error --> Exception: Call to a member function row_array() on boolean /var/www/html/equizAdmindesign/application/controllers/Dashboard.php 58
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:31:25 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:31:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: select wallet_balance from kams_users where uid = 
ERROR - 2020-03-24 18:31:27 --> Severity: error --> Exception: Call to a member function row_array() on boolean /var/www/html/equizAdmindesign/application/controllers/Dashboard.php 58
ERROR - 2020-03-24 18:31:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: select wallet_balance from kams_users where uid = 
ERROR - 2020-03-24 18:31:34 --> Severity: error --> Exception: Call to a member function row_array() on boolean /var/www/html/equizAdmindesign/application/controllers/Dashboard.php 58
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:43 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
ERROR - 2020-03-24 18:33:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 7
