<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-13 11:17:03 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 349
ERROR - 2020-03-13 11:17:04 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 362
ERROR - 2020-03-13 11:17:04 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 373
ERROR - 2020-03-13 11:17:04 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 383
ERROR - 2020-03-13 11:17:04 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 396
ERROR - 2020-03-13 11:17:04 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 407
ERROR - 2020-03-13 11:17:04 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 417
ERROR - 2020-03-13 11:17:04 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 430
ERROR - 2020-03-13 11:17:04 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 441
ERROR - 2020-03-13 11:17:04 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 452
ERROR - 2020-03-13 11:17:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 162
ERROR - 2020-03-13 11:17:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 11:17:50 --> Severity: Notice --> Undefined variable: verified_users /var/www/html/equizAdmindesign/application/views/dashboard.php 3
ERROR - 2020-03-13 11:17:50 --> Severity: Notice --> Undefined variable: unverified_users /var/www/html/equizAdmindesign/application/views/dashboard.php 4
ERROR - 2020-03-13 11:17:50 --> Severity: Notice --> Undefined variable: num_users /var/www/html/equizAdmindesign/application/views/dashboard.php 5
ERROR - 2020-03-13 11:17:50 --> Severity: Notice --> Undefined variable: count_pilots /var/www/html/equizAdmindesign/application/views/dashboard.php 9
ERROR - 2020-03-13 11:17:50 --> Severity: Notice --> Undefined variable: count_agents /var/www/html/equizAdmindesign/application/views/dashboard.php 10
ERROR - 2020-03-13 11:17:50 --> Severity: Notice --> Undefined variable: count_atcos /var/www/html/equizAdmindesign/application/views/dashboard.php 11
ERROR - 2020-03-13 11:17:50 --> Severity: Notice --> Undefined variable: count_technicians /var/www/html/equizAdmindesign/application/views/dashboard.php 12
ERROR - 2020-03-13 11:17:50 --> Severity: Notice --> Undefined variable: num_users /var/www/html/equizAdmindesign/application/views/dashboard.php 42
ERROR - 2020-03-13 11:17:50 --> Severity: Notice --> Undefined variable: total_agency /var/www/html/equizAdmindesign/application/views/dashboard.php 61
ERROR - 2020-03-13 11:17:50 --> Severity: Notice --> Undefined variable: total_subscription /var/www/html/equizAdmindesign/application/views/dashboard.php 80
ERROR - 2020-03-13 11:17:50 --> Severity: Notice --> Undefined variable: num_quiz_mock /var/www/html/equizAdmindesign/application/views/dashboard.php 101
ERROR - 2020-03-13 11:17:50 --> Severity: Notice --> Undefined variable: num_quiz_exam /var/www/html/equizAdmindesign/application/views/dashboard.php 120
ERROR - 2020-03-13 11:17:50 --> Severity: Notice --> Undefined variable: num_qbank /var/www/html/equizAdmindesign/application/views/dashboard.php 139
ERROR - 2020-03-13 11:17:50 --> Severity: Notice --> Undefined variable: agency_listing /var/www/html/equizAdmindesign/application/views/dashboard.php 196
ERROR - 2020-03-13 11:17:50 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmindesign/application/views/dashboard.php 196
ERROR - 2020-03-13 11:17:50 --> Severity: Notice --> Undefined variable: agency_listing /var/www/html/equizAdmindesign/application/views/dashboard.php 201
ERROR - 2020-03-13 11:17:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/dashboard.php 201
ERROR - 2020-03-13 11:17:50 --> Severity: Notice --> Undefined variable: verified_users /var/www/html/equizAdmindesign/application/views/dashboard.php 234
ERROR - 2020-03-13 11:17:50 --> Severity: Notice --> Undefined variable: unverified_users /var/www/html/equizAdmindesign/application/views/dashboard.php 234
ERROR - 2020-03-13 11:17:50 --> Severity: Notice --> Undefined variable: num_users /var/www/html/equizAdmindesign/application/views/dashboard.php 234
ERROR - 2020-03-13 11:17:50 --> Severity: Notice --> Undefined variable: count_pilots /var/www/html/equizAdmindesign/application/views/dashboard.php 245
ERROR - 2020-03-13 11:17:50 --> Severity: Notice --> Undefined variable: count_agents /var/www/html/equizAdmindesign/application/views/dashboard.php 245
ERROR - 2020-03-13 11:17:50 --> Severity: Notice --> Undefined variable: count_atcos /var/www/html/equizAdmindesign/application/views/dashboard.php 245
ERROR - 2020-03-13 11:17:50 --> Severity: Notice --> Undefined variable: count_technicians /var/www/html/equizAdmindesign/application/views/dashboard.php 245
ERROR - 2020-03-13 11:19:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 162
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined index: training_center /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined index: training_center /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined index: training_center /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined index: training_center /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined index: training_center /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined index: location_city /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined index: location_city /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined index: location_city /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined index: location /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined index: location /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined index: location /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined index: question_bank /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined index: question_bank /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined index: question_bank /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined index: exam /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined index: exam /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined index: exam /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined index: transaction_listing /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined index: mock_exam_result_list /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined index: mock_exam_result_list /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined index: mock_exam_result_list /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined index: result_list /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined index: result_list /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined index: result_list /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined index: student_exam_registration /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined index: student_exam_registration /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined variable: verified_users /var/www/html/equizAdmindesign/application/views/dashboard.php 3
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined variable: unverified_users /var/www/html/equizAdmindesign/application/views/dashboard.php 4
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined variable: num_users /var/www/html/equizAdmindesign/application/views/dashboard.php 5
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined variable: count_pilots /var/www/html/equizAdmindesign/application/views/dashboard.php 9
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined variable: count_agents /var/www/html/equizAdmindesign/application/views/dashboard.php 10
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined variable: count_atcos /var/www/html/equizAdmindesign/application/views/dashboard.php 11
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined variable: count_technicians /var/www/html/equizAdmindesign/application/views/dashboard.php 12
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined variable: num_users /var/www/html/equizAdmindesign/application/views/dashboard.php 42
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined variable: total_agency /var/www/html/equizAdmindesign/application/views/dashboard.php 61
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined variable: total_subscription /var/www/html/equizAdmindesign/application/views/dashboard.php 80
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined variable: num_quiz_mock /var/www/html/equizAdmindesign/application/views/dashboard.php 101
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined variable: num_quiz_exam /var/www/html/equizAdmindesign/application/views/dashboard.php 120
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined variable: num_qbank /var/www/html/equizAdmindesign/application/views/dashboard.php 139
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined variable: agency_listing /var/www/html/equizAdmindesign/application/views/dashboard.php 196
ERROR - 2020-03-13 11:19:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmindesign/application/views/dashboard.php 196
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined variable: agency_listing /var/www/html/equizAdmindesign/application/views/dashboard.php 201
ERROR - 2020-03-13 11:19:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/dashboard.php 201
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined variable: verified_users /var/www/html/equizAdmindesign/application/views/dashboard.php 234
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined variable: unverified_users /var/www/html/equizAdmindesign/application/views/dashboard.php 234
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined variable: num_users /var/www/html/equizAdmindesign/application/views/dashboard.php 234
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined variable: count_pilots /var/www/html/equizAdmindesign/application/views/dashboard.php 245
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined variable: count_agents /var/www/html/equizAdmindesign/application/views/dashboard.php 245
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined variable: count_atcos /var/www/html/equizAdmindesign/application/views/dashboard.php 245
ERROR - 2020-03-13 11:19:34 --> Severity: Notice --> Undefined variable: count_technicians /var/www/html/equizAdmindesign/application/views/dashboard.php 245
ERROR - 2020-03-13 11:19:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 162
ERROR - 2020-03-13 11:20:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 162
ERROR - 2020-03-13 11:20:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 162
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined index: training_center /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined index: training_center /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined index: training_center /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined index: training_center /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined index: training_center /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined index: location_city /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined index: location_city /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined index: location_city /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined index: location /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined index: location /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined index: location /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined index: question_bank /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined index: question_bank /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined index: question_bank /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined index: exam /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined index: exam /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined index: exam /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined index: transaction_listing /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined index: mock_exam_result_list /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined index: mock_exam_result_list /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined index: mock_exam_result_list /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined index: result_list /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined index: result_list /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined index: result_list /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined index: student_exam_registration /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined index: student_exam_registration /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined variable: verified_users /var/www/html/equizAdmindesign/application/views/dashboard.php 3
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined variable: unverified_users /var/www/html/equizAdmindesign/application/views/dashboard.php 4
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined variable: num_users /var/www/html/equizAdmindesign/application/views/dashboard.php 5
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined variable: count_pilots /var/www/html/equizAdmindesign/application/views/dashboard.php 9
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined variable: count_agents /var/www/html/equizAdmindesign/application/views/dashboard.php 10
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined variable: count_atcos /var/www/html/equizAdmindesign/application/views/dashboard.php 11
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined variable: count_technicians /var/www/html/equizAdmindesign/application/views/dashboard.php 12
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined variable: num_users /var/www/html/equizAdmindesign/application/views/dashboard.php 42
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined variable: total_agency /var/www/html/equizAdmindesign/application/views/dashboard.php 61
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined variable: total_subscription /var/www/html/equizAdmindesign/application/views/dashboard.php 80
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined variable: num_quiz_mock /var/www/html/equizAdmindesign/application/views/dashboard.php 101
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined variable: num_quiz_exam /var/www/html/equizAdmindesign/application/views/dashboard.php 120
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined variable: num_qbank /var/www/html/equizAdmindesign/application/views/dashboard.php 139
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined variable: agency_listing /var/www/html/equizAdmindesign/application/views/dashboard.php 196
ERROR - 2020-03-13 11:20:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmindesign/application/views/dashboard.php 196
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined variable: agency_listing /var/www/html/equizAdmindesign/application/views/dashboard.php 201
ERROR - 2020-03-13 11:20:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/dashboard.php 201
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined variable: verified_users /var/www/html/equizAdmindesign/application/views/dashboard.php 234
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined variable: unverified_users /var/www/html/equizAdmindesign/application/views/dashboard.php 234
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined variable: num_users /var/www/html/equizAdmindesign/application/views/dashboard.php 234
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined variable: count_pilots /var/www/html/equizAdmindesign/application/views/dashboard.php 245
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined variable: count_agents /var/www/html/equizAdmindesign/application/views/dashboard.php 245
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined variable: count_atcos /var/www/html/equizAdmindesign/application/views/dashboard.php 245
ERROR - 2020-03-13 11:20:34 --> Severity: Notice --> Undefined variable: count_technicians /var/www/html/equizAdmindesign/application/views/dashboard.php 245
ERROR - 2020-03-13 11:21:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 162
ERROR - 2020-03-13 11:21:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 11:21:32 --> Severity: Notice --> Undefined variable: verified_users /var/www/html/equizAdmindesign/application/views/dashboard.php 3
ERROR - 2020-03-13 11:21:32 --> Severity: Notice --> Undefined variable: unverified_users /var/www/html/equizAdmindesign/application/views/dashboard.php 4
ERROR - 2020-03-13 11:21:32 --> Severity: Notice --> Undefined variable: num_users /var/www/html/equizAdmindesign/application/views/dashboard.php 5
ERROR - 2020-03-13 11:21:32 --> Severity: Notice --> Undefined variable: count_pilots /var/www/html/equizAdmindesign/application/views/dashboard.php 9
ERROR - 2020-03-13 11:21:32 --> Severity: Notice --> Undefined variable: count_agents /var/www/html/equizAdmindesign/application/views/dashboard.php 10
ERROR - 2020-03-13 11:21:32 --> Severity: Notice --> Undefined variable: count_atcos /var/www/html/equizAdmindesign/application/views/dashboard.php 11
ERROR - 2020-03-13 11:21:32 --> Severity: Notice --> Undefined variable: count_technicians /var/www/html/equizAdmindesign/application/views/dashboard.php 12
ERROR - 2020-03-13 11:21:32 --> Severity: Notice --> Undefined variable: num_users /var/www/html/equizAdmindesign/application/views/dashboard.php 42
ERROR - 2020-03-13 11:21:32 --> Severity: Notice --> Undefined variable: total_agency /var/www/html/equizAdmindesign/application/views/dashboard.php 61
ERROR - 2020-03-13 11:21:32 --> Severity: Notice --> Undefined variable: total_subscription /var/www/html/equizAdmindesign/application/views/dashboard.php 80
ERROR - 2020-03-13 11:21:32 --> Severity: Notice --> Undefined variable: num_quiz_mock /var/www/html/equizAdmindesign/application/views/dashboard.php 101
ERROR - 2020-03-13 11:21:32 --> Severity: Notice --> Undefined variable: num_quiz_exam /var/www/html/equizAdmindesign/application/views/dashboard.php 120
ERROR - 2020-03-13 11:21:32 --> Severity: Notice --> Undefined variable: num_qbank /var/www/html/equizAdmindesign/application/views/dashboard.php 139
ERROR - 2020-03-13 11:21:32 --> Severity: Notice --> Undefined variable: agency_listing /var/www/html/equizAdmindesign/application/views/dashboard.php 196
ERROR - 2020-03-13 11:21:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmindesign/application/views/dashboard.php 196
ERROR - 2020-03-13 11:21:32 --> Severity: Notice --> Undefined variable: agency_listing /var/www/html/equizAdmindesign/application/views/dashboard.php 201
ERROR - 2020-03-13 11:21:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/dashboard.php 201
ERROR - 2020-03-13 11:21:32 --> Severity: Notice --> Undefined variable: verified_users /var/www/html/equizAdmindesign/application/views/dashboard.php 234
ERROR - 2020-03-13 11:21:32 --> Severity: Notice --> Undefined variable: unverified_users /var/www/html/equizAdmindesign/application/views/dashboard.php 234
ERROR - 2020-03-13 11:21:32 --> Severity: Notice --> Undefined variable: num_users /var/www/html/equizAdmindesign/application/views/dashboard.php 234
ERROR - 2020-03-13 11:21:32 --> Severity: Notice --> Undefined variable: count_pilots /var/www/html/equizAdmindesign/application/views/dashboard.php 245
ERROR - 2020-03-13 11:21:32 --> Severity: Notice --> Undefined variable: count_agents /var/www/html/equizAdmindesign/application/views/dashboard.php 245
ERROR - 2020-03-13 11:21:32 --> Severity: Notice --> Undefined variable: count_atcos /var/www/html/equizAdmindesign/application/views/dashboard.php 245
ERROR - 2020-03-13 11:21:32 --> Severity: Notice --> Undefined variable: count_technicians /var/www/html/equizAdmindesign/application/views/dashboard.php 245
ERROR - 2020-03-13 11:22:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 163
ERROR - 2020-03-13 11:22:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 11:22:24 --> Severity: Notice --> Undefined variable: verified_users /var/www/html/equizAdmindesign/application/views/dashboard.php 3
ERROR - 2020-03-13 11:22:24 --> Severity: Notice --> Undefined variable: unverified_users /var/www/html/equizAdmindesign/application/views/dashboard.php 4
ERROR - 2020-03-13 11:22:24 --> Severity: Notice --> Undefined variable: num_users /var/www/html/equizAdmindesign/application/views/dashboard.php 5
ERROR - 2020-03-13 11:22:24 --> Severity: Notice --> Undefined variable: count_pilots /var/www/html/equizAdmindesign/application/views/dashboard.php 9
ERROR - 2020-03-13 11:22:24 --> Severity: Notice --> Undefined variable: count_agents /var/www/html/equizAdmindesign/application/views/dashboard.php 10
ERROR - 2020-03-13 11:22:24 --> Severity: Notice --> Undefined variable: count_atcos /var/www/html/equizAdmindesign/application/views/dashboard.php 11
ERROR - 2020-03-13 11:22:24 --> Severity: Notice --> Undefined variable: count_technicians /var/www/html/equizAdmindesign/application/views/dashboard.php 12
ERROR - 2020-03-13 11:22:24 --> Severity: Notice --> Undefined variable: num_users /var/www/html/equizAdmindesign/application/views/dashboard.php 42
ERROR - 2020-03-13 11:22:24 --> Severity: Notice --> Undefined variable: total_agency /var/www/html/equizAdmindesign/application/views/dashboard.php 61
ERROR - 2020-03-13 11:22:24 --> Severity: Notice --> Undefined variable: total_subscription /var/www/html/equizAdmindesign/application/views/dashboard.php 80
ERROR - 2020-03-13 11:22:24 --> Severity: Notice --> Undefined variable: num_quiz_mock /var/www/html/equizAdmindesign/application/views/dashboard.php 101
ERROR - 2020-03-13 11:22:24 --> Severity: Notice --> Undefined variable: num_quiz_exam /var/www/html/equizAdmindesign/application/views/dashboard.php 120
ERROR - 2020-03-13 11:22:24 --> Severity: Notice --> Undefined variable: num_qbank /var/www/html/equizAdmindesign/application/views/dashboard.php 139
ERROR - 2020-03-13 11:22:24 --> Severity: Notice --> Undefined variable: agency_listing /var/www/html/equizAdmindesign/application/views/dashboard.php 196
ERROR - 2020-03-13 11:22:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmindesign/application/views/dashboard.php 196
ERROR - 2020-03-13 11:22:24 --> Severity: Notice --> Undefined variable: agency_listing /var/www/html/equizAdmindesign/application/views/dashboard.php 201
ERROR - 2020-03-13 11:22:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/dashboard.php 201
ERROR - 2020-03-13 11:22:24 --> Severity: Notice --> Undefined variable: verified_users /var/www/html/equizAdmindesign/application/views/dashboard.php 234
ERROR - 2020-03-13 11:22:24 --> Severity: Notice --> Undefined variable: unverified_users /var/www/html/equizAdmindesign/application/views/dashboard.php 234
ERROR - 2020-03-13 11:22:24 --> Severity: Notice --> Undefined variable: num_users /var/www/html/equizAdmindesign/application/views/dashboard.php 234
ERROR - 2020-03-13 11:22:24 --> Severity: Notice --> Undefined variable: count_pilots /var/www/html/equizAdmindesign/application/views/dashboard.php 245
ERROR - 2020-03-13 11:22:24 --> Severity: Notice --> Undefined variable: count_agents /var/www/html/equizAdmindesign/application/views/dashboard.php 245
ERROR - 2020-03-13 11:22:24 --> Severity: Notice --> Undefined variable: count_atcos /var/www/html/equizAdmindesign/application/views/dashboard.php 245
ERROR - 2020-03-13 11:22:24 --> Severity: Notice --> Undefined variable: count_technicians /var/www/html/equizAdmindesign/application/views/dashboard.php 245
ERROR - 2020-03-13 11:23:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 163
ERROR - 2020-03-13 11:23:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 163
ERROR - 2020-03-13 11:24:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 163
ERROR - 2020-03-13 11:24:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 163
ERROR - 2020-03-13 11:25:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 163
ERROR - 2020-03-13 11:25:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 11:25:28 --> Severity: Notice --> Undefined variable: verified_users /var/www/html/equizAdmindesign/application/views/dashboard.php 3
ERROR - 2020-03-13 11:25:28 --> Severity: Notice --> Undefined variable: unverified_users /var/www/html/equizAdmindesign/application/views/dashboard.php 4
ERROR - 2020-03-13 11:25:28 --> Severity: Notice --> Undefined variable: num_users /var/www/html/equizAdmindesign/application/views/dashboard.php 5
ERROR - 2020-03-13 11:25:28 --> Severity: Notice --> Undefined variable: count_pilots /var/www/html/equizAdmindesign/application/views/dashboard.php 9
ERROR - 2020-03-13 11:25:28 --> Severity: Notice --> Undefined variable: count_agents /var/www/html/equizAdmindesign/application/views/dashboard.php 10
ERROR - 2020-03-13 11:25:28 --> Severity: Notice --> Undefined variable: count_atcos /var/www/html/equizAdmindesign/application/views/dashboard.php 11
ERROR - 2020-03-13 11:25:28 --> Severity: Notice --> Undefined variable: count_technicians /var/www/html/equizAdmindesign/application/views/dashboard.php 12
ERROR - 2020-03-13 11:25:28 --> Severity: Notice --> Undefined variable: num_users /var/www/html/equizAdmindesign/application/views/dashboard.php 42
ERROR - 2020-03-13 11:25:28 --> Severity: Notice --> Undefined variable: total_agency /var/www/html/equizAdmindesign/application/views/dashboard.php 61
ERROR - 2020-03-13 11:25:28 --> Severity: Notice --> Undefined variable: total_subscription /var/www/html/equizAdmindesign/application/views/dashboard.php 80
ERROR - 2020-03-13 11:25:28 --> Severity: Notice --> Undefined variable: num_quiz_mock /var/www/html/equizAdmindesign/application/views/dashboard.php 101
ERROR - 2020-03-13 11:25:28 --> Severity: Notice --> Undefined variable: num_quiz_exam /var/www/html/equizAdmindesign/application/views/dashboard.php 120
ERROR - 2020-03-13 11:25:28 --> Severity: Notice --> Undefined variable: num_qbank /var/www/html/equizAdmindesign/application/views/dashboard.php 139
ERROR - 2020-03-13 11:25:28 --> Severity: Notice --> Undefined variable: agency_listing /var/www/html/equizAdmindesign/application/views/dashboard.php 196
ERROR - 2020-03-13 11:25:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmindesign/application/views/dashboard.php 196
ERROR - 2020-03-13 11:25:28 --> Severity: Notice --> Undefined variable: agency_listing /var/www/html/equizAdmindesign/application/views/dashboard.php 201
ERROR - 2020-03-13 11:25:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/dashboard.php 201
ERROR - 2020-03-13 11:25:28 --> Severity: Notice --> Undefined variable: verified_users /var/www/html/equizAdmindesign/application/views/dashboard.php 234
ERROR - 2020-03-13 11:25:28 --> Severity: Notice --> Undefined variable: unverified_users /var/www/html/equizAdmindesign/application/views/dashboard.php 234
ERROR - 2020-03-13 11:25:28 --> Severity: Notice --> Undefined variable: num_users /var/www/html/equizAdmindesign/application/views/dashboard.php 234
ERROR - 2020-03-13 11:25:28 --> Severity: Notice --> Undefined variable: count_pilots /var/www/html/equizAdmindesign/application/views/dashboard.php 245
ERROR - 2020-03-13 11:25:28 --> Severity: Notice --> Undefined variable: count_agents /var/www/html/equizAdmindesign/application/views/dashboard.php 245
ERROR - 2020-03-13 11:25:28 --> Severity: Notice --> Undefined variable: count_atcos /var/www/html/equizAdmindesign/application/views/dashboard.php 245
ERROR - 2020-03-13 11:25:28 --> Severity: Notice --> Undefined variable: count_technicians /var/www/html/equizAdmindesign/application/views/dashboard.php 245
ERROR - 2020-03-13 11:25:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 163
ERROR - 2020-03-13 11:26:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 163
ERROR - 2020-03-13 11:30:39 --> Severity: Notice --> Undefined index: training_center /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Notice --> Undefined index: training_center /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Notice --> Undefined index: training_center /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Notice --> Undefined index: training_center /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Notice --> Undefined index: training_center /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Notice --> Undefined index: location_city /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Notice --> Undefined index: location_city /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Notice --> Undefined index: location_city /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Notice --> Undefined index: location /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Notice --> Undefined index: location /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Notice --> Undefined index: location /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Notice --> Undefined index: question_bank /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Notice --> Undefined index: question_bank /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Notice --> Undefined index: question_bank /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Notice --> Undefined index: exam /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Notice --> Undefined index: exam /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Notice --> Undefined index: exam /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Notice --> Undefined index: transaction_listing /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Notice --> Undefined index: mock_exam_result_list /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Notice --> Undefined index: mock_exam_result_list /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Notice --> Undefined index: mock_exam_result_list /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Notice --> Undefined index: result_list /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Notice --> Undefined index: result_list /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Notice --> Undefined index: result_list /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Notice --> Undefined index: student_exam_registration /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Notice --> Undefined index: student_exam_registration /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:30:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 167
ERROR - 2020-03-13 11:35:22 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 356
ERROR - 2020-03-13 11:35:22 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 369
ERROR - 2020-03-13 11:35:22 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 380
ERROR - 2020-03-13 11:35:22 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 390
ERROR - 2020-03-13 11:35:22 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 403
ERROR - 2020-03-13 11:35:22 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 414
ERROR - 2020-03-13 11:35:22 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 424
ERROR - 2020-03-13 11:35:22 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 437
ERROR - 2020-03-13 11:35:22 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 448
ERROR - 2020-03-13 11:35:22 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 459
ERROR - 2020-03-13 11:35:26 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 356
ERROR - 2020-03-13 11:35:26 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 369
ERROR - 2020-03-13 11:35:26 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 380
ERROR - 2020-03-13 11:35:26 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 390
ERROR - 2020-03-13 11:35:26 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 403
ERROR - 2020-03-13 11:35:26 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 414
ERROR - 2020-03-13 11:35:26 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 424
ERROR - 2020-03-13 11:35:26 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 437
ERROR - 2020-03-13 11:35:26 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 448
ERROR - 2020-03-13 11:35:26 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 459
ERROR - 2020-03-13 11:35:28 --> Severity: Notice --> Undefined index: per_page /var/www/html/equizAdmindesign/application/controllers/Management_user.php 96
ERROR - 2020-03-13 11:35:28 --> Severity: Notice --> Undefined variable: start /var/www/html/equizAdmindesign/application/controllers/Management_user.php 96
ERROR - 2020-03-13 11:35:28 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 356
ERROR - 2020-03-13 11:35:28 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 369
ERROR - 2020-03-13 11:35:28 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 380
ERROR - 2020-03-13 11:35:28 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 390
ERROR - 2020-03-13 11:35:28 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 403
ERROR - 2020-03-13 11:35:28 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 414
ERROR - 2020-03-13 11:35:28 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 424
ERROR - 2020-03-13 11:35:28 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 437
ERROR - 2020-03-13 11:35:28 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 448
ERROR - 2020-03-13 11:35:28 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 459
ERROR - 2020-03-13 11:35:28 --> Severity: Notice --> Undefined index: username /var/www/html/equizAdmindesign/application/views/management_user_list.php 32
ERROR - 2020-03-13 11:35:28 --> Severity: Notice --> Undefined index: email /var/www/html/equizAdmindesign/application/views/management_user_list.php 33
ERROR - 2020-03-13 11:35:28 --> Severity: Notice --> Undefined index: phone /var/www/html/equizAdmindesign/application/views/management_user_list.php 34
ERROR - 2020-03-13 11:35:28 --> Severity: Notice --> Undefined variable: exam_category /var/www/html/equizAdmindesign/application/views/management_user_list.php 75
ERROR - 2020-03-13 11:35:28 --> Severity: Notice --> Undefined variable: students_list /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-13 11:35:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-13 12:06:29 --> Severity: Notice --> Undefined index: per_page /var/www/html/equizAdmindesign/application/controllers/Management_user.php 96
ERROR - 2020-03-13 12:06:29 --> Severity: Notice --> Undefined variable: start /var/www/html/equizAdmindesign/application/controllers/Management_user.php 96
ERROR - 2020-03-13 12:06:29 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 356
ERROR - 2020-03-13 12:06:29 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 369
ERROR - 2020-03-13 12:06:29 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 380
ERROR - 2020-03-13 12:06:29 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 390
ERROR - 2020-03-13 12:06:29 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 403
ERROR - 2020-03-13 12:06:29 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 414
ERROR - 2020-03-13 12:06:29 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 424
ERROR - 2020-03-13 12:06:29 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 437
ERROR - 2020-03-13 12:06:29 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 448
ERROR - 2020-03-13 12:06:29 --> Severity: Notice --> Undefined variable: show_management_menu /var/www/html/equizAdmindesign/application/views/header.php 459
ERROR - 2020-03-13 12:06:29 --> Severity: Notice --> Undefined index: username /var/www/html/equizAdmindesign/application/views/management_user_list.php 32
ERROR - 2020-03-13 12:06:29 --> Severity: Notice --> Undefined index: email /var/www/html/equizAdmindesign/application/views/management_user_list.php 33
ERROR - 2020-03-13 12:06:29 --> Severity: Notice --> Undefined index: phone /var/www/html/equizAdmindesign/application/views/management_user_list.php 34
ERROR - 2020-03-13 12:06:29 --> Severity: Notice --> Undefined variable: exam_category /var/www/html/equizAdmindesign/application/views/management_user_list.php 75
ERROR - 2020-03-13 12:06:29 --> Severity: Notice --> Undefined variable: students_list /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-13 12:06:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-13 12:08:21 --> Severity: Notice --> Undefined index: per_page /var/www/html/equizAdmindesign/application/controllers/Management_user.php 96
ERROR - 2020-03-13 12:08:21 --> Severity: Notice --> Undefined variable: start /var/www/html/equizAdmindesign/application/controllers/Management_user.php 96
ERROR - 2020-03-13 12:08:21 --> Severity: Notice --> Undefined index: username /var/www/html/equizAdmindesign/application/views/management_user_list.php 32
ERROR - 2020-03-13 12:08:21 --> Severity: Notice --> Undefined index: email /var/www/html/equizAdmindesign/application/views/management_user_list.php 33
ERROR - 2020-03-13 12:08:21 --> Severity: Notice --> Undefined index: phone /var/www/html/equizAdmindesign/application/views/management_user_list.php 34
ERROR - 2020-03-13 12:08:21 --> Severity: Notice --> Undefined variable: exam_category /var/www/html/equizAdmindesign/application/views/management_user_list.php 75
ERROR - 2020-03-13 12:08:21 --> Severity: Notice --> Undefined variable: students_list /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-13 12:08:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-13 12:09:15 --> Severity: Notice --> Undefined variable: start /var/www/html/equizAdmindesign/application/controllers/Management_user.php 97
ERROR - 2020-03-13 12:09:15 --> Severity: Notice --> Undefined index: username /var/www/html/equizAdmindesign/application/views/management_user_list.php 32
ERROR - 2020-03-13 12:09:15 --> Severity: Notice --> Undefined index: email /var/www/html/equizAdmindesign/application/views/management_user_list.php 33
ERROR - 2020-03-13 12:09:15 --> Severity: Notice --> Undefined index: phone /var/www/html/equizAdmindesign/application/views/management_user_list.php 34
ERROR - 2020-03-13 12:09:15 --> Severity: Notice --> Undefined variable: exam_category /var/www/html/equizAdmindesign/application/views/management_user_list.php 75
ERROR - 2020-03-13 12:09:15 --> Severity: Notice --> Undefined variable: students_list /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-13 12:09:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-13 12:09:18 --> Severity: Notice --> Undefined variable: start /var/www/html/equizAdmindesign/application/controllers/Management_user.php 97
ERROR - 2020-03-13 12:09:18 --> Severity: Notice --> Undefined index: username /var/www/html/equizAdmindesign/application/views/management_user_list.php 32
ERROR - 2020-03-13 12:09:18 --> Severity: Notice --> Undefined index: email /var/www/html/equizAdmindesign/application/views/management_user_list.php 33
ERROR - 2020-03-13 12:09:18 --> Severity: Notice --> Undefined index: phone /var/www/html/equizAdmindesign/application/views/management_user_list.php 34
ERROR - 2020-03-13 12:09:18 --> Severity: Notice --> Undefined variable: exam_category /var/www/html/equizAdmindesign/application/views/management_user_list.php 75
ERROR - 2020-03-13 12:09:18 --> Severity: Notice --> Undefined variable: students_list /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-13 12:09:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-13 12:10:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-13 12:11:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-13 12:12:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-13 12:12:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 165
ERROR - 2020-03-13 12:12:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 4
ERROR - 2020-03-13 12:12:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmindesign/application/views/dashboard.php 196
ERROR - 2020-03-13 12:12:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/dashboard.php 201
ERROR - 2020-03-13 12:12:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 165
ERROR - 2020-03-13 12:13:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 165
ERROR - 2020-03-13 12:13:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 165
ERROR - 2020-03-13 12:14:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 165
ERROR - 2020-03-13 12:14:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 165
ERROR - 2020-03-13 12:16:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmindesign/application/views/dashboard.php 196
ERROR - 2020-03-13 12:16:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/dashboard.php 201
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 166
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmindesign/application/views/dashboard.php 196
ERROR - 2020-03-13 12:16:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/dashboard.php 201
ERROR - 2020-03-13 13:04:22 --> Severity: error --> Exception: Call to a member function load() on null /var/www/html/equizAdmindesign/application/config/menudata.php 2
ERROR - 2020-03-13 13:16:57 --> Severity: error --> Exception: Call to a member function load() on null /var/www/html/equizAdmindesign/application/config/menudata.php 2
ERROR - 2020-03-13 13:19:51 --> Severity: error --> Exception: Call to a member function load() on null /var/www/html/equizAdmindesign/application/config/menudata.php 2
ERROR - 2020-03-13 13:20:06 --> Severity: error --> Exception: Call to a member function load() on null /var/www/html/equizAdmindesign/application/config/menudata.php 2
ERROR - 2020-03-13 13:20:33 --> Severity: error --> Exception: Call to a member function load() on null /var/www/html/equizAdmindesign/application/config/menudata.php 2
ERROR - 2020-03-13 13:22:28 --> Severity: error --> Exception: Call to a member function load() on null /var/www/html/equizAdmindesign/application/config/menudata.php 2
ERROR - 2020-03-13 13:27:50 --> Severity: error --> Exception: Call to a member function load() on null /var/www/html/equizAdmindesign/application/config/menudata.php 2
ERROR - 2020-03-13 13:28:18 --> Severity: error --> Exception: Call to a member function load() on null /var/www/html/equizAdmindesign/application/config/menudata.php 2
ERROR - 2020-03-13 13:28:26 --> Severity: error --> Exception: Call to a member function load() on null /var/www/html/equizAdmindesign/application/config/menudata.php 2
ERROR - 2020-03-13 13:28:28 --> Severity: error --> Exception: Call to a member function load() on null /var/www/html/equizAdmindesign/application/config/menudata.php 2
ERROR - 2020-03-13 13:28:46 --> Severity: error --> Exception: Call to a member function load() on null /var/www/html/equizAdmindesign/application/config/menudata.php 2
ERROR - 2020-03-13 13:29:14 --> Severity: error --> Exception: Call to a member function load() on null /var/www/html/equizAdmindesign/application/config/menudata.php 2
ERROR - 2020-03-13 13:29:16 --> Severity: error --> Exception: Call to a member function load() on null /var/www/html/equizAdmindesign/application/config/menudata.php 2
ERROR - 2020-03-13 15:12:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-13 15:12:28 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 15:12:28 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 15:12:28 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 15:12:28 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 15:12:28 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 15:12:28 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 15:12:28 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 15:12:28 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 15:12:28 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 15:12:28 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 15:12:28 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 15:12:28 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 15:12:28 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 15:12:28 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 15:12:28 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 15:12:28 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 15:12:28 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 15:12:28 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 15:12:28 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 15:12:28 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 15:12:28 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 15:12:28 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 15:12:28 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 15:12:28 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 15:12:28 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 15:12:28 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 15:14:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 188
ERROR - 2020-03-13 15:35:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-13 15:35:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:35:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:35:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:35:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:35:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:35:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:35:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:35:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:35:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:35:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:35:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:35:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:35:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:35:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:35:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:35:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:35:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:35:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:35:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:35:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:35:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:35:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:35:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:35:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:35:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:35:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:36:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:36:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:36:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:36:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:36:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:36:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:36:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:36:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:36:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:36:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:36:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:36:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:36:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:36:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:36:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:36:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:36:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:36:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:36:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:36:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:36:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:36:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:36:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:36:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:36:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:36:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:40:26 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:17 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:20 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:41:42 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:42 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:42 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:42 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:42 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:42 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:42 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:42 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:42 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:42 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:42 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:42 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:42 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:42 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:42 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:42 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:42 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:42 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:42 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:42 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:42 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:42 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:42 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:42 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:42 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:41:42 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:05 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 15:42:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 7
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:24 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:42:50 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 15:43:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 6
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmindesign/application/views/dashboard.php 196
ERROR - 2020-03-13 16:08:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/dashboard.php 201
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmindesign/application/views/dashboard.php 196
ERROR - 2020-03-13 17:10:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/dashboard.php 201
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:10:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/header.php 169
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:11:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/admin_management_menu.php 5
ERROR - 2020-03-13 17:12:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:12:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:12:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:12:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:12:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:12:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:12:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:12:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:12:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:12:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:12:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:12:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:12:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:12:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:12:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:12:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:12:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:12:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:12:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:12:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:12:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:12:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:12:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:12:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:12:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:12:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:21:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:21:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:21:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:21:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:21:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:21:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:21:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:21:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:21:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:21:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:21:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:21:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:21:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:21:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:21:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:21:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:21:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:21:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:21:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:21:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:21:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:21:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:21:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:21:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:21:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-13 17:21:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
