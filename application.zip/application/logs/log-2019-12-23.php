<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-23 12:13:04 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 263
ERROR - 2019-12-23 12:16:01 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 264
ERROR - 2019-12-23 12:17:11 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/equiz/application/models/User_model.php 229
ERROR - 2019-12-23 12:17:38 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/equiz/application/models/User_model.php 230
ERROR - 2019-12-23 12:18:17 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 263
ERROR - 2019-12-23 12:25:39 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 263
ERROR - 2019-12-23 12:27:57 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 263
ERROR - 2019-12-23 12:31:30 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 263
ERROR - 2019-12-23 13:10:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 175
ERROR - 2019-12-23 13:10:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 264
ERROR - 2019-12-23 13:10:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 175
ERROR - 2019-12-23 13:10:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 264
ERROR - 2019-12-23 13:11:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 174
ERROR - 2019-12-23 13:11:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 263
ERROR - 2019-12-23 13:11:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 174
ERROR - 2019-12-23 13:11:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 263
ERROR - 2019-12-23 13:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 174
ERROR - 2019-12-23 13:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 263
ERROR - 2019-12-23 13:19:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 174
ERROR - 2019-12-23 13:19:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 263
ERROR - 2019-12-23 13:19:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 174
ERROR - 2019-12-23 13:19:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 263
