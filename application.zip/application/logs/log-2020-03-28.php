<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-28 21:26:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/models/User_model.php 414
ERROR - 2020-03-28 21:26:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/models/User_model.php 414
ERROR - 2020-03-28 21:27:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/onlineclassroom/application/views/dashboard.php 197
ERROR - 2020-03-28 21:27:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/dashboard.php 202
ERROR - 2020-03-28 21:27:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IS NULL' at line 7 - Invalid query: SELECT `q`.`quiz_name`, `q`.`quiz_price`, `s`.*, CONCAT(ust.first_name, " ", ust.last_name) AS student_name, CONCAT(ue.first_name, " ", ue.last_name) AS examiner_name, CONCAT(us.first_name, " ", us.last_name) AS scorer_name
FROM `kams_students_exam_subscription` `s`
LEFT JOIN `kams_quiz` `q` ON `q`.`quid` = `s`.`quiz_id`
LEFT JOIN `kams_users` `ue` ON `ue`.`uid` = `s`.`examiner_id`
LEFT JOIN `kams_users` `us` ON `us`.`uid` = `s`.`scorer_id`
LEFT JOIN `kams_users` `ust` ON `ust`.`uid` = `s`.`student_id`
WHERE  IS NULL
ERROR - 2020-03-28 21:27:15 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/onlineclassroom/application/controllers/Student_subscriptionexam.php 90
ERROR - 2020-03-28 21:27:21 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/onlineclassroom/application/views/dashboard.php 197
ERROR - 2020-03-28 21:27:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/dashboard.php 202
