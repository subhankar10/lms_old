<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-04 10:18:56 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-02-04 10:38:29 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-02-04 10:38:43 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-02-04 10:39:00 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-02-04 10:39:17 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-02-04 12:41:12 --> Severity: Warning --> Illegal string offset 'id_city' /var/www/html/equizAdmin/application/views/new_examiner.php 97
ERROR - 2020-02-04 12:41:12 --> Severity: Warning --> Illegal string offset 'city_name' /var/www/html/equizAdmin/application/views/new_examiner.php 97
ERROR - 2020-02-04 12:41:12 --> Severity: Warning --> Illegal string offset 'id_city' /var/www/html/equizAdmin/application/views/new_examiner.php 97
ERROR - 2020-02-04 12:41:12 --> Severity: Warning --> Illegal string offset 'city_name' /var/www/html/equizAdmin/application/views/new_examiner.php 97
ERROR - 2020-02-04 12:41:42 --> Severity: Warning --> Illegal string offset 'id_city' /var/www/html/equizAdmin/application/views/new_examiner.php 97
ERROR - 2020-02-04 12:41:42 --> Severity: Warning --> Illegal string offset 'city_name' /var/www/html/equizAdmin/application/views/new_examiner.php 97
ERROR - 2020-02-04 12:41:42 --> Severity: Warning --> Illegal string offset 'id_city' /var/www/html/equizAdmin/application/views/new_examiner.php 97
ERROR - 2020-02-04 12:41:42 --> Severity: Warning --> Illegal string offset 'city_name' /var/www/html/equizAdmin/application/views/new_examiner.php 97
ERROR - 2020-02-04 12:41:59 --> Severity: Warning --> Illegal string offset 'id_city' /var/www/html/equizAdmin/application/views/new_examiner.php 98
ERROR - 2020-02-04 12:41:59 --> Severity: Warning --> Illegal string offset 'city_name' /var/www/html/equizAdmin/application/views/new_examiner.php 98
ERROR - 2020-02-04 12:41:59 --> Severity: Warning --> Illegal string offset 'id_city' /var/www/html/equizAdmin/application/views/new_examiner.php 98
ERROR - 2020-02-04 12:41:59 --> Severity: Warning --> Illegal string offset 'city_name' /var/www/html/equizAdmin/application/views/new_examiner.php 98
ERROR - 2020-02-04 12:44:59 --> Severity: Warning --> Illegal string offset 'id_city' /var/www/html/equizAdmin/application/views/new_examiner.php 97
ERROR - 2020-02-04 12:44:59 --> Severity: Warning --> Illegal string offset 'id_city' /var/www/html/equizAdmin/application/views/new_examiner.php 97
ERROR - 2020-02-04 12:44:59 --> Severity: Warning --> Illegal string offset 'city_name' /var/www/html/equizAdmin/application/views/new_examiner.php 97
ERROR - 2020-02-04 12:44:59 --> Severity: Warning --> Illegal string offset 'id_city' /var/www/html/equizAdmin/application/views/new_examiner.php 97
ERROR - 2020-02-04 12:44:59 --> Severity: Warning --> Illegal string offset 'id_city' /var/www/html/equizAdmin/application/views/new_examiner.php 97
ERROR - 2020-02-04 12:44:59 --> Severity: Warning --> Illegal string offset 'city_name' /var/www/html/equizAdmin/application/views/new_examiner.php 97
ERROR - 2020-02-04 12:46:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 202
ERROR - 2020-02-04 12:48:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 202
ERROR - 2020-02-04 12:49:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 202
ERROR - 2020-02-04 12:56:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 206
ERROR - 2020-02-04 12:56:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 206
ERROR - 2020-02-04 12:57:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 206
ERROR - 2020-02-04 12:58:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 206
ERROR - 2020-02-04 12:59:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 206
ERROR - 2020-02-04 13:00:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 206
ERROR - 2020-02-04 13:00:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 206
ERROR - 2020-02-04 13:01:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 206
ERROR - 2020-02-04 13:03:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 206
ERROR - 2020-02-04 13:05:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 206
ERROR - 2020-02-04 13:07:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 206
ERROR - 2020-02-04 13:07:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 206
ERROR - 2020-02-04 13:08:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 206
ERROR - 2020-02-04 13:10:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 206
ERROR - 2020-02-04 13:11:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 206
ERROR - 2020-02-04 13:11:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 206
ERROR - 2020-02-04 13:11:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 206
ERROR - 2020-02-04 13:12:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 206
ERROR - 2020-02-04 13:23:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/profile.php 231
ERROR - 2020-02-04 13:23:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/profile.php 320
ERROR - 2020-02-04 13:24:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/profile.php 231
ERROR - 2020-02-04 13:24:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/profile.php 320
ERROR - 2020-02-04 13:26:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 206
ERROR - 2020-02-04 13:33:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 206
ERROR - 2020-02-04 13:48:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 206
ERROR - 2020-02-04 15:06:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 206
ERROR - 2020-02-04 15:23:20 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 15:23:20 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 15:23:20 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 15:23:20 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 15:23:20 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 15:37:09 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 15:37:09 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 15:37:09 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 15:37:09 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 15:37:09 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 15:37:19 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 15:37:19 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 15:37:19 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 15:37:19 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 15:37:19 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 15:37:19 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 15:37:19 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 15:37:19 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 15:37:19 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 15:37:32 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 15:37:32 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 15:37:32 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 15:37:32 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 15:37:32 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 15:37:38 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 15:37:38 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 15:37:38 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 15:37:38 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 15:37:38 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 15:41:52 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 15:41:52 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 15:41:52 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 15:41:52 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 15:41:52 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 15:42:51 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 15:42:51 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 15:42:51 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 15:42:51 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 15:42:51 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 15:44:14 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 15:44:14 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 15:44:14 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 15:44:14 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 15:44:14 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 15:44:35 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 15:44:35 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 15:44:35 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 15:44:35 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 15:44:35 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 15:44:48 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 15:44:48 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 15:44:48 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 15:44:48 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 15:44:48 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 15:45:38 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 15:45:38 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 15:45:38 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 15:45:38 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 15:45:38 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 15:46:20 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 15:46:20 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 15:46:20 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 15:46:20 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 15:46:20 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 16:00:36 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 16:00:36 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 16:00:36 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 16:00:36 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 16:00:36 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 16:01:34 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 16:01:34 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 16:01:34 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 16:01:34 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 16:01:34 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 16:04:31 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 16:04:31 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 16:04:31 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 16:04:31 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 16:04:31 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 16:04:35 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 16:04:35 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 16:04:35 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 16:04:35 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 16:04:37 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 16:04:37 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 16:04:37 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 16:04:37 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 16:04:37 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 16:04:40 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 16:04:40 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 16:04:40 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 16:04:40 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 16:04:41 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 16:04:41 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 16:04:41 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 16:04:41 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 16:04:41 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:01:15 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 17:01:15 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 17:01:15 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 17:01:15 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 17:01:15 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:01:57 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 17:01:57 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 17:01:57 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 17:01:57 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 17:01:57 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:01:57 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:06:54 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 17:06:54 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 17:06:54 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 17:06:54 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 17:06:54 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:06:54 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:07:25 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 17:07:25 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 17:07:25 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 17:07:25 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 17:07:25 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:07:25 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:16:34 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 17:16:34 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 17:16:34 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 17:16:34 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 17:16:34 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:16:34 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:17:01 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 17:17:01 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 17:17:01 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 17:17:01 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 17:17:01 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:17:01 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:21:23 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 17:21:23 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 17:21:23 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 17:21:23 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 17:21:23 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:21:23 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:21:33 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 17:21:33 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 17:21:33 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 17:21:33 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 17:21:33 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:21:33 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:21:39 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 17:21:39 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 17:21:39 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 17:21:39 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 17:21:39 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:21:39 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:21:49 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 17:21:49 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 17:21:49 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 17:21:49 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 17:21:49 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmin/application/models/Quiz_model.php 255
ERROR - 2020-02-04 17:21:49 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmin/application/models/Quiz_model.php 256
ERROR - 2020-02-04 17:21:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/models/Quiz_model.php 321
ERROR - 2020-02-04 17:21:50 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 17:21:50 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 17:21:50 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 17:21:50 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 17:21:50 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:21:50 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:21:56 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 17:21:56 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 17:21:56 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 17:21:56 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 17:21:56 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:21:56 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:22:02 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 17:22:02 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 17:22:02 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 17:22:02 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 17:22:02 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:22:02 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:22:50 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 17:22:50 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 17:22:50 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 17:22:50 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 17:22:50 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmin/application/models/Quiz_model.php 255
ERROR - 2020-02-04 17:22:50 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmin/application/models/Quiz_model.php 256
ERROR - 2020-02-04 17:22:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/models/Quiz_model.php 321
ERROR - 2020-02-04 17:22:50 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 17:22:50 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 17:22:50 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 17:22:50 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 17:22:50 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:22:50 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:24:47 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 17:24:47 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 17:24:47 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 17:24:47 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 17:24:47 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:24:47 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:24:51 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 17:24:51 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 17:24:51 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 17:24:51 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 17:24:51 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmin/application/models/Quiz_model.php 255
ERROR - 2020-02-04 17:24:51 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmin/application/models/Quiz_model.php 256
ERROR - 2020-02-04 17:24:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/models/Quiz_model.php 316
ERROR - 2020-02-04 17:24:52 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 17:24:52 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 17:24:52 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 17:24:52 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 17:24:52 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:24:52 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:25:12 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 17:25:12 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 17:25:12 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 17:25:12 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 17:25:12 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmin/application/models/Quiz_model.php 255
ERROR - 2020-02-04 17:25:12 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmin/application/models/Quiz_model.php 256
ERROR - 2020-02-04 17:25:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/models/Quiz_model.php 316
ERROR - 2020-02-04 17:25:12 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 17:25:12 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 17:25:12 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 17:25:12 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 17:25:12 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:25:12 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:25:22 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 17:25:22 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 17:25:22 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 17:25:22 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 17:25:22 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:25:22 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:25:24 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 17:25:24 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 17:25:24 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 17:25:24 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 17:25:24 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:25:24 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:25:34 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 17:25:34 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 17:25:34 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 17:25:34 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 17:25:34 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:25:34 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:25:37 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 17:25:37 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 17:25:37 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 17:25:37 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 17:25:37 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:25:37 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:26:04 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 17:26:04 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 17:26:04 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 17:26:04 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 17:26:04 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmin/application/models/Quiz_model.php 255
ERROR - 2020-02-04 17:26:04 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmin/application/models/Quiz_model.php 256
ERROR - 2020-02-04 17:26:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/models/Quiz_model.php 316
ERROR - 2020-02-04 17:26:05 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-04 17:26:05 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-04 17:26:05 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-04 17:26:05 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-04 17:26:05 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-04 17:26:05 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmin/system/libraries/Breadcrumb.php 74
