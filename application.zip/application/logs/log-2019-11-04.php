<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-04 10:11:38 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 237
