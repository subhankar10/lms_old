<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-11 15:26:42 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-11 15:26:42 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-11 15:26:42 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-11 15:26:42 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-11 15:26:55 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-11 15:26:55 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-11 15:26:55 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-11 15:26:55 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-11 15:27:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 247
ERROR - 2020-02-11 15:28:40 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-11 15:28:40 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-11 15:28:40 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-11 15:28:40 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-11 15:29:17 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-11 15:29:17 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-11 15:29:17 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-11 15:29:17 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-11 16:15:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 247
ERROR - 2020-02-11 16:18:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 247
ERROR - 2020-02-11 16:24:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 247
ERROR - 2020-02-11 16:25:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 247
ERROR - 2020-02-11 16:26:12 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-11 16:26:12 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-11 16:26:12 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-11 16:26:12 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-11 16:27:18 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-11 16:27:18 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-11 16:27:18 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-11 16:27:18 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-11 16:28:01 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-11 16:28:01 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-11 16:28:01 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-11 16:28:01 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-11 18:38:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 247
ERROR - 2020-02-11 18:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 245
ERROR - 2020-02-11 18:39:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 245
ERROR - 2020-02-11 18:45:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 245
ERROR - 2020-02-11 18:47:13 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-11 18:47:13 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-11 18:47:13 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-11 18:47:13 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
