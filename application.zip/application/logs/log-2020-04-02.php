<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-02 09:34:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/dashboard.php 178
ERROR - 2020-04-02 09:34:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/examiner_list.php 204
ERROR - 2020-04-02 09:34:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 207
ERROR - 2020-04-02 09:35:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/dashboard.php 178
ERROR - 2020-04-02 09:35:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/dashboard.php 178
ERROR - 2020-04-02 12:29:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/dashboard.php 178
ERROR - 2020-04-02 12:29:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/dashboard.php 178
ERROR - 2020-04-02 13:07:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: select * from kams_students_exam_subscription where qid in () 
ERROR - 2020-04-02 13:11:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 245
ERROR - 2020-04-02 13:11:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/userupcomingliveclassList.php 198
ERROR - 2020-04-02 13:12:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/examiner_list.php 204
ERROR - 2020-04-02 13:12:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/class/classroomList.php 174
ERROR - 2020-04-02 13:40:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/class/classroomList.php 174
ERROR - 2020-04-02 13:41:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/subject/subjectList.php 174
ERROR - 2020-04-02 13:43:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/class/classroomList.php 174
ERROR - 2020-04-02 13:46:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/subject/subjectList.php 174
ERROR - 2020-04-02 13:46:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 245
ERROR - 2020-04-02 13:46:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 207
ERROR - 2020-04-02 13:49:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 207
ERROR - 2020-04-02 13:50:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 207
ERROR - 2020-04-02 13:51:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/examiner_list.php 204
ERROR - 2020-04-02 13:51:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/examiner_list.php 204
ERROR - 2020-04-02 13:52:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 207
ERROR - 2020-04-02 14:13:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/models/User_model.php 422
ERROR - 2020-04-02 14:22:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/userupcomingliveclassList.php 198
ERROR - 2020-04-02 14:22:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/userupcomingliveclassList.php 198
ERROR - 2020-04-02 14:26:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/userupcomingliveclassList.php 198
ERROR - 2020-04-02 14:58:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 245
ERROR - 2020-04-02 14:58:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 245
ERROR - 2020-04-02 14:58:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 245
ERROR - 2020-04-02 15:29:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/examiner_list.php 204
ERROR - 2020-04-02 15:30:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/class/classroomList.php 174
ERROR - 2020-04-02 15:31:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/class/classroomList.php 174
ERROR - 2020-04-02 15:31:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/subject/subjectList.php 174
ERROR - 2020-04-02 15:31:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/subject/subjectList.php 174
ERROR - 2020-04-02 15:32:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 207
ERROR - 2020-04-02 15:33:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 207
ERROR - 2020-04-02 15:33:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: select * from kams_students_exam_subscription where qid in () 
ERROR - 2020-04-02 18:33:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/userupcomingliveclassList.php 198
ERROR - 2020-04-02 18:33:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/examiner_list.php 204
ERROR - 2020-04-02 18:34:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/examiner_list.php 204
ERROR - 2020-04-02 22:29:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/subject/subjectList.php 174
ERROR - 2020-04-02 22:29:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 207
ERROR - 2020-04-02 22:30:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 207
ERROR - 2020-04-02 22:34:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/userupcomingliveclassList.php 198
ERROR - 2020-04-02 22:44:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 207
