<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-31 10:25:25 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-01-31 10:29:17 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-01-31 10:52:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 202
ERROR - 2020-01-31 10:54:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/edit_question_1.php 76
ERROR - 2020-01-31 10:55:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/edit_question_1.php 76
