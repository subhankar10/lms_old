<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-09 12:23:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-09 15:13:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-09 15:17:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 155
ERROR - 2020-03-09 15:17:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmindesign/application/views/dashboard.php 196
ERROR - 2020-03-09 15:17:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/dashboard.php 201
ERROR - 2020-03-09 15:41:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:41:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:41:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:41:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:41:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:41:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:41:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:41:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:41:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:41:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:41:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:41:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:41:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:41:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:41:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:41:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:41:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:41:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:41:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:41:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:41:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:41:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:41:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:41:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:41:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:41:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:47:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-09 15:48:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-09 15:48:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:48:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:48:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:48:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:48:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:48:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:48:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:48:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:48:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:48:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:48:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:48:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:48:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:48:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:48:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:48:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:48:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:48:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:48:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:48:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:48:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:48:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:48:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:48:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:48:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-09 15:48:33 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
