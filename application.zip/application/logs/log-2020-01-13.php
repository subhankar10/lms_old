<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-13 16:49:44 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-01-13 17:20:50 --> Severity: Warning --> require_once(/var/www/html/equizAdmin/application/controllers/Qbank.php): failed to open stream: Permission denied /var/www/html/equizAdmin/system/core/CodeIgniter.php 411
ERROR - 2020-01-13 17:20:50 --> Severity: Compile Error --> require_once(): Failed opening required '/var/www/html/equizAdmin/application/controllers/Qbank.php' (include_path='.:/usr/share/php') /var/www/html/equizAdmin/system/core/CodeIgniter.php 411
ERROR - 2020-01-13 17:20:52 --> Severity: Warning --> require_once(/var/www/html/equizAdmin/application/controllers/Qbank.php): failed to open stream: Permission denied /var/www/html/equizAdmin/system/core/CodeIgniter.php 411
ERROR - 2020-01-13 17:20:52 --> Severity: Compile Error --> require_once(): Failed opening required '/var/www/html/equizAdmin/application/controllers/Qbank.php' (include_path='.:/usr/share/php') /var/www/html/equizAdmin/system/core/CodeIgniter.php 411
ERROR - 2020-01-13 17:21:37 --> Severity: Warning --> require_once(/var/www/html/equizAdmin/application/controllers/Qbank.php): failed to open stream: Permission denied /var/www/html/equizAdmin/system/core/CodeIgniter.php 411
ERROR - 2020-01-13 17:21:37 --> Severity: Compile Error --> require_once(): Failed opening required '/var/www/html/equizAdmin/application/controllers/Qbank.php' (include_path='.:/usr/share/php') /var/www/html/equizAdmin/system/core/CodeIgniter.php 411
ERROR - 2020-01-13 17:22:02 --> Severity: Warning --> require_once(/var/www/html/equizAdmin/application/controllers/Qbank.php): failed to open stream: Permission denied /var/www/html/equizAdmin/system/core/CodeIgniter.php 411
ERROR - 2020-01-13 17:22:02 --> Severity: Compile Error --> require_once(): Failed opening required '/var/www/html/equizAdmin/application/controllers/Qbank.php' (include_path='.:/usr/share/php') /var/www/html/equizAdmin/system/core/CodeIgniter.php 411
ERROR - 2020-01-13 17:22:14 --> Severity: Warning --> require_once(/var/www/html/equizAdmin/application/controllers/Qbank.php): failed to open stream: Permission denied /var/www/html/equizAdmin/system/core/CodeIgniter.php 411
ERROR - 2020-01-13 17:22:14 --> Severity: Compile Error --> require_once(): Failed opening required '/var/www/html/equizAdmin/application/controllers/Qbank.php' (include_path='.:/usr/share/php') /var/www/html/equizAdmin/system/core/CodeIgniter.php 411
ERROR - 2020-01-13 17:22:18 --> Severity: Warning --> require_once(/var/www/html/equizAdmin/application/controllers/Qbank.php): failed to open stream: Permission denied /var/www/html/equizAdmin/system/core/CodeIgniter.php 411
ERROR - 2020-01-13 17:22:18 --> Severity: Compile Error --> require_once(): Failed opening required '/var/www/html/equizAdmin/application/controllers/Qbank.php' (include_path='.:/usr/share/php') /var/www/html/equizAdmin/system/core/CodeIgniter.php 411
ERROR - 2020-01-13 17:22:39 --> Severity: Warning --> require_once(/var/www/html/equizAdmin/application/controllers/Qbank.php): failed to open stream: Permission denied /var/www/html/equizAdmin/system/core/CodeIgniter.php 411
ERROR - 2020-01-13 17:22:39 --> Severity: Compile Error --> require_once(): Failed opening required '/var/www/html/equizAdmin/application/controllers/Qbank.php' (include_path='.:/usr/share/php') /var/www/html/equizAdmin/system/core/CodeIgniter.php 411
ERROR - 2020-01-13 17:23:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/question_list.php 36
ERROR - 2020-01-13 17:23:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/question_list.php 49
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 17:27:11 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/question_list.php 99
ERROR - 2020-01-13 18:48:56 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
