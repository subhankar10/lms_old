<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-27 10:20:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/management_user_list.php 193
ERROR - 2020-03-27 10:21:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/management_user_list.php 193
ERROR - 2020-03-27 10:22:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/management_user_list.php 193
ERROR - 2020-03-27 10:23:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/management_user_list.php 193
ERROR - 2020-03-27 10:23:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/management_user_list.php 193
ERROR - 2020-03-27 10:24:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/examiner_list.php 204
ERROR - 2020-03-27 10:29:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/examiner_list.php 204
