<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-28 10:39:42 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-01-28 10:49:49 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-01-28 11:11:03 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmin/application/models/Quiz_model.php 219
ERROR - 2020-01-28 11:11:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/models/Quiz_model.php 280
ERROR - 2020-01-28 11:11:14 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmin/application/models/Quiz_model.php 219
ERROR - 2020-01-28 11:11:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/models/Quiz_model.php 280
ERROR - 2020-01-28 11:16:54 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580190414)
ERROR - 2020-01-28 11:25:13 --> Query error: Table 'equiz_live.kams_assign_students' doesn't exist - Invalid query: SELECT *
FROM `kams_users`
WHERE `kams_users`.`su` = '2'
AND `uid` NOT IN (SELECT `student_id` FROM `kams_assign_students`)
ORDER BY `kams_users`.`uid` DESC
ERROR - 2020-01-28 11:25:13 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/controllers/Examiner.php 46
ERROR - 2020-01-28 11:25:24 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-01-28 11:25:42 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-01-28 12:16:19 --> Severity: error --> Exception: syntax error, unexpected '$subcriptionExamList' (T_VARIABLE) /var/www/html/equizAdmin/application/controllers/Api.php 1597
ERROR - 2020-01-28 12:18:33 --> Severity: error --> Exception: syntax error, unexpected '}' /var/www/html/equizAdmin/application/controllers/Api.php 1600
ERROR - 2020-01-28 12:33:05 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580194985)
ERROR - 2020-01-28 12:39:42 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580195382)
ERROR - 2020-01-28 12:57:44 --> Severity: Warning --> Use of undefined constant SITE_ROOT - assumed 'SITE_ROOT' (this will throw an Error in a future version of PHP) /var/www/html/equizAdmin/application/views/mail/contactus.php 1
ERROR - 2020-01-28 12:57:44 --> Severity: Warning --> include(SITE_ROOTviews/mail/header.php): failed to open stream: No such file or directory /var/www/html/equizAdmin/application/views/mail/contactus.php 1
ERROR - 2020-01-28 12:57:44 --> Severity: Warning --> include(): Failed opening 'SITE_ROOTviews/mail/header.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/equizAdmin/application/views/mail/contactus.php 1
ERROR - 2020-01-28 12:57:44 --> Severity: Warning --> Use of undefined constant SITE_ROOT - assumed 'SITE_ROOT' (this will throw an Error in a future version of PHP) /var/www/html/equizAdmin/application/views/mail/contactus.php 26
ERROR - 2020-01-28 12:57:44 --> Severity: Warning --> include(SITE_ROOTviews/mail/footer.php): failed to open stream: No such file or directory /var/www/html/equizAdmin/application/views/mail/contactus.php 26
ERROR - 2020-01-28 12:57:44 --> Severity: Warning --> include(): Failed opening 'SITE_ROOTviews/mail/footer.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/equizAdmin/application/views/mail/contactus.php 26
ERROR - 2020-01-28 15:03:47 --> Severity: Warning --> Use of undefined constant SITE_ROOT - assumed 'SITE_ROOT' (this will throw an Error in a future version of PHP) /var/www/html/equizAdmin/application/views/mail/examSubscription.php 1
ERROR - 2020-01-28 15:03:47 --> Severity: Warning --> include(SITE_ROOTviews/mail/header.php): failed to open stream: No such file or directory /var/www/html/equizAdmin/application/views/mail/examSubscription.php 1
ERROR - 2020-01-28 15:03:47 --> Severity: Warning --> include(): Failed opening 'SITE_ROOTviews/mail/header.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/equizAdmin/application/views/mail/examSubscription.php 1
ERROR - 2020-01-28 15:03:47 --> Severity: Warning --> Use of undefined constant SITE_ROOT - assumed 'SITE_ROOT' (this will throw an Error in a future version of PHP) /var/www/html/equizAdmin/application/views/mail/examSubscription.php 27
ERROR - 2020-01-28 15:03:47 --> Severity: Warning --> include(SITE_ROOTviews/mail/footer.php): failed to open stream: No such file or directory /var/www/html/equizAdmin/application/views/mail/examSubscription.php 27
ERROR - 2020-01-28 15:03:47 --> Severity: Warning --> include(): Failed opening 'SITE_ROOTviews/mail/footer.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/equizAdmin/application/views/mail/examSubscription.php 27
ERROR - 2020-01-28 15:04:59 --> Severity: Warning --> Use of undefined constant SITE_ROOT - assumed 'SITE_ROOT' (this will throw an Error in a future version of PHP) /var/www/html/equizAdmin/application/views/mail/examSubscription.php 1
ERROR - 2020-01-28 15:04:59 --> Severity: Warning --> include(SITE_ROOTviews/mail/header.php): failed to open stream: No such file or directory /var/www/html/equizAdmin/application/views/mail/examSubscription.php 1
ERROR - 2020-01-28 15:04:59 --> Severity: Warning --> include(): Failed opening 'SITE_ROOTviews/mail/header.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/equizAdmin/application/views/mail/examSubscription.php 1
ERROR - 2020-01-28 15:04:59 --> Severity: Warning --> Use of undefined constant SITE_ROOT - assumed 'SITE_ROOT' (this will throw an Error in a future version of PHP) /var/www/html/equizAdmin/application/views/mail/examSubscription.php 27
ERROR - 2020-01-28 15:04:59 --> Severity: Warning --> include(SITE_ROOTviews/mail/footer.php): failed to open stream: No such file or directory /var/www/html/equizAdmin/application/views/mail/examSubscription.php 27
ERROR - 2020-01-28 15:04:59 --> Severity: Warning --> include(): Failed opening 'SITE_ROOTviews/mail/footer.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/equizAdmin/application/views/mail/examSubscription.php 27
ERROR - 2020-01-28 15:05:29 --> Severity: Warning --> Use of undefined constant SITE_ROOT - assumed 'SITE_ROOT' (this will throw an Error in a future version of PHP) /var/www/html/equizAdmin/application/views/mail/examSubscription.php 1
ERROR - 2020-01-28 15:05:29 --> Severity: Warning --> include(SITE_ROOTviews/mail/header.php): failed to open stream: No such file or directory /var/www/html/equizAdmin/application/views/mail/examSubscription.php 1
ERROR - 2020-01-28 15:05:29 --> Severity: Warning --> include(): Failed opening 'SITE_ROOTviews/mail/header.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/equizAdmin/application/views/mail/examSubscription.php 1
ERROR - 2020-01-28 15:05:29 --> Severity: Warning --> Use of undefined constant SITE_ROOT - assumed 'SITE_ROOT' (this will throw an Error in a future version of PHP) /var/www/html/equizAdmin/application/views/mail/examSubscription.php 27
ERROR - 2020-01-28 15:05:29 --> Severity: Warning --> include(SITE_ROOTviews/mail/footer.php): failed to open stream: No such file or directory /var/www/html/equizAdmin/application/views/mail/examSubscription.php 27
ERROR - 2020-01-28 15:05:29 --> Severity: Warning --> include(): Failed opening 'SITE_ROOTviews/mail/footer.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/equizAdmin/application/views/mail/examSubscription.php 27
ERROR - 2020-01-28 15:07:25 --> Severity: Warning --> Use of undefined constant SITE_ROOT - assumed 'SITE_ROOT' (this will throw an Error in a future version of PHP) /var/www/html/equizAdmin/application/views/mail/examSubscription.php 1
ERROR - 2020-01-28 15:07:25 --> Severity: Warning --> include(SITE_ROOTviews/mail/header.php): failed to open stream: No such file or directory /var/www/html/equizAdmin/application/views/mail/examSubscription.php 1
ERROR - 2020-01-28 15:07:25 --> Severity: Warning --> include(): Failed opening 'SITE_ROOTviews/mail/header.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/equizAdmin/application/views/mail/examSubscription.php 1
ERROR - 2020-01-28 15:07:25 --> Severity: Warning --> Use of undefined constant SITE_ROOT - assumed 'SITE_ROOT' (this will throw an Error in a future version of PHP) /var/www/html/equizAdmin/application/views/mail/examSubscription.php 27
ERROR - 2020-01-28 15:07:25 --> Severity: Warning --> include(SITE_ROOTviews/mail/footer.php): failed to open stream: No such file or directory /var/www/html/equizAdmin/application/views/mail/examSubscription.php 27
ERROR - 2020-01-28 15:07:25 --> Severity: Warning --> include(): Failed opening 'SITE_ROOTviews/mail/footer.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/equizAdmin/application/views/mail/examSubscription.php 27
ERROR - 2020-01-28 15:08:50 --> Severity: Warning --> Use of undefined constant SITE_ROOT - assumed 'SITE_ROOT' (this will throw an Error in a future version of PHP) /var/www/html/equizAdmin/application/views/mail/contactus.php 1
ERROR - 2020-01-28 15:08:50 --> Severity: Warning --> include(SITE_ROOTviews/mail/header.php): failed to open stream: No such file or directory /var/www/html/equizAdmin/application/views/mail/contactus.php 1
ERROR - 2020-01-28 15:08:50 --> Severity: Warning --> include(): Failed opening 'SITE_ROOTviews/mail/header.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/equizAdmin/application/views/mail/contactus.php 1
ERROR - 2020-01-28 15:08:50 --> Severity: Warning --> Use of undefined constant SITE_ROOT - assumed 'SITE_ROOT' (this will throw an Error in a future version of PHP) /var/www/html/equizAdmin/application/views/mail/contactus.php 26
ERROR - 2020-01-28 15:08:50 --> Severity: Warning --> include(SITE_ROOTviews/mail/footer.php): failed to open stream: No such file or directory /var/www/html/equizAdmin/application/views/mail/contactus.php 26
ERROR - 2020-01-28 15:08:50 --> Severity: Warning --> include(): Failed opening 'SITE_ROOTviews/mail/footer.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/equizAdmin/application/views/mail/contactus.php 26
ERROR - 2020-01-28 15:10:04 --> Severity: Warning --> Use of undefined constant SITE_ROOT - assumed 'SITE_ROOT' (this will throw an Error in a future version of PHP) /var/www/html/equizAdmin/application/views/mail/examSubscription.php 1
ERROR - 2020-01-28 15:10:04 --> Severity: Warning --> include(SITE_ROOTviews/mail/header.php): failed to open stream: No such file or directory /var/www/html/equizAdmin/application/views/mail/examSubscription.php 1
ERROR - 2020-01-28 15:10:04 --> Severity: Warning --> include(): Failed opening 'SITE_ROOTviews/mail/header.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/equizAdmin/application/views/mail/examSubscription.php 1
ERROR - 2020-01-28 15:10:04 --> Severity: Warning --> Use of undefined constant SITE_ROOT - assumed 'SITE_ROOT' (this will throw an Error in a future version of PHP) /var/www/html/equizAdmin/application/views/mail/examSubscription.php 27
ERROR - 2020-01-28 15:10:04 --> Severity: Warning --> include(SITE_ROOTviews/mail/footer.php): failed to open stream: No such file or directory /var/www/html/equizAdmin/application/views/mail/examSubscription.php 27
ERROR - 2020-01-28 15:10:04 --> Severity: Warning --> include(): Failed opening 'SITE_ROOTviews/mail/footer.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/equizAdmin/application/views/mail/examSubscription.php 27
ERROR - 2020-01-28 15:30:26 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-01-28 17:23:32 --> Severity: Warning --> Use of undefined constant SITE_ROOT - assumed 'SITE_ROOT' (this will throw an Error in a future version of PHP) /var/www/html/equizAdmin/application/views/mail/examSubscription.php 1
ERROR - 2020-01-28 17:23:32 --> Severity: Warning --> include(SITE_ROOTviews/mail/header.php): failed to open stream: No such file or directory /var/www/html/equizAdmin/application/views/mail/examSubscription.php 1
ERROR - 2020-01-28 17:23:32 --> Severity: Warning --> include(): Failed opening 'SITE_ROOTviews/mail/header.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/equizAdmin/application/views/mail/examSubscription.php 1
ERROR - 2020-01-28 17:23:32 --> Severity: Warning --> Use of undefined constant SITE_ROOT - assumed 'SITE_ROOT' (this will throw an Error in a future version of PHP) /var/www/html/equizAdmin/application/views/mail/examSubscription.php 27
ERROR - 2020-01-28 17:23:32 --> Severity: Warning --> include(SITE_ROOTviews/mail/footer.php): failed to open stream: No such file or directory /var/www/html/equizAdmin/application/views/mail/examSubscription.php 27
ERROR - 2020-01-28 17:23:32 --> Severity: Warning --> include(): Failed opening 'SITE_ROOTviews/mail/footer.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/equizAdmin/application/views/mail/examSubscription.php 27
ERROR - 2020-01-28 17:23:37 --> Severity: Warning --> fsockopen(): unable to connect to lnx25.securehostdns.com:587 (Connection timed out) /var/www/html/equizAdmin/system/libraries/Email.php 2069
ERROR - 2020-01-28 17:30:18 --> Severity: Warning --> require_once(/var/www/html/equizAdmin/application/controllers/Login.php): failed to open stream: Permission denied /var/www/html/equizAdmin/system/core/CodeIgniter.php 411
ERROR - 2020-01-28 17:30:18 --> Severity: Compile Error --> require_once(): Failed opening required '/var/www/html/equizAdmin/application/controllers/Login.php' (include_path='.:/usr/share/php') /var/www/html/equizAdmin/system/core/CodeIgniter.php 411
ERROR - 2020-01-28 17:30:23 --> Severity: Warning --> require_once(/var/www/html/equizAdmin/application/controllers/Login.php): failed to open stream: Permission denied /var/www/html/equizAdmin/system/core/CodeIgniter.php 411
ERROR - 2020-01-28 17:30:23 --> Severity: Compile Error --> require_once(): Failed opening required '/var/www/html/equizAdmin/application/controllers/Login.php' (include_path='.:/usr/share/php') /var/www/html/equizAdmin/system/core/CodeIgniter.php 411
ERROR - 2020-01-28 17:30:57 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-01-28 19:06:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: INSERT INTO kams_answers (qid,q_option,uid,score_u,rid,exam_module) SELECT qid,oid,'52',score,'234',3 FROM kams_options WHERE oid IN ();
ERROR - 2020-01-28 19:18:27 --> Severity: Warning --> Use of undefined constant SITE_ROOT - assumed 'SITE_ROOT' (this will throw an Error in a future version of PHP) /var/www/html/equizAdmin/application/views/mail/examSubscription.php 1
ERROR - 2020-01-28 19:18:27 --> Severity: Warning --> include(SITE_ROOTviews/mail/header.php): failed to open stream: No such file or directory /var/www/html/equizAdmin/application/views/mail/examSubscription.php 1
ERROR - 2020-01-28 19:18:27 --> Severity: Warning --> include(): Failed opening 'SITE_ROOTviews/mail/header.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/equizAdmin/application/views/mail/examSubscription.php 1
ERROR - 2020-01-28 19:18:27 --> Severity: Warning --> Use of undefined constant SITE_ROOT - assumed 'SITE_ROOT' (this will throw an Error in a future version of PHP) /var/www/html/equizAdmin/application/views/mail/examSubscription.php 27
ERROR - 2020-01-28 19:18:27 --> Severity: Warning --> include(SITE_ROOTviews/mail/footer.php): failed to open stream: No such file or directory /var/www/html/equizAdmin/application/views/mail/examSubscription.php 27
ERROR - 2020-01-28 19:18:27 --> Severity: Warning --> include(): Failed opening 'SITE_ROOTviews/mail/footer.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/equizAdmin/application/views/mail/examSubscription.php 27
ERROR - 2020-01-28 19:35:15 --> Severity: Warning --> include(/var/www/html/equizAdmin/application/language/english/basic_lang.php): failed to open stream: Permission denied /var/www/html/equizAdmin/system/core/Lang.php 144
ERROR - 2020-01-28 19:35:15 --> Severity: Warning --> include(): Failed opening '/var/www/html/equizAdmin/application/language/english/basic_lang.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/equizAdmin/system/core/Lang.php 144
ERROR - 2020-01-28 19:35:15 --> Language file contains no data: language/english/basic_lang.php
ERROR - 2020-01-28 19:35:15 --> Could not find the language line "student_subscription_exam"
ERROR - 2020-01-28 19:35:15 --> Severity: Warning --> include(/var/www/html/equizAdmin/application/views/header.php): failed to open stream: Permission denied /var/www/html/equizAdmin/system/core/Loader.php 968
ERROR - 2020-01-28 19:35:15 --> Severity: Warning --> include(): Failed opening '/var/www/html/equizAdmin/application/views/header.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/equizAdmin/system/core/Loader.php 968
ERROR - 2020-01-28 19:35:15 --> Severity: Warning --> include(/var/www/html/equizAdmin/application/views/student_subscription.php): failed to open stream: Permission denied /var/www/html/equizAdmin/system/core/Loader.php 968
ERROR - 2020-01-28 19:35:15 --> Severity: Warning --> include(): Failed opening '/var/www/html/equizAdmin/application/views/student_subscription.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/equizAdmin/system/core/Loader.php 968
ERROR - 2020-01-28 19:35:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 32
ERROR - 2020-01-28 20:29:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 32
ERROR - 2020-01-28 20:29:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 32
