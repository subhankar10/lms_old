<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-27 11:26:58 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580104617)
ERROR - 2020-01-27 11:30:28 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580104828)
ERROR - 2020-01-27 11:38:52 --> Could not find the language line "student_subscription_exam"
ERROR - 2020-01-27 11:38:52 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-01-27 11:39:06 --> Could not find the language line "student_subscription_exam"
ERROR - 2020-01-27 11:39:12 --> Could not find the language line "student_subscription_exam"
ERROR - 2020-01-27 11:39:49 --> Could not find the language line "student_subscription_exam"
ERROR - 2020-01-27 11:39:56 --> Could not find the language line "student_subscription_exam"
ERROR - 2020-01-27 11:39:58 --> Could not find the language line "student_subscription_exam"
ERROR - 2020-01-27 11:39:59 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580105399)
ERROR - 2020-01-27 11:40:02 --> Could not find the language line "student_subscription_exam"
ERROR - 2020-01-27 11:40:05 --> Could not find the language line "student_subscription_exam"
ERROR - 2020-01-27 11:40:09 --> Could not find the language line "student_subscription_exam"
ERROR - 2020-01-27 11:40:40 --> Could not find the language line "student_subscription_exam"
ERROR - 2020-01-27 11:40:54 --> Could not find the language line "student_subscription_exam"
ERROR - 2020-01-27 11:40:57 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580105457)
ERROR - 2020-01-27 11:43:14 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580105594)
ERROR - 2020-01-27 11:48:21 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580105901)
ERROR - 2020-01-27 11:48:40 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580105920)
ERROR - 2020-01-27 11:49:03 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580105943)
ERROR - 2020-01-27 11:50:16 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580106016)
ERROR - 2020-01-27 11:55:14 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580106314)
ERROR - 2020-01-27 11:58:13 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580106493)
ERROR - 2020-01-27 11:59:10 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580106550)
ERROR - 2020-01-27 11:59:24 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580106564)
ERROR - 2020-01-27 12:01:06 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580106666)
ERROR - 2020-01-27 12:01:39 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580106699)
ERROR - 2020-01-27 12:03:09 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580106789)
ERROR - 2020-01-27 12:03:26 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580106806)
ERROR - 2020-01-27 12:04:41 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580106881)
ERROR - 2020-01-27 12:07:04 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580107024)
ERROR - 2020-01-27 12:13:36 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580107416)
ERROR - 2020-01-27 12:43:23 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580109203)
ERROR - 2020-01-27 12:44:25 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580109265)
ERROR - 2020-01-27 13:13:37 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580111017)
ERROR - 2020-01-27 13:15:54 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580111154)
ERROR - 2020-01-27 13:16:04 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580111164)
ERROR - 2020-01-27 13:17:12 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580111232)
ERROR - 2020-01-27 13:17:57 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580111277)
ERROR - 2020-01-27 13:19:48 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580111388)
ERROR - 2020-01-27 13:20:15 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580111415)
ERROR - 2020-01-27 13:21:33 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580111493)
ERROR - 2020-01-27 13:23:09 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580111589)
ERROR - 2020-01-27 13:26:49 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580111809)
ERROR - 2020-01-27 13:27:04 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580111824)
ERROR - 2020-01-27 13:33:32 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580112212)
ERROR - 2020-01-27 13:34:52 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580112292)
ERROR - 2020-01-27 13:36:54 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580112412)
ERROR - 2020-01-27 13:37:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: INSERT INTO kams_answers (qid,q_option,uid,score_u,rid,exam_module) SELECT qid,oid,'52',score,'227',3 FROM kams_options WHERE oid IN ();
ERROR - 2020-01-27 13:41:07 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580112667)
ERROR - 2020-01-27 14:33:24 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580115804)
ERROR - 2020-01-27 14:35:07 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580115907)
ERROR - 2020-01-27 14:38:06 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580116086)
ERROR - 2020-01-27 14:40:30 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580116230)
ERROR - 2020-01-27 14:42:14 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580116334)
ERROR - 2020-01-27 14:43:46 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580116426)
ERROR - 2020-01-27 14:45:14 --> Could not find the language line "student_subscription_exam"
ERROR - 2020-01-27 14:45:14 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-01-27 14:45:27 --> Could not find the language line "student_subscription_exam"
ERROR - 2020-01-27 14:45:35 --> Could not find the language line "student_subscription_exam"
ERROR - 2020-01-27 14:45:39 --> Could not find the language line "student_subscription_exam"
ERROR - 2020-01-27 14:45:55 --> Could not find the language line "student_subscription_exam"
ERROR - 2020-01-27 14:45:55 --> Query error: Table 'equiz.kams_students_exam_subscription' doesn't exist - Invalid query: SELECT `q`.`quiz_name`, `s`.*
FROM `kams_students_exam_subscription` `s`
LEFT JOIN `kams_quiz` `q` ON `q`.`quid` = `s`.`quiz_id`
ERROR - 2020-01-27 14:45:55 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/controllers/Student_subscriptionexam.php 44
ERROR - 2020-01-27 14:46:03 --> Could not find the language line "student_subscription_exam"
ERROR - 2020-01-27 14:46:12 --> Could not find the language line "student_subscription_exam"
ERROR - 2020-01-27 14:46:15 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580116575)
ERROR - 2020-01-27 14:46:20 --> Could not find the language line "student_subscription_exam"
ERROR - 2020-01-27 14:46:26 --> Could not find the language line "student_subscription_exam"
ERROR - 2020-01-27 14:47:22 --> Could not find the language line "student_subscription_exam"
ERROR - 2020-01-27 14:47:27 --> Could not find the language line "student_subscription_exam"
ERROR - 2020-01-27 14:47:58 --> Could not find the language line "student_subscription_exam"
ERROR - 2020-01-27 14:52:11 --> Could not find the language line "student_subscription_exam"
ERROR - 2020-01-27 14:53:56 --> Could not find the language line "student_subscription_exam"
ERROR - 2020-01-27 14:54:27 --> Could not find the language line "student_subscription_exam"
ERROR - 2020-01-27 15:00:50 --> Could not find the language line "student_subscription_exam"
ERROR - 2020-01-27 15:00:54 --> Could not find the language line "student_subscription_exam"
ERROR - 2020-01-27 15:01:29 --> Could not find the language line "student_subscription_exam"
ERROR - 2020-01-27 15:01:51 --> Could not find the language line "student_subscription_exam"
ERROR - 2020-01-27 15:02:12 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580117532)
ERROR - 2020-01-27 15:03:41 --> Could not find the language line "student_subscription_exam"
ERROR - 2020-01-27 15:03:58 --> Could not find the language line "student_subscription_exam"
ERROR - 2020-01-27 15:05:56 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580117756)
ERROR - 2020-01-27 15:10:10 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580118010)
ERROR - 2020-01-27 15:10:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: INSERT INTO kams_answers (qid,q_option,uid,score_u,rid,exam_module) SELECT qid,oid,'52',score,'238',1 FROM kams_options WHERE oid IN ();
ERROR - 2020-01-27 15:10:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: INSERT INTO kams_answers (qid,q_option,uid,score_u,rid,exam_module) SELECT qid,oid,'52',score,'238',3 FROM kams_options WHERE oid IN ();
ERROR - 2020-01-27 15:12:14 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580118134)
ERROR - 2020-01-27 15:16:29 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580118389)
ERROR - 2020-01-27 15:24:13 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-01-27 15:24:20 --> Query error: Table 'equiz.kams_students_exam_subscription' doesn't exist - Invalid query: SELECT `q`.`quiz_name`, `s`.*
FROM `kams_students_exam_subscription` `s`
LEFT JOIN `kams_quiz` `q` ON `q`.`quid` = `s`.`quiz_id`
ERROR - 2020-01-27 15:24:20 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/controllers/Student_subscriptionexam.php 44
ERROR - 2020-01-27 15:25:36 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580118936)
ERROR - 2020-01-27 15:39:53 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmin/application/models/Quiz_model.php 219
ERROR - 2020-01-27 15:39:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/models/Quiz_model.php 280
ERROR - 2020-01-27 15:43:49 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmin/application/models/Quiz_model.php 219
ERROR - 2020-01-27 15:43:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/models/Quiz_model.php 280
ERROR - 2020-01-27 15:46:06 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580120166)
ERROR - 2020-01-27 15:49:14 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580120354)
ERROR - 2020-01-27 15:50:25 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580120425)
ERROR - 2020-01-27 15:53:51 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580120631)
ERROR - 2020-01-27 15:55:46 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580120746)
ERROR - 2020-01-27 15:59:05 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580120945)
ERROR - 2020-01-27 16:00:23 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580121022)
ERROR - 2020-01-27 16:01:28 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580121088)
ERROR - 2020-01-27 16:01:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: INSERT INTO kams_answers (qid,q_option,uid,score_u,rid,exam_module) SELECT qid,oid,'52',score,'191',3 FROM kams_options WHERE oid IN ();
ERROR - 2020-01-27 16:02:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: INSERT INTO kams_answers (qid,q_option,uid,score_u,rid,exam_module) SELECT qid,oid,'52',score,'191',4 FROM kams_options WHERE oid IN ();
ERROR - 2020-01-27 16:05:44 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580121344)
ERROR - 2020-01-27 16:07:43 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580121463)
ERROR - 2020-01-27 16:12:13 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580121733)
ERROR - 2020-01-27 16:12:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: INSERT INTO kams_answers (qid,q_option,uid,score_u,rid,exam_module) SELECT qid,oid,'52',score,'194',1 FROM kams_options WHERE oid IN ();
ERROR - 2020-01-27 16:15:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: INSERT INTO kams_answers (qid,q_option,uid,score_u,rid,exam_module) SELECT qid,oid,'52',score,'194',3 FROM kams_options WHERE oid IN ();
ERROR - 2020-01-27 16:18:53 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580122133)
ERROR - 2020-01-27 16:24:05 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580122445)
ERROR - 2020-01-27 16:37:52 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580123272)
ERROR - 2020-01-27 16:40:42 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580123442)
ERROR - 2020-01-27 16:43:18 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580123598)
ERROR - 2020-01-27 16:44:05 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580123645)
ERROR - 2020-01-27 16:44:36 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580123676)
ERROR - 2020-01-27 16:49:52 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580123992)
ERROR - 2020-01-27 16:51:58 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580124118)
ERROR - 2020-01-27 17:11:38 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580125298)
ERROR - 2020-01-27 17:14:25 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580125465)
ERROR - 2020-01-27 17:17:47 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580125667)
ERROR - 2020-01-27 17:41:43 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-01-27 18:00:23 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580128223)
ERROR - 2020-01-27 18:00:49 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580128249)
ERROR - 2020-01-27 18:05:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: INSERT INTO kams_answers (qid,q_option,uid,score_u,rid,exam_module) SELECT qid,oid,'52',score,'208',1 FROM kams_options WHERE oid IN ();
ERROR - 2020-01-27 18:06:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: INSERT INTO kams_answers (qid,q_option,uid,score_u,rid,exam_module) SELECT qid,oid,'52',score,'208',4 FROM kams_options WHERE oid IN ();
ERROR - 2020-01-27 18:06:48 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580128608)
ERROR - 2020-01-27 18:06:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: INSERT INTO kams_answers (qid,q_option,uid,score_u,rid,exam_module) SELECT qid,oid,'52',score,'206',4 FROM kams_options WHERE oid IN ();
ERROR - 2020-01-27 18:07:01 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580128621)
ERROR - 2020-01-27 18:08:40 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580128720)
ERROR - 2020-01-27 18:09:05 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580128745)
ERROR - 2020-01-27 18:09:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: INSERT INTO kams_answers (qid,q_option,uid,score_u,rid,exam_module) SELECT qid,oid,'52',score,'212',3 FROM kams_options WHERE oid IN ();
ERROR - 2020-01-27 18:09:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: INSERT INTO kams_answers (qid,q_option,uid,score_u,rid,exam_module) SELECT qid,oid,'52',score,'212',4 FROM kams_options WHERE oid IN ();
ERROR - 2020-01-27 19:38:04 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1580134084)
