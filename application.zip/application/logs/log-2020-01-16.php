<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-16 16:47:25 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-01-16 18:36:54 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmin/application/models/Quiz_model.php 217
ERROR - 2020-01-16 18:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/models/Quiz_model.php 278
