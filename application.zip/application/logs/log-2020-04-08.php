<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-08 23:21:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 207
ERROR - 2020-04-08 23:21:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 207
ERROR - 2020-04-08 23:22:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 207
ERROR - 2020-04-08 23:22:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/class/classroomList.php 174
ERROR - 2020-04-08 23:22:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 207
ERROR - 2020-04-08 23:23:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/userupcomingliveclassList.php 198
ERROR - 2020-04-08 23:24:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 245
