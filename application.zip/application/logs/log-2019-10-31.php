<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-31 11:22:15 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 237
