<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-12 13:44:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-12 15:21:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-12 15:33:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-12 15:34:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-12 15:35:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-12 15:38:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-12 15:44:47 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 15:44:47 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 15:44:47 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 15:44:47 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 15:44:47 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 15:44:47 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 15:44:47 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 15:44:47 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 15:44:47 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 15:44:47 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 15:44:47 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 15:44:47 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 15:44:47 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 15:44:47 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 15:44:47 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 15:44:47 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 15:44:47 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 15:44:47 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 15:44:47 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 15:44:47 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 15:44:47 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 15:44:47 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 15:44:47 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 15:44:47 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 15:44:47 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 15:44:47 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 15:44:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-12 16:51:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-12 16:53:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-12 16:53:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:53:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:53:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:53:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:53:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:53:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:53:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:53:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:53:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:53:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:53:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:53:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:53:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:53:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:53:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:53:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:53:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:53:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:53:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:53:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:53:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:53:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:53:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:53:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:53:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:53:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:53:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-12 16:56:24 --> Severity: error --> Exception: Call to undefined method CI_Router::method() /var/www/html/equizAdmindesign/application/views/header.php 283
ERROR - 2020-03-12 16:56:27 --> Severity: error --> Exception: Call to undefined method CI_Router::method() /var/www/html/equizAdmindesign/application/views/header.php 283
ERROR - 2020-03-12 16:57:04 --> Severity: error --> Exception: Call to undefined method CI_Router::method() /var/www/html/equizAdmindesign/application/views/header.php 283
ERROR - 2020-03-12 16:57:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-12 16:58:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-12 16:58:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-12 16:58:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:58:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:58:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:58:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:58:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:58:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:58:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:58:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:58:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:58:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:58:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:58:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:58:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:58:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:58:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:58:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:58:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:58:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:58:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:58:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:58:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:58:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:58:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:58:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:58:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:58:07 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:59:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:59:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:59:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:59:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:59:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:59:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:59:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:59:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:59:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:59:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:59:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:59:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:59:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:59:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:59:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:59:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:59:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:59:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:59:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:59:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:59:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:59:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:59:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:59:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:59:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 16:59:29 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:00:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-12 17:01:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-12 17:01:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:36 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:01:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:05:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-12 17:05:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:05:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:05:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:05:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:05:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:05:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:05:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:05:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:05:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:05:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:05:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:05:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:05:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:05:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:05:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:05:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:05:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:05:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:05:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:05:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:05:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:05:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:05:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:05:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:05:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:05:04 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:09:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:09:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:09:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:09:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:09:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:09:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:09:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:09:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:09:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:09:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:09:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:09:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:09:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:09:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:09:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:09:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:09:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:09:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:09:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:09:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:09:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:09:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:09:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:09:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:09:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:09:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-12 17:09:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-12 18:38:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-12 18:39:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-12 18:40:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 162
ERROR - 2020-03-12 18:40:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 5
ERROR - 2020-03-12 18:40:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 162
ERROR - 2020-03-12 18:40:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 5
ERROR - 2020-03-12 18:41:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 162
ERROR - 2020-03-12 18:41:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 4
ERROR - 2020-03-12 18:42:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 162
ERROR - 2020-03-12 18:42:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 4
ERROR - 2020-03-12 18:42:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 162
ERROR - 2020-03-12 18:42:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 4
ERROR - 2020-03-12 18:42:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 162
ERROR - 2020-03-12 18:42:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 4
ERROR - 2020-03-12 18:44:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 162
ERROR - 2020-03-12 18:44:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 4
ERROR - 2020-03-12 18:48:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 162
ERROR - 2020-03-12 18:48:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 5
ERROR - 2020-03-12 18:48:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 162
ERROR - 2020-03-12 18:48:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/agency_management_menu.php 5
ERROR - 2020-03-12 18:52:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 162
ERROR - 2020-03-12 18:52:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 162
ERROR - 2020-03-12 18:53:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 162
ERROR - 2020-03-12 18:53:03 --> Severity: error --> Exception: Too few arguments to function CI_Config::item(), 0 passed in /var/www/html/equizAdmindesign/application/views/agency_management_menu.php on line 3 and at least 1 expected /var/www/html/equizAdmindesign/system/core/Config.php 197
ERROR - 2020-03-12 18:53:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 162
ERROR - 2020-03-12 18:53:13 --> Severity: error --> Exception: Too few arguments to function CI_Config::item(), 0 passed in /var/www/html/equizAdmindesign/application/views/agency_management_menu.php on line 3 and at least 1 expected /var/www/html/equizAdmindesign/system/core/Config.php 197
ERROR - 2020-03-12 18:53:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 162
ERROR - 2020-03-12 18:53:16 --> Severity: error --> Exception: Too few arguments to function CI_Config::item(), 0 passed in /var/www/html/equizAdmindesign/application/views/agency_management_menu.php on line 3 and at least 1 expected /var/www/html/equizAdmindesign/system/core/Config.php 197
ERROR - 2020-03-12 18:53:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 162
ERROR - 2020-03-12 18:53:27 --> Severity: error --> Exception: Too few arguments to function CI_Config::item(), 0 passed in /var/www/html/equizAdmindesign/application/views/agency_management_menu.php on line 3 and at least 1 expected /var/www/html/equizAdmindesign/system/core/Config.php 197
ERROR - 2020-03-12 18:54:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 162
ERROR - 2020-03-12 18:54:37 --> Severity: error --> Exception: Too few arguments to function CI_Config::item(), 0 passed in /var/www/html/equizAdmindesign/application/views/agency_management_menu.php on line 3 and at least 1 expected /var/www/html/equizAdmindesign/system/core/Config.php 197
ERROR - 2020-03-12 18:54:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 162
ERROR - 2020-03-12 18:54:58 --> Severity: error --> Exception: Too few arguments to function CI_Config::item(), 0 passed in /var/www/html/equizAdmindesign/application/views/agency_management_menu.php on line 3 and at least 1 expected /var/www/html/equizAdmindesign/system/core/Config.php 197
ERROR - 2020-03-12 18:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 162
ERROR - 2020-03-12 18:55:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 162
ERROR - 2020-03-12 18:56:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 162
ERROR - 2020-03-12 18:56:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 162
ERROR - 2020-03-12 18:56:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 162
ERROR - 2020-03-12 18:56:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 162
