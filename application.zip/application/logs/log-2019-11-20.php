<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-20 11:03:11 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 237
ERROR - 2019-11-20 11:28:43 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 237
ERROR - 2019-11-20 12:32:28 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equiz/application/models/Quiz_model.php 202
ERROR - 2019-11-20 12:32:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/models/Quiz_model.php 252
ERROR - 2019-11-20 18:44:31 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 237
