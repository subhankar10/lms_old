<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-13 11:10:23 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 237
ERROR - 2019-12-13 17:18:32 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 237
