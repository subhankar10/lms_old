<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-27 11:13:16 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 294
