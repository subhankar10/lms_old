<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-17 12:26:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 184
ERROR - 2020-02-17 12:27:43 --> Could not find the language line "select_type"
ERROR - 2020-02-17 12:27:43 --> Could not find the language line "select_type"
ERROR - 2020-02-17 12:27:43 --> Could not find the language line "select_add"
ERROR - 2020-02-17 12:27:43 --> Could not find the language line "select_deduct"
ERROR - 2020-02-17 16:29:08 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-17 16:29:08 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-17 16:29:08 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-17 16:29:08 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-17 16:29:11 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-17 16:29:11 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-17 16:29:11 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-17 16:29:11 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-17 16:30:39 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-17 16:30:39 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-17 16:30:39 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-17 16:30:39 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-17 16:33:39 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-17 16:33:39 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-17 16:33:39 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-17 16:33:39 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-17 16:33:57 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-17 16:33:57 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-17 16:33:57 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-17 16:33:57 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-17 16:34:58 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-17 16:34:58 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-17 16:34:58 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-17 16:34:58 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-17 16:35:14 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-17 16:35:14 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-17 16:35:14 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-17 16:35:14 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-17 16:35:38 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-17 16:35:38 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-17 16:35:38 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-17 16:35:38 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-17 17:24:48 --> Severity: Warning --> Use of undefined constant SITE_ROOT - assumed 'SITE_ROOT' (this will throw an Error in a future version of PHP) /var/www/html/equizAdmindesign/application/views/mail/registration.php 1
ERROR - 2020-02-17 17:24:48 --> Severity: Warning --> include(SITE_ROOTviews/mail/header.php): failed to open stream: No such file or directory /var/www/html/equizAdmindesign/application/views/mail/registration.php 1
ERROR - 2020-02-17 17:24:48 --> Severity: Warning --> include(): Failed opening 'SITE_ROOTviews/mail/header.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/equizAdmindesign/application/views/mail/registration.php 1
ERROR - 2020-02-17 17:24:48 --> Severity: Warning --> Use of undefined constant SITE_ROOT - assumed 'SITE_ROOT' (this will throw an Error in a future version of PHP) /var/www/html/equizAdmindesign/application/views/mail/registration.php 30
ERROR - 2020-02-17 17:24:48 --> Severity: Warning --> include(SITE_ROOTviews/mail/footer.php): failed to open stream: No such file or directory /var/www/html/equizAdmindesign/application/views/mail/registration.php 30
ERROR - 2020-02-17 17:24:48 --> Severity: Warning --> include(): Failed opening 'SITE_ROOTviews/mail/footer.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/equizAdmindesign/application/views/mail/registration.php 30
ERROR - 2020-02-17 17:34:42 --> Severity: Warning --> Use of undefined constant SITE_ROOT - assumed 'SITE_ROOT' (this will throw an Error in a future version of PHP) /var/www/html/equizAdmindesign/application/views/mail/registration.php 1
ERROR - 2020-02-17 17:34:42 --> Severity: Warning --> include(SITE_ROOTviews/mail/header.php): failed to open stream: No such file or directory /var/www/html/equizAdmindesign/application/views/mail/registration.php 1
ERROR - 2020-02-17 17:34:42 --> Severity: Warning --> include(): Failed opening 'SITE_ROOTviews/mail/header.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/equizAdmindesign/application/views/mail/registration.php 1
ERROR - 2020-02-17 17:34:42 --> Severity: Warning --> Use of undefined constant SITE_ROOT - assumed 'SITE_ROOT' (this will throw an Error in a future version of PHP) /var/www/html/equizAdmindesign/application/views/mail/registration.php 30
ERROR - 2020-02-17 17:34:42 --> Severity: Warning --> include(SITE_ROOTviews/mail/footer.php): failed to open stream: No such file or directory /var/www/html/equizAdmindesign/application/views/mail/registration.php 30
ERROR - 2020-02-17 17:34:42 --> Severity: Warning --> include(): Failed opening 'SITE_ROOTviews/mail/footer.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/equizAdmindesign/application/views/mail/registration.php 30
ERROR - 2020-02-17 17:38:11 --> Severity: Warning --> Use of undefined constant SITE_ROOT - assumed 'SITE_ROOT' (this will throw an Error in a future version of PHP) /var/www/html/equizAdmindesign/application/views/mail/registration.php 1
ERROR - 2020-02-17 17:38:11 --> Severity: Warning --> include(SITE_ROOTviews/mail/header.php): failed to open stream: No such file or directory /var/www/html/equizAdmindesign/application/views/mail/registration.php 1
ERROR - 2020-02-17 17:38:11 --> Severity: Warning --> include(): Failed opening 'SITE_ROOTviews/mail/header.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/equizAdmindesign/application/views/mail/registration.php 1
ERROR - 2020-02-17 17:38:11 --> Severity: Warning --> Use of undefined constant SITE_ROOT - assumed 'SITE_ROOT' (this will throw an Error in a future version of PHP) /var/www/html/equizAdmindesign/application/views/mail/registration.php 30
ERROR - 2020-02-17 17:38:11 --> Severity: Warning --> include(SITE_ROOTviews/mail/footer.php): failed to open stream: No such file or directory /var/www/html/equizAdmindesign/application/views/mail/registration.php 30
ERROR - 2020-02-17 17:38:11 --> Severity: Warning --> include(): Failed opening 'SITE_ROOTviews/mail/footer.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/equizAdmindesign/application/views/mail/registration.php 30
ERROR - 2020-02-17 18:22:11 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-17 18:22:11 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-17 18:22:11 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-17 18:22:11 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-17 18:22:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 184
ERROR - 2020-02-17 18:45:46 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'equiz_live.pi.rid' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT ks.examiner_id, ks.scorer_id, ks.student_id, ku.first_name, ku.last_name, kq.quiz_name,kq.vocabulary_flag,kq.structure_flag,kq.fluency_flag,kq.pronunciation_flag,kq.comprehension_flag, p1.rid,p1.quid,p1.uid,p1.result_status,p1.video_conference_flag FROM kams_result p1 INNER JOIN (SELECT pi.rid, MAX(pi.rid) AS maxpostid FROM kams_result pi GROUP BY pi.quid) p2 ON (p1.rid = p2.maxpostid)LEFT JOIN kams_users AS ku ON ku.uid = p1.uid LEFT JOIN kams_quiz AS kq ON kq.quid = p1.quid LEFT JOIN kams_students_exam_subscription AS ks ON ks.subscription_id = p1.subscription_id
ERROR - 2020-02-17 18:45:46 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmindesign/application/controllers/Examiner.php 262
ERROR - 2020-02-17 18:59:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 184
ERROR - 2020-02-17 19:29:22 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-17 19:29:22 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-17 19:29:22 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-17 19:29:22 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-17 19:29:25 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-17 19:29:25 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-17 19:29:25 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-17 19:29:25 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-17 19:35:51 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-17 19:35:51 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-17 19:35:51 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-17 19:35:51 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-17 19:39:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 184
ERROR - 2020-02-17 20:37:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 184
