<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-01 10:08:52 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 294
ERROR - 2020-01-01 10:09:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/new_question_1.php 28
ERROR - 2020-01-01 10:09:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/new_question_1.php 41
ERROR - 2020-01-01 10:09:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/new_question_1.php 54
ERROR - 2020-01-01 10:10:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/new_question_1.php 28
ERROR - 2020-01-01 10:10:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/new_question_1.php 41
ERROR - 2020-01-01 10:10:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/new_question_1.php 54
ERROR - 2020-01-01 10:11:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/new_question_1.php 28
ERROR - 2020-01-01 10:11:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/new_question_1.php 41
ERROR - 2020-01-01 10:11:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/new_question_1.php 54
