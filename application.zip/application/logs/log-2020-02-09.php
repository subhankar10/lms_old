<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-09 09:51:42 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-09 09:51:42 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-09 09:51:42 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-09 09:51:42 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-09 10:02:04 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-09 10:02:04 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-09 10:02:04 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-09 10:02:04 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-09 10:02:04 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-09 10:02:04 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-09 10:04:52 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-09 10:04:52 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-09 10:04:52 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-09 10:04:52 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-09 10:04:52 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-09 10:04:52 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-09 10:04:58 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-09 10:04:58 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-09 10:04:58 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-09 10:04:58 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-09 10:04:58 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-09 10:04:58 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-09 10:07:07 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-09 10:07:07 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-09 10:07:07 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-09 10:07:07 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-09 10:07:07 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-09 10:07:07 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-09 10:10:56 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-09 10:10:56 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-09 10:10:56 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-09 10:10:56 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-09 10:10:56 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-09 10:10:56 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-09 10:13:51 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-09 10:13:51 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-09 10:13:51 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-09 10:13:51 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-09 10:13:51 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-09 10:13:51 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-09 10:16:07 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-09 10:16:07 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-09 10:16:07 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-09 10:16:07 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-09 10:16:07 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-09 10:16:07 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-09 10:18:17 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-09 10:18:17 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-09 10:18:17 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-09 10:18:17 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-09 10:18:17 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-09 10:18:17 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-09 10:24:17 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-09 10:24:17 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-09 10:24:17 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-09 10:24:17 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-09 10:24:17 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-09 10:24:17 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-09 10:33:12 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-09 10:33:12 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-09 10:33:12 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-09 10:33:12 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-09 10:33:12 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-09 10:33:12 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-09 10:36:18 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-09 10:36:18 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-09 10:36:18 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-09 10:36:18 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-09 10:36:18 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-09 10:36:18 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-09 10:36:45 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-09 10:36:45 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-09 10:36:45 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-09 10:36:45 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-09 10:36:45 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-09 10:36:45 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-09 11:02:32 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-09 11:02:32 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-09 11:02:32 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-09 11:02:32 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-09 11:02:32 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-09 11:02:32 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-09 11:52:53 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/views/view_result.php 204
ERROR - 2020-02-09 11:52:53 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/views/view_result.php 205
ERROR - 2020-02-09 11:52:53 --> Could not find the language line "hello"
ERROR - 2020-02-09 11:52:53 --> Could not find the language line "user_id"
ERROR - 2020-02-09 11:52:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmindesign/application/views/view_result.php 325
ERROR - 2020-02-09 11:52:53 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/views/view_result.php 330
ERROR - 2020-02-09 11:52:53 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/views/view_result.php 332
ERROR - 2020-02-09 11:52:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/view_result.php 840
ERROR - 2020-02-09 11:52:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/view_result.php 1143
ERROR - 2020-02-09 12:05:53 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/views/view_result.php 204
ERROR - 2020-02-09 12:05:53 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/views/view_result.php 205
ERROR - 2020-02-09 12:05:53 --> Could not find the language line "hello"
ERROR - 2020-02-09 12:05:53 --> Could not find the language line "user_id"
ERROR - 2020-02-09 12:05:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmindesign/application/views/view_result.php 325
ERROR - 2020-02-09 12:05:53 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/views/view_result.php 330
ERROR - 2020-02-09 12:05:53 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/views/view_result.php 332
ERROR - 2020-02-09 12:05:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/view_result.php 840
ERROR - 2020-02-09 12:05:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/view_result.php 1143
ERROR - 2020-02-09 12:34:49 --> Severity: error --> Exception: Call to undefined function ordinal() /var/www/html/equizAdmindesign/application/views/view_result.php 38
ERROR - 2020-02-09 12:35:31 --> Severity: error --> Exception: Call to undefined function ordinal() /var/www/html/equizAdmindesign/application/views/view_result.php 38
ERROR - 2020-02-09 12:37:14 --> Severity: error --> Exception: Call to undefined function ordinal() /var/www/html/equizAdmindesign/application/views/view_result.php 40
ERROR - 2020-02-09 12:37:25 --> Severity: error --> Exception: Call to undefined function ordinal() /var/www/html/equizAdmindesign/application/views/view_result.php 39
ERROR - 2020-02-09 12:37:56 --> Severity: error --> Exception: Call to undefined function ordinal() /var/www/html/equizAdmindesign/application/views/view_result.php 39
ERROR - 2020-02-09 12:38:21 --> Severity: error --> Exception: Call to undefined function ordinal() /var/www/html/equizAdmindesign/application/views/view_result.php 39
ERROR - 2020-02-09 12:38:33 --> Severity: error --> Exception: Call to undefined function ordinal() /var/www/html/equizAdmindesign/application/views/view_result.php 39
ERROR - 2020-02-09 12:38:35 --> Severity: error --> Exception: Call to undefined function ordinal() /var/www/html/equizAdmindesign/application/views/view_result.php 39
ERROR - 2020-02-09 12:38:59 --> Severity: error --> Exception: Call to undefined function ordinal() /var/www/html/equizAdmindesign/application/views/view_result.php 39
ERROR - 2020-02-09 12:39:24 --> Severity: error --> Exception: Call to undefined function ordinal() /var/www/html/equizAdmindesign/application/views/view_result.php 39
ERROR - 2020-02-09 12:39:53 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /var/www/html/equizAdmindesign/application/controllers/Result.php 263
ERROR - 2020-02-09 12:39:53 --> Severity: error --> Exception: Call to undefined function ordinal() /var/www/html/equizAdmindesign/application/views/view_result.php 39
ERROR - 2020-02-09 12:39:54 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /var/www/html/equizAdmindesign/application/controllers/Result.php 263
ERROR - 2020-02-09 12:39:54 --> Severity: error --> Exception: Call to undefined function ordinal() /var/www/html/equizAdmindesign/application/views/view_result.php 39
ERROR - 2020-02-09 12:40:48 --> Severity: error --> Exception: Call to undefined function ordinal() /var/www/html/equizAdmindesign/application/views/view_result.php 21
ERROR - 2020-02-09 12:41:01 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/views/view_result.php 204
ERROR - 2020-02-09 12:41:01 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/views/view_result.php 205
ERROR - 2020-02-09 12:41:01 --> Could not find the language line "hello"
ERROR - 2020-02-09 12:41:01 --> Could not find the language line "user_id"
ERROR - 2020-02-09 12:41:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmindesign/application/views/view_result.php 325
ERROR - 2020-02-09 12:41:01 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/views/view_result.php 330
ERROR - 2020-02-09 12:41:01 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/views/view_result.php 332
ERROR - 2020-02-09 12:41:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/view_result.php 840
ERROR - 2020-02-09 12:41:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/view_result.php 1143
ERROR - 2020-02-09 18:56:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 242
ERROR - 2020-02-09 18:56:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 242
ERROR - 2020-02-09 21:17:05 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-09 21:17:05 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-09 21:17:05 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-09 21:17:05 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-09 21:17:05 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-09 21:17:05 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 74
ERROR - 2020-02-09 21:17:08 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-09 21:17:08 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-09 21:17:08 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-09 21:17:08 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-09 21:17:08 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 74
