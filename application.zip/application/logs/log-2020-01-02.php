<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-02 10:23:31 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 294
ERROR - 2020-01-02 10:28:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/new_question_1.php 28
ERROR - 2020-01-02 10:28:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/new_question_1.php 41
ERROR - 2020-01-02 10:28:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/new_question_1.php 54
ERROR - 2020-01-02 10:47:02 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 294
