<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-29 17:40:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 184
ERROR - 2020-02-29 17:41:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 184
ERROR - 2020-02-29 18:50:05 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-29 18:50:05 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-29 18:50:05 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-29 18:50:05 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
ERROR - 2020-02-29 18:50:13 --> Severity: Warning --> Illegal string offset 'open' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 10
ERROR - 2020-02-29 18:50:13 --> Severity: Warning --> Illegal string offset 'close' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 11
ERROR - 2020-02-29 18:50:13 --> Severity: Warning --> Illegal string offset 'itemOpen' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 12
ERROR - 2020-02-29 18:50:13 --> Severity: Warning --> Illegal string offset 'itemClose' /var/www/html/equizAdmindesign/system/libraries/Breadcrumb.php 13
