<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-05 17:35:18 --> Could not find the language line "roles_permission"
ERROR - 2020-03-05 17:35:18 --> Could not find the language line "management_user"
ERROR - 2020-03-05 17:35:18 --> Could not find the language line "management_user"
ERROR - 2020-03-05 17:38:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-05 17:38:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 17:38:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 17:38:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 17:38:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 17:38:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 17:38:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 17:38:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 17:38:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 17:38:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 17:38:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 17:38:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 17:38:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 17:38:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 17:38:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 17:38:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 17:38:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 17:38:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 17:38:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 17:38:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 17:38:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 17:38:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 17:38:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 17:38:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 17:38:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 17:38:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 17:38:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 17:38:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-05 18:11:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-05 18:11:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 18:11:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 18:11:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 18:11:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 18:11:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 18:11:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 18:11:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 18:11:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 18:11:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 18:11:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 18:11:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 18:11:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 18:11:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 18:11:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 18:11:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 18:11:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 18:11:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 18:11:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 18:11:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 18:11:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 18:11:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 18:11:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 18:11:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 18:11:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 18:11:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 18:11:52 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-05 18:12:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-05 18:12:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 155
ERROR - 2020-03-05 18:12:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmindesign/application/views/dashboard.php 196
ERROR - 2020-03-05 18:12:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/dashboard.php 201
ERROR - 2020-03-05 18:12:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 155
ERROR - 2020-03-05 18:12:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 155
ERROR - 2020-03-05 18:12:51 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmindesign/application/views/dashboard.php 196
ERROR - 2020-03-05 18:12:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/dashboard.php 201
