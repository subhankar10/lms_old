<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-08 13:27:52 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 294
ERROR - 2020-01-08 13:28:51 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 294
ERROR - 2020-01-08 13:33:13 --> Could not find the language line "hello"
ERROR - 2020-01-08 13:33:13 --> Could not find the language line "user_id"
ERROR - 2020-01-08 13:33:13 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equiz/application/views/view_result.php 356
ERROR - 2020-01-08 13:33:45 --> Could not find the language line "hello"
ERROR - 2020-01-08 13:33:45 --> Could not find the language line "user_id"
ERROR - 2020-01-08 13:33:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equiz/application/views/view_result.php 356
ERROR - 2020-01-08 13:34:08 --> Could not find the language line "hello"
ERROR - 2020-01-08 13:34:08 --> Could not find the language line "user_id"
ERROR - 2020-01-08 13:34:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equiz/application/views/view_result.php 356
ERROR - 2020-01-08 13:34:23 --> Could not find the language line "hello"
ERROR - 2020-01-08 13:34:23 --> Could not find the language line "user_id"
ERROR - 2020-01-08 13:34:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equiz/application/views/view_result.php 356
ERROR - 2020-01-08 13:34:45 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 294
