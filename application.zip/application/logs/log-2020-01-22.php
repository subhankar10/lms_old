<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-22 10:42:48 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-01-22 10:48:41 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/equizAdmin/application/controllers/Schedule_time.php 59
ERROR - 2020-01-22 10:49:03 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/equizAdmin/application/controllers/Schedule_time.php 61
ERROR - 2020-01-22 10:49:04 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/equizAdmin/application/controllers/Schedule_time.php 61
ERROR - 2020-01-22 10:49:17 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/equizAdmin/application/controllers/Schedule_time.php 61
ERROR - 2020-01-22 10:49:18 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/equizAdmin/application/controllers/Schedule_time.php 61
ERROR - 2020-01-22 10:49:23 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/equizAdmin/application/controllers/Schedule_time.php 61
ERROR - 2020-01-22 10:49:39 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/equizAdmin/application/controllers/Schedule_time.php 62
ERROR - 2020-01-22 10:49:44 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/equizAdmin/application/controllers/Schedule_time.php 62
ERROR - 2020-01-22 10:49:51 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/equizAdmin/application/controllers/Schedule_time.php 62
ERROR - 2020-01-22 10:49:54 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/equizAdmin/application/controllers/Schedule_time.php 62
ERROR - 2020-01-22 10:49:54 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/equizAdmin/application/controllers/Schedule_time.php 62
ERROR - 2020-01-22 10:49:54 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/equizAdmin/application/controllers/Schedule_time.php 62
ERROR - 2020-01-22 10:49:54 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/equizAdmin/application/controllers/Schedule_time.php 62
ERROR - 2020-01-22 10:49:54 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/equizAdmin/application/controllers/Schedule_time.php 62
ERROR - 2020-01-22 10:49:54 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/equizAdmin/application/controllers/Schedule_time.php 62
ERROR - 2020-01-22 10:49:54 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/equizAdmin/application/controllers/Schedule_time.php 62
ERROR - 2020-01-22 10:49:54 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/equizAdmin/application/controllers/Schedule_time.php 62
ERROR - 2020-01-22 10:49:54 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/equizAdmin/application/controllers/Schedule_time.php 62
ERROR - 2020-01-22 10:49:54 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/equizAdmin/application/controllers/Schedule_time.php 62
ERROR - 2020-01-22 10:49:54 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/equizAdmin/application/controllers/Schedule_time.php 62
ERROR - 2020-01-22 10:49:54 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/equizAdmin/application/controllers/Schedule_time.php 62
ERROR - 2020-01-22 10:49:54 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/equizAdmin/application/controllers/Schedule_time.php 62
ERROR - 2020-01-22 10:50:06 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/equizAdmin/application/controllers/Schedule_time.php 62
ERROR - 2020-01-22 10:50:08 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/equizAdmin/application/controllers/Schedule_time.php 62
ERROR - 2020-01-22 10:50:18 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/equizAdmin/application/controllers/Schedule_time.php 60
ERROR - 2020-01-22 10:50:24 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/equizAdmin/application/controllers/Schedule_time.php 60
ERROR - 2020-01-22 10:50:40 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/equizAdmin/application/controllers/Schedule_time.php 60
ERROR - 2020-01-22 10:50:42 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/equizAdmin/application/controllers/Schedule_time.php 60
ERROR - 2020-01-22 15:51:29 --> Query error: Unknown column 'scExaminerhedule_title' in 'field list' - Invalid query: INSERT INTO `kams_schedule_quiz` (`quiz_id`, `scExaminerhedule_title`, `schedule_date`, `start_schedule`, `end_schedule`, `display_event_start`, `display_event_end`) VALUES ('18', 'Quiz Schedule 3', '2020-01-22', '2020-01-22 02:00', '2020-01-22 03:00', 'Wed Jan 22 2020 14:00:00 GMT+0530 (India Standard Time)', 'Wed Jan 22 2020 15:00:00 GMT+0530 (India Standard Time)')
ERROR - 2020-01-22 15:52:07 --> Query error: Unknown column 'scExaminerhedule_title' in 'field list' - Invalid query: INSERT INTO `kams_schedule_quiz` (`quiz_id`, `scExaminerhedule_title`, `schedule_date`, `start_schedule`, `end_schedule`, `display_event_start`, `display_event_end`) VALUES ('18', 'Quiz Schedule 3', '2020-01-22', '2020-01-22 04:00', '2020-01-22 05:00', 'Wed Jan 22 2020 04:00:00 GMT+0530 (India Standard Time)', 'Wed Jan 22 2020 05:00:00 GMT+0530 (India Standard Time)')
ERROR - 2020-01-22 15:53:59 --> Query error: Unknown column 'scExaminerhedule_title' in 'field list' - Invalid query: INSERT INTO `kams_schedule_quiz` (`quiz_id`, `scExaminerhedule_title`, `schedule_date`, `start_schedule`, `end_schedule`, `display_event_start`, `display_event_end`) VALUES ('18', 'Quiz Schedule 3', '2020-01-22', '2020-01-22 04:00', '2020-01-22 05:00', 'Wed Jan 22 2020 04:00:00 GMT+0530 (India Standard Time)', 'Wed Jan 22 2020 05:00:00 GMT+0530 (India Standard Time)')
ERROR - 2020-01-22 15:54:57 --> Query error: Unknown column 'scExaminerhedule_title' in 'field list' - Invalid query: INSERT INTO `kams_schedule_quiz` (`quiz_id`, `scExaminerhedule_title`, `schedule_date`, `start_schedule`, `end_schedule`, `display_event_start`, `display_event_end`) VALUES ('18', 'Test', '2020-01-22', '2020-01-22 03:00', '2020-01-22 04:00', 'Wed Jan 22 2020 03:00:00 GMT+0530 (India Standard Time)', 'Wed Jan 22 2020 04:00:00 GMT+0530 (India Standard Time)')
ERROR - 2020-01-22 16:59:28 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-22 16:59:28 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-22 16:59:28 --> Could not find the language line "hello"
ERROR - 2020-01-22 16:59:28 --> Could not find the language line "user_id"
ERROR - 2020-01-22 16:59:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-22 16:59:28 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-22 16:59:28 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-22 16:59:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 828
ERROR - 2020-01-22 16:59:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1131
ERROR - 2020-01-22 17:00:59 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-22 17:00:59 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-22 17:00:59 --> Could not find the language line "hello"
ERROR - 2020-01-22 17:00:59 --> Could not find the language line "user_id"
ERROR - 2020-01-22 17:00:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-22 17:00:59 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-22 17:00:59 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-22 17:00:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 828
ERROR - 2020-01-22 17:00:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1131
ERROR - 2020-01-22 17:09:41 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-01-22 17:14:32 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmin/application/models/Quiz_model.php 219
ERROR - 2020-01-22 17:14:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/models/Quiz_model.php 280
ERROR - 2020-01-22 17:14:43 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmin/application/models/Quiz_model.php 219
ERROR - 2020-01-22 17:14:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/models/Quiz_model.php 280
ERROR - 2020-01-22 19:54:35 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-01-22 19:54:56 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1579703096)
ERROR - 2020-01-22 19:57:46 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1579703266)
ERROR - 2020-01-22 19:59:33 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1579703373)
ERROR - 2020-01-22 20:17:12 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1579704432)
ERROR - 2020-01-22 20:18:15 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1579704495)
ERROR - 2020-01-22 20:19:25 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1579704565)
ERROR - 2020-01-22 20:19:43 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1579704583)
ERROR - 2020-01-22 20:23:57 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1579704837)
ERROR - 2020-01-22 20:25:05 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1579704905)
ERROR - 2020-01-22 20:25:21 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1579704921)
ERROR - 2020-01-22 20:26:20 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1579704980)
ERROR - 2020-01-22 20:27:15 --> Query error: Column 'uid' cannot be null - Invalid query: INSERT INTO `kams_result` (`quid`, `uid`, `start_time`) VALUES (18, NULL, 1579705035)
