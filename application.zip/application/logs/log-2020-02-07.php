<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-07 11:01:49 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 284
ERROR - 2020-02-07 12:19:57 --> Severity: Warning --> Division by zero /var/www/html/equizAdmindesign/application/views/dashboard.php 284
ERROR - 2020-02-07 12:29:12 --> Severity: Warning --> Division by zero /var/www/html/equizAdmindesign/application/views/dashboard.php 284
ERROR - 2020-02-07 12:29:44 --> Severity: Warning --> Division by zero /var/www/html/equizAdmindesign/application/views/dashboard.php 284
ERROR - 2020-02-07 12:29:54 --> Severity: Warning --> Division by zero /var/www/html/equizAdmindesign/application/views/dashboard.php 284
ERROR - 2020-02-07 12:29:55 --> Severity: Warning --> Division by zero /var/www/html/equizAdmindesign/application/views/dashboard.php 284
ERROR - 2020-02-07 12:31:02 --> Severity: Warning --> Division by zero /var/www/html/equizAdmindesign/application/views/dashboard.php 284
ERROR - 2020-02-07 12:31:44 --> Severity: Warning --> Division by zero /var/www/html/equizAdmindesign/application/views/dashboard.php 284
ERROR - 2020-02-07 12:32:17 --> Severity: Warning --> Division by zero /var/www/html/equizAdmindesign/application/views/dashboard.php 284
ERROR - 2020-02-07 12:32:33 --> Severity: Warning --> Division by zero /var/www/html/equizAdmindesign/application/views/dashboard.php 284
ERROR - 2020-02-07 17:24:56 --> Could not find the language line "student_subscriptionexam"
ERROR - 2020-02-07 17:26:24 --> Could not find the language line "student_subscriptionexam"
