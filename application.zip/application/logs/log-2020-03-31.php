<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-31 12:39:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/examiner_list.php 204
ERROR - 2020-03-31 12:40:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/examiner_list.php 204
ERROR - 2020-03-31 12:42:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/onlineclassroom/application/views/dashboard.php 197
ERROR - 2020-03-31 12:42:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/dashboard.php 202
ERROR - 2020-03-31 12:45:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 207
ERROR - 2020-03-31 12:46:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 207
ERROR - 2020-03-31 12:46:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/onlineclassroom/application/views/dashboard.php 197
ERROR - 2020-03-31 12:46:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/dashboard.php 202
ERROR - 2020-03-31 16:24:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/onlineclassroom/application/views/dashboard.php 168
ERROR - 2020-03-31 16:24:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/dashboard.php 178
ERROR - 2020-03-31 16:25:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/examiner_list.php 204
ERROR - 2020-03-31 16:26:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 207
ERROR - 2020-03-31 16:26:11 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/onlineclassroom/application/views/dashboard.php 168
ERROR - 2020-03-31 16:26:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/dashboard.php 178
ERROR - 2020-03-31 16:26:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/examiner_list.php 204
ERROR - 2020-03-31 16:26:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/examiner_list.php 204
ERROR - 2020-03-31 16:27:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 207
ERROR - 2020-03-31 16:29:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/userupcomingliveclassList.php 198
ERROR - 2020-03-31 16:30:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/onlineclassroom/application/views/dashboard.php 168
ERROR - 2020-03-31 16:30:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/dashboard.php 178
ERROR - 2020-03-31 16:32:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 207
ERROR - 2020-03-31 16:33:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 207
ERROR - 2020-03-31 16:33:50 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/onlineclassroom/application/views/dashboard.php 168
ERROR - 2020-03-31 16:33:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/dashboard.php 178
ERROR - 2020-03-31 16:34:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/userupcomingliveclassList.php 198
ERROR - 2020-03-31 16:34:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/userupcomingliveclassList.php 198
ERROR - 2020-03-31 16:34:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/userupcomingliveclassList.php 198
ERROR - 2020-03-31 16:35:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomPastDateList.php 245
