<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-26 11:00:42 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 263
ERROR - 2019-12-26 11:03:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 174
ERROR - 2019-12-26 11:03:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 263
ERROR - 2019-12-26 12:09:01 --> Severity: error --> Exception: syntax error, unexpected end of file /var/www/html/equiz/application/views/user_list.php 136
ERROR - 2019-12-26 13:37:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/equiz/application/controllers/Api.php 341
ERROR - 2019-12-26 13:37:09 --> Severity: Warning --> Illegal offset type in isset or empty /var/www/html/equiz/system/libraries/Upload.php 377
ERROR - 2019-12-26 13:37:09 --> Severity: Warning --> preg_match_all() expects parameter 2 to be string, object given /var/www/html/equiz/system/libraries/Upload.php 382
ERROR - 2019-12-26 13:38:19 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/equiz/application/controllers/Api.php 341
ERROR - 2019-12-26 13:38:19 --> Severity: Warning --> Illegal offset type in isset or empty /var/www/html/equiz/system/libraries/Upload.php 377
ERROR - 2019-12-26 13:38:19 --> Severity: Warning --> preg_match_all() expects parameter 2 to be string, object given /var/www/html/equiz/system/libraries/Upload.php 382
ERROR - 2019-12-26 15:51:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 174
ERROR - 2019-12-26 15:51:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 263
ERROR - 2019-12-26 15:51:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 174
ERROR - 2019-12-26 15:51:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 263
ERROR - 2019-12-26 15:52:08 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 263
ERROR - 2019-12-26 16:29:39 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 294
ERROR - 2019-12-26 16:31:10 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 294
ERROR - 2019-12-26 16:34:06 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 294
ERROR - 2019-12-26 16:34:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 174
ERROR - 2019-12-26 16:34:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 263
ERROR - 2019-12-26 16:49:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 192
ERROR - 2019-12-26 16:49:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 281
ERROR - 2019-12-26 16:50:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 200
ERROR - 2019-12-26 16:50:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 289
ERROR - 2019-12-26 16:54:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 207
ERROR - 2019-12-26 16:54:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 296
ERROR - 2019-12-26 16:54:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 207
ERROR - 2019-12-26 16:54:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 296
ERROR - 2019-12-26 16:55:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 207
ERROR - 2019-12-26 16:55:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 296
ERROR - 2019-12-26 16:56:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 210
ERROR - 2019-12-26 16:56:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 299
ERROR - 2019-12-26 16:56:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 210
ERROR - 2019-12-26 16:56:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 299
ERROR - 2019-12-26 16:56:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 210
ERROR - 2019-12-26 16:56:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 299
ERROR - 2019-12-26 16:59:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 213
ERROR - 2019-12-26 16:59:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 302
ERROR - 2019-12-26 16:59:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 213
ERROR - 2019-12-26 16:59:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 302
ERROR - 2019-12-26 16:59:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 213
ERROR - 2019-12-26 16:59:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 302
ERROR - 2019-12-26 17:01:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 216
ERROR - 2019-12-26 17:01:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 305
ERROR - 2019-12-26 17:02:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 218
ERROR - 2019-12-26 17:02:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 307
ERROR - 2019-12-26 17:02:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 218
ERROR - 2019-12-26 17:02:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 307
ERROR - 2019-12-26 17:02:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 218
ERROR - 2019-12-26 17:02:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 307
ERROR - 2019-12-26 17:03:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 218
ERROR - 2019-12-26 17:03:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 307
ERROR - 2019-12-26 17:03:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 218
ERROR - 2019-12-26 17:03:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 307
ERROR - 2019-12-26 17:03:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 218
ERROR - 2019-12-26 17:03:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 307
ERROR - 2019-12-26 17:05:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 218
ERROR - 2019-12-26 17:05:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 307
ERROR - 2019-12-26 17:06:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 218
ERROR - 2019-12-26 17:06:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 307
ERROR - 2019-12-26 17:07:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 218
ERROR - 2019-12-26 17:07:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 307
ERROR - 2019-12-26 17:08:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 218
ERROR - 2019-12-26 17:08:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 307
ERROR - 2019-12-26 17:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 218
ERROR - 2019-12-26 17:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 307
ERROR - 2019-12-26 17:29:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 218
ERROR - 2019-12-26 17:29:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 307
ERROR - 2019-12-26 17:34:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 229
ERROR - 2019-12-26 17:34:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 318
ERROR - 2019-12-26 17:36:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 234
ERROR - 2019-12-26 17:36:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 323
ERROR - 2019-12-26 17:37:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 234
ERROR - 2019-12-26 17:37:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 323
ERROR - 2019-12-26 17:37:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 234
ERROR - 2019-12-26 17:37:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 323
ERROR - 2019-12-26 17:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 231
ERROR - 2019-12-26 17:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 320
ERROR - 2019-12-26 17:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 231
ERROR - 2019-12-26 17:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/profile.php 320
ERROR - 2019-12-26 18:40:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/models/User_model.php 378
ERROR - 2019-12-26 18:44:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/models/User_model.php 378
ERROR - 2019-12-26 18:49:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/models/User_model.php 378
