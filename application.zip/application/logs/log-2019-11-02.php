<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-02 11:40:20 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 237
ERROR - 2019-11-02 16:04:07 --> Severity: Warning --> Use of undefined constant APP_ROOT - assumed 'APP_ROOT' (this will throw an Error in a future version of PHP) /var/www/html/equiz/application/models/Qbank_model.php 106
ERROR - 2019-11-02 16:04:07 --> The upload path does not appear to be valid.
ERROR - 2019-11-02 16:07:45 --> Severity: Warning --> Use of undefined constant APP_ROOT - assumed 'APP_ROOT' (this will throw an Error in a future version of PHP) /var/www/html/equiz/application/models/Qbank_model.php 106
ERROR - 2019-11-02 16:07:45 --> The upload path does not appear to be valid.
ERROR - 2019-11-02 16:09:35 --> Severity: Warning --> Use of undefined constant APP_ROOT - assumed 'APP_ROOT' (this will throw an Error in a future version of PHP) /var/www/html/equiz/application/models/Qbank_model.php 106
ERROR - 2019-11-02 16:09:35 --> The upload path does not appear to be valid.
ERROR - 2019-11-02 16:10:50 --> Severity: Warning --> Use of undefined constant APP_ROOT - assumed 'APP_ROOT' (this will throw an Error in a future version of PHP) /var/www/html/equiz/application/models/Qbank_model.php 106
ERROR - 2019-11-02 16:10:50 --> The upload path does not appear to be valid.
