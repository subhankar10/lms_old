<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-26 11:09:43 --> Severity: Warning --> Use of undefined constant SITE_ROOT - assumed 'SITE_ROOT' (this will throw an Error in a future version of PHP) /var/www/html/equizAdmindesign/application/views/mail/registration.php 1
ERROR - 2020-02-26 11:09:43 --> Severity: Warning --> include(SITE_ROOTviews/mail/header.php): failed to open stream: No such file or directory /var/www/html/equizAdmindesign/application/views/mail/registration.php 1
ERROR - 2020-02-26 11:09:43 --> Severity: Warning --> include(): Failed opening 'SITE_ROOTviews/mail/header.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/equizAdmindesign/application/views/mail/registration.php 1
ERROR - 2020-02-26 11:09:43 --> Severity: Warning --> Use of undefined constant SITE_ROOT - assumed 'SITE_ROOT' (this will throw an Error in a future version of PHP) /var/www/html/equizAdmindesign/application/views/mail/registration.php 30
ERROR - 2020-02-26 11:09:43 --> Severity: Warning --> include(SITE_ROOTviews/mail/footer.php): failed to open stream: No such file or directory /var/www/html/equizAdmindesign/application/views/mail/registration.php 30
ERROR - 2020-02-26 11:09:43 --> Severity: Warning --> include(): Failed opening 'SITE_ROOTviews/mail/footer.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/equizAdmindesign/application/views/mail/registration.php 30
