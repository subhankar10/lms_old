<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-15 10:41:35 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-01-15 10:44:18 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-01-15 10:47:27 --> Could not find the language line "hello"
ERROR - 2020-01-15 10:47:27 --> Could not find the language line "user_id"
ERROR - 2020-01-15 10:47:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 356
ERROR - 2020-01-15 11:10:46 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-01-15 11:11:33 --> Could not find the language line "hello"
ERROR - 2020-01-15 11:11:33 --> Could not find the language line "user_id"
ERROR - 2020-01-15 11:11:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 356
ERROR - 2020-01-15 12:46:40 --> Could not find the language line "hello"
ERROR - 2020-01-15 12:46:40 --> Could not find the language line "user_id"
ERROR - 2020-01-15 12:46:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 356
ERROR - 2020-01-15 12:56:11 --> Could not find the language line "hello"
ERROR - 2020-01-15 12:56:11 --> Could not find the language line "user_id"
ERROR - 2020-01-15 12:56:11 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 356
ERROR - 2020-01-15 13:04:52 --> Could not find the language line "hello"
ERROR - 2020-01-15 13:04:52 --> Could not find the language line "user_id"
ERROR - 2020-01-15 13:04:52 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 356
ERROR - 2020-01-15 13:11:06 --> Could not find the language line "hello"
ERROR - 2020-01-15 13:11:06 --> Could not find the language line "user_id"
ERROR - 2020-01-15 13:11:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 319
ERROR - 2020-01-15 13:13:49 --> Could not find the language line "hello"
ERROR - 2020-01-15 13:13:49 --> Could not find the language line "user_id"
ERROR - 2020-01-15 13:13:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 323
ERROR - 2020-01-15 13:15:47 --> Could not find the language line "hello"
ERROR - 2020-01-15 13:15:47 --> Could not find the language line "user_id"
ERROR - 2020-01-15 13:15:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 323
ERROR - 2020-01-15 13:18:55 --> Could not find the language line "hello"
ERROR - 2020-01-15 13:18:55 --> Could not find the language line "user_id"
ERROR - 2020-01-15 13:18:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 323
ERROR - 2020-01-15 14:34:56 --> Could not find the language line "hello"
ERROR - 2020-01-15 14:34:56 --> Could not find the language line "user_id"
ERROR - 2020-01-15 14:34:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 323
ERROR - 2020-01-15 14:53:06 --> Could not find the language line "hello"
ERROR - 2020-01-15 14:53:06 --> Could not find the language line "user_id"
ERROR - 2020-01-15 14:53:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 323
ERROR - 2020-01-15 15:34:28 --> Could not find the language line "hello"
ERROR - 2020-01-15 15:34:28 --> Could not find the language line "user_id"
ERROR - 2020-01-15 15:34:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 323
ERROR - 2020-01-15 15:35:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') order by FIELD(kams_options.qid,)' at line 1 - Invalid query: select * from kams_options where qid in () order by FIELD(kams_options.qid,)
ERROR - 2020-01-15 15:35:21 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/models/Quiz_model.php 355
ERROR - 2020-01-15 15:35:26 --> Could not find the language line "hello"
ERROR - 2020-01-15 15:35:26 --> Could not find the language line "user_id"
ERROR - 2020-01-15 15:35:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 323
ERROR - 2020-01-15 15:36:22 --> Could not find the language line "hello"
ERROR - 2020-01-15 15:36:22 --> Could not find the language line "user_id"
ERROR - 2020-01-15 15:36:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 323
ERROR - 2020-01-15 15:36:27 --> Could not find the language line "hello"
ERROR - 2020-01-15 15:36:27 --> Could not find the language line "user_id"
ERROR - 2020-01-15 15:36:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 323
ERROR - 2020-01-15 15:36:35 --> Could not find the language line "hello"
ERROR - 2020-01-15 15:36:35 --> Could not find the language line "user_id"
ERROR - 2020-01-15 15:36:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 323
ERROR - 2020-01-15 15:37:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') order by FIELD(kams_options.qid,)' at line 1 - Invalid query: select * from kams_options where qid in () order by FIELD(kams_options.qid,)
ERROR - 2020-01-15 15:37:05 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/models/Quiz_model.php 355
ERROR - 2020-01-15 15:39:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') order by FIELD(kams_options.qid,)' at line 1 - Invalid query: select * from kams_options where qid in () order by FIELD(kams_options.qid,)
ERROR - 2020-01-15 15:39:25 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/models/Quiz_model.php 355
ERROR - 2020-01-15 15:39:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') order by FIELD(kams_options.qid,)' at line 1 - Invalid query: select * from kams_options where qid in () order by FIELD(kams_options.qid,)
ERROR - 2020-01-15 15:39:38 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/models/Quiz_model.php 355
ERROR - 2020-01-15 15:39:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') order by FIELD(kams_options.qid,)' at line 1 - Invalid query: select * from kams_options where qid in () order by FIELD(kams_options.qid,)
ERROR - 2020-01-15 15:39:41 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/models/Quiz_model.php 355
ERROR - 2020-01-15 15:39:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') order by FIELD(kams_options.qid,)' at line 1 - Invalid query: select * from kams_options where qid in () order by FIELD(kams_options.qid,)
ERROR - 2020-01-15 15:39:43 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/models/Quiz_model.php 355
ERROR - 2020-01-15 15:40:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') order by FIELD(kams_options.qid,)' at line 1 - Invalid query: select * from kams_options where qid in () order by FIELD(kams_options.qid,)
ERROR - 2020-01-15 15:40:01 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/models/Quiz_model.php 355
ERROR - 2020-01-15 15:50:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') order by FIELD(kams_options.qid,)' at line 1 - Invalid query: select * from kams_options where qid in () order by FIELD(kams_options.qid,)
ERROR - 2020-01-15 15:50:22 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/models/Quiz_model.php 355
ERROR - 2020-01-15 15:50:28 --> Could not find the language line "hello"
ERROR - 2020-01-15 15:50:28 --> Could not find the language line "user_id"
ERROR - 2020-01-15 15:50:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 323
ERROR - 2020-01-15 15:58:42 --> Could not find the language line "hello"
ERROR - 2020-01-15 15:58:42 --> Could not find the language line "user_id"
ERROR - 2020-01-15 15:58:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 323
ERROR - 2020-01-15 15:59:01 --> Could not find the language line "hello"
ERROR - 2020-01-15 15:59:01 --> Could not find the language line "user_id"
ERROR - 2020-01-15 15:59:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 323
ERROR - 2020-01-15 15:59:25 --> Could not find the language line "hello"
ERROR - 2020-01-15 15:59:25 --> Could not find the language line "user_id"
ERROR - 2020-01-15 15:59:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 323
ERROR - 2020-01-15 15:59:47 --> Could not find the language line "hello"
ERROR - 2020-01-15 15:59:47 --> Could not find the language line "user_id"
ERROR - 2020-01-15 15:59:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 323
ERROR - 2020-01-15 16:08:15 --> Could not find the language line "hello"
ERROR - 2020-01-15 16:08:15 --> Could not find the language line "user_id"
ERROR - 2020-01-15 16:08:15 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 323
ERROR - 2020-01-15 16:17:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') order by FIELD(kams_options.qid,)' at line 1 - Invalid query: select * from kams_options where qid in () order by FIELD(kams_options.qid,)
ERROR - 2020-01-15 16:17:23 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/models/Quiz_model.php 355
ERROR - 2020-01-15 16:17:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') order by FIELD(kams_options.qid,)' at line 1 - Invalid query: select * from kams_options where qid in () order by FIELD(kams_options.qid,)
ERROR - 2020-01-15 16:17:25 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/models/Quiz_model.php 355
ERROR - 2020-01-15 16:19:16 --> Could not find the language line "hello"
ERROR - 2020-01-15 16:19:16 --> Could not find the language line "user_id"
ERROR - 2020-01-15 16:19:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 320
ERROR - 2020-01-15 16:19:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') order by FIELD(kams_options.qid,)' at line 1 - Invalid query: select * from kams_options where qid in () order by FIELD(kams_options.qid,)
ERROR - 2020-01-15 16:19:18 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/models/Quiz_model.php 355
ERROR - 2020-01-15 16:19:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') order by FIELD(kams_options.qid,)' at line 1 - Invalid query: select * from kams_options where qid in () order by FIELD(kams_options.qid,)
ERROR - 2020-01-15 16:19:21 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/models/Quiz_model.php 355
ERROR - 2020-01-15 16:20:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') order by FIELD(kams_options.qid,)' at line 1 - Invalid query: select * from kams_options where qid in () order by FIELD(kams_options.qid,)
ERROR - 2020-01-15 16:20:03 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/models/Quiz_model.php 355
ERROR - 2020-01-15 16:20:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') order by FIELD(kams_options.qid,)' at line 1 - Invalid query: select * from kams_options where qid in () order by FIELD(kams_options.qid,)
ERROR - 2020-01-15 16:20:05 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/models/Quiz_model.php 355
ERROR - 2020-01-15 16:20:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') order by FIELD(kams_options.qid,)' at line 1 - Invalid query: select * from kams_options where qid in () order by FIELD(kams_options.qid,)
ERROR - 2020-01-15 16:20:45 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/models/Quiz_model.php 355
ERROR - 2020-01-15 16:21:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') order by FIELD(kams_options.qid,)' at line 1 - Invalid query: select * from kams_options where qid in () order by FIELD(kams_options.qid,)
ERROR - 2020-01-15 16:21:01 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/models/Quiz_model.php 355
ERROR - 2020-01-15 16:21:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') order by FIELD(kams_options.qid,)' at line 1 - Invalid query: select * from kams_options where qid in () order by FIELD(kams_options.qid,)
ERROR - 2020-01-15 16:21:23 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/models/Quiz_model.php 355
ERROR - 2020-01-15 16:22:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') order by FIELD(kams_options.qid,)' at line 1 - Invalid query: select * from kams_options where qid in () order by FIELD(kams_options.qid,)
ERROR - 2020-01-15 16:22:15 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/models/Quiz_model.php 355
ERROR - 2020-01-15 16:22:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') order by FIELD(kams_options.qid,)' at line 1 - Invalid query: select * from kams_options where qid in () order by FIELD(kams_options.qid,)
ERROR - 2020-01-15 16:22:29 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/models/Quiz_model.php 355
ERROR - 2020-01-15 16:26:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') order by FIELD(kams_options.qid,)' at line 1 - Invalid query: select * from kams_options where qid in () order by FIELD(kams_options.qid,)
ERROR - 2020-01-15 16:26:08 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/models/Quiz_model.php 355
ERROR - 2020-01-15 16:26:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') order by FIELD(kams_options.qid,)' at line 1 - Invalid query: select * from kams_options where qid in () order by FIELD(kams_options.qid,)
ERROR - 2020-01-15 16:26:42 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/models/Quiz_model.php 355
ERROR - 2020-01-15 16:27:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') order by FIELD(kams_options.qid,)' at line 1 - Invalid query: select * from kams_options where qid in () order by FIELD(kams_options.qid,)
ERROR - 2020-01-15 16:27:03 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/equizAdmin/application/models/Quiz_model.php 355
ERROR - 2020-01-15 16:46:37 --> Could not find the language line "hello"
ERROR - 2020-01-15 16:46:37 --> Could not find the language line "user_id"
ERROR - 2020-01-15 16:46:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 323
ERROR - 2020-01-15 16:46:46 --> Could not find the language line "hello"
ERROR - 2020-01-15 16:46:46 --> Could not find the language line "user_id"
ERROR - 2020-01-15 16:46:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 323
ERROR - 2020-01-15 16:47:09 --> Could not find the language line "hello"
ERROR - 2020-01-15 16:47:09 --> Could not find the language line "user_id"
ERROR - 2020-01-15 16:47:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 323
ERROR - 2020-01-15 16:50:20 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 16:50:20 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 16:50:20 --> Could not find the language line "hello"
ERROR - 2020-01-15 16:50:20 --> Could not find the language line "user_id"
ERROR - 2020-01-15 16:50:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 323
ERROR - 2020-01-15 16:50:20 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 328
ERROR - 2020-01-15 16:50:20 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 330
ERROR - 2020-01-15 16:50:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 797
ERROR - 2020-01-15 16:50:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1100
ERROR - 2020-01-15 16:56:45 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 16:56:45 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 16:56:45 --> Could not find the language line "hello"
ERROR - 2020-01-15 16:56:45 --> Could not find the language line "user_id"
ERROR - 2020-01-15 16:56:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 323
ERROR - 2020-01-15 16:56:45 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 328
ERROR - 2020-01-15 16:56:45 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 330
ERROR - 2020-01-15 16:56:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 797
ERROR - 2020-01-15 16:56:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1100
ERROR - 2020-01-15 16:57:33 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 16:57:33 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 16:57:33 --> Could not find the language line "hello"
ERROR - 2020-01-15 16:57:33 --> Could not find the language line "user_id"
ERROR - 2020-01-15 16:57:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 323
ERROR - 2020-01-15 16:57:33 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 328
ERROR - 2020-01-15 16:57:33 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 330
ERROR - 2020-01-15 16:57:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 797
ERROR - 2020-01-15 16:57:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1100
ERROR - 2020-01-15 16:57:49 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 16:57:49 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 16:57:49 --> Could not find the language line "hello"
ERROR - 2020-01-15 16:57:49 --> Could not find the language line "user_id"
ERROR - 2020-01-15 16:57:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 323
ERROR - 2020-01-15 16:57:49 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 328
ERROR - 2020-01-15 16:57:49 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 330
ERROR - 2020-01-15 16:57:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 797
ERROR - 2020-01-15 16:57:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1100
ERROR - 2020-01-15 17:16:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 17:16:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 17:16:21 --> Could not find the language line "hello"
ERROR - 2020-01-15 17:16:21 --> Could not find the language line "user_id"
ERROR - 2020-01-15 17:16:21 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 337
ERROR - 2020-01-15 17:16:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 342
ERROR - 2020-01-15 17:16:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 344
ERROR - 2020-01-15 17:16:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 811
ERROR - 2020-01-15 17:16:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1114
ERROR - 2020-01-15 17:16:22 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 17:16:22 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 17:16:22 --> Could not find the language line "hello"
ERROR - 2020-01-15 17:16:22 --> Could not find the language line "user_id"
ERROR - 2020-01-15 17:16:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 337
ERROR - 2020-01-15 17:16:22 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 342
ERROR - 2020-01-15 17:16:22 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 344
ERROR - 2020-01-15 17:16:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 811
ERROR - 2020-01-15 17:16:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1114
ERROR - 2020-01-15 17:16:41 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 17:16:41 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 17:16:41 --> Could not find the language line "hello"
ERROR - 2020-01-15 17:16:41 --> Could not find the language line "user_id"
ERROR - 2020-01-15 17:16:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 338
ERROR - 2020-01-15 17:16:41 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 343
ERROR - 2020-01-15 17:16:41 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 345
ERROR - 2020-01-15 17:16:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 812
ERROR - 2020-01-15 17:16:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1115
ERROR - 2020-01-15 17:18:22 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 17:18:22 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 17:18:22 --> Could not find the language line "hello"
ERROR - 2020-01-15 17:18:22 --> Could not find the language line "user_id"
ERROR - 2020-01-15 17:18:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 332
ERROR - 2020-01-15 17:18:22 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 337
ERROR - 2020-01-15 17:18:22 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 339
ERROR - 2020-01-15 17:18:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 806
ERROR - 2020-01-15 17:18:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1109
ERROR - 2020-01-15 17:19:32 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 17:19:32 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 17:19:32 --> Could not find the language line "hello"
ERROR - 2020-01-15 17:19:32 --> Could not find the language line "user_id"
ERROR - 2020-01-15 17:19:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 337
ERROR - 2020-01-15 17:19:32 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 342
ERROR - 2020-01-15 17:19:32 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 344
ERROR - 2020-01-15 17:19:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 811
ERROR - 2020-01-15 17:19:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1114
ERROR - 2020-01-15 17:20:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 17:20:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 17:20:29 --> Could not find the language line "hello"
ERROR - 2020-01-15 17:20:29 --> Could not find the language line "user_id"
ERROR - 2020-01-15 17:20:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 337
ERROR - 2020-01-15 17:20:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 342
ERROR - 2020-01-15 17:20:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 344
ERROR - 2020-01-15 17:20:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 811
ERROR - 2020-01-15 17:20:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1114
ERROR - 2020-01-15 17:21:24 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 17:21:24 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 17:21:24 --> Could not find the language line "hello"
ERROR - 2020-01-15 17:21:24 --> Severity: error --> Exception: Call to undefined function float() /var/www/html/equizAdmin/application/views/view_result.php 250
ERROR - 2020-01-15 17:23:14 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 17:23:14 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 17:23:14 --> Could not find the language line "hello"
ERROR - 2020-01-15 17:23:14 --> Could not find the language line "user_id"
ERROR - 2020-01-15 17:23:14 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 337
ERROR - 2020-01-15 17:23:14 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 342
ERROR - 2020-01-15 17:23:14 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 344
ERROR - 2020-01-15 17:23:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 811
ERROR - 2020-01-15 17:23:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1114
ERROR - 2020-01-15 17:23:24 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 17:23:24 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 17:23:24 --> Could not find the language line "hello"
ERROR - 2020-01-15 17:23:24 --> Could not find the language line "user_id"
ERROR - 2020-01-15 17:23:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 337
ERROR - 2020-01-15 17:23:24 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 342
ERROR - 2020-01-15 17:23:24 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 344
ERROR - 2020-01-15 17:23:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 811
ERROR - 2020-01-15 17:23:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1114
ERROR - 2020-01-15 17:25:03 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 17:25:03 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 17:25:03 --> Could not find the language line "hello"
ERROR - 2020-01-15 17:25:03 --> Could not find the language line "user_id"
ERROR - 2020-01-15 17:25:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 338
ERROR - 2020-01-15 17:25:03 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 343
ERROR - 2020-01-15 17:25:03 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 345
ERROR - 2020-01-15 17:25:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 812
ERROR - 2020-01-15 17:25:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1115
ERROR - 2020-01-15 17:25:45 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 17:25:45 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 17:25:45 --> Could not find the language line "hello"
ERROR - 2020-01-15 17:25:45 --> Could not find the language line "user_id"
ERROR - 2020-01-15 17:25:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 338
ERROR - 2020-01-15 17:25:45 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 343
ERROR - 2020-01-15 17:25:45 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 345
ERROR - 2020-01-15 17:25:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 812
ERROR - 2020-01-15 17:25:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1115
ERROR - 2020-01-15 17:25:54 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 17:25:54 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 17:25:54 --> Could not find the language line "hello"
ERROR - 2020-01-15 17:25:54 --> Could not find the language line "user_id"
ERROR - 2020-01-15 17:25:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 338
ERROR - 2020-01-15 17:25:54 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 343
ERROR - 2020-01-15 17:25:54 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 345
ERROR - 2020-01-15 17:25:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 812
ERROR - 2020-01-15 17:25:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1115
ERROR - 2020-01-15 17:26:15 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 17:26:15 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 17:26:15 --> Could not find the language line "hello"
ERROR - 2020-01-15 17:26:15 --> Could not find the language line "user_id"
ERROR - 2020-01-15 17:26:15 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 339
ERROR - 2020-01-15 17:26:15 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 344
ERROR - 2020-01-15 17:26:15 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 346
ERROR - 2020-01-15 17:26:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 813
ERROR - 2020-01-15 17:26:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1116
ERROR - 2020-01-15 17:27:16 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 17:27:16 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 17:27:16 --> Could not find the language line "hello"
ERROR - 2020-01-15 17:27:16 --> Could not find the language line "user_id"
ERROR - 2020-01-15 17:27:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 340
ERROR - 2020-01-15 17:27:16 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 345
ERROR - 2020-01-15 17:27:16 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 347
ERROR - 2020-01-15 17:27:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 814
ERROR - 2020-01-15 17:27:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1117
ERROR - 2020-01-15 17:27:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 17:27:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 17:27:29 --> Could not find the language line "hello"
ERROR - 2020-01-15 17:27:29 --> Could not find the language line "user_id"
ERROR - 2020-01-15 17:27:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 340
ERROR - 2020-01-15 17:27:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 345
ERROR - 2020-01-15 17:27:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 347
ERROR - 2020-01-15 17:27:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 814
ERROR - 2020-01-15 17:27:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1117
ERROR - 2020-01-15 17:27:31 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 17:27:31 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 17:27:31 --> Could not find the language line "hello"
ERROR - 2020-01-15 17:27:31 --> Could not find the language line "user_id"
ERROR - 2020-01-15 17:27:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 340
ERROR - 2020-01-15 17:27:31 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 345
ERROR - 2020-01-15 17:27:31 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 347
ERROR - 2020-01-15 17:27:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 814
ERROR - 2020-01-15 17:27:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1117
ERROR - 2020-01-15 17:28:27 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 17:28:27 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 17:28:27 --> Could not find the language line "hello"
ERROR - 2020-01-15 17:28:27 --> Could not find the language line "user_id"
ERROR - 2020-01-15 17:28:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 340
ERROR - 2020-01-15 17:28:27 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 345
ERROR - 2020-01-15 17:28:27 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 347
ERROR - 2020-01-15 17:28:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 814
ERROR - 2020-01-15 17:28:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1117
ERROR - 2020-01-15 17:29:51 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 17:29:51 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 17:29:51 --> Could not find the language line "hello"
ERROR - 2020-01-15 17:29:51 --> Could not find the language line "user_id"
ERROR - 2020-01-15 17:29:51 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-15 17:29:51 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 332
ERROR - 2020-01-15 17:29:51 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 334
ERROR - 2020-01-15 17:29:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 801
ERROR - 2020-01-15 17:29:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1104
ERROR - 2020-01-15 17:39:22 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 17:39:22 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 17:39:22 --> Could not find the language line "hello"
ERROR - 2020-01-15 17:39:22 --> Could not find the language line "user_id"
ERROR - 2020-01-15 17:39:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-15 17:39:22 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 332
ERROR - 2020-01-15 17:39:22 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 334
ERROR - 2020-01-15 17:39:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 781
ERROR - 2020-01-15 17:39:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1084
ERROR - 2020-01-15 17:52:02 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 17:52:02 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 17:52:02 --> Could not find the language line "hello"
ERROR - 2020-01-15 17:52:02 --> Could not find the language line "user_id"
ERROR - 2020-01-15 17:52:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-15 17:52:02 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 332
ERROR - 2020-01-15 17:52:02 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 334
ERROR - 2020-01-15 17:52:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 758
ERROR - 2020-01-15 17:52:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1061
ERROR - 2020-01-15 17:53:17 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 17:53:17 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 17:53:17 --> Could not find the language line "hello"
ERROR - 2020-01-15 17:53:17 --> Could not find the language line "user_id"
ERROR - 2020-01-15 17:53:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-15 17:53:17 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 332
ERROR - 2020-01-15 17:53:17 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 334
ERROR - 2020-01-15 17:53:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 767
ERROR - 2020-01-15 17:53:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1070
ERROR - 2020-01-15 17:53:55 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 17:53:55 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 17:53:55 --> Could not find the language line "hello"
ERROR - 2020-01-15 17:53:55 --> Could not find the language line "user_id"
ERROR - 2020-01-15 17:53:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-15 17:53:55 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 332
ERROR - 2020-01-15 17:53:55 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 334
ERROR - 2020-01-15 17:53:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 776
ERROR - 2020-01-15 17:53:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1079
ERROR - 2020-01-15 17:54:39 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 17:54:39 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 17:54:39 --> Could not find the language line "hello"
ERROR - 2020-01-15 17:54:39 --> Could not find the language line "user_id"
ERROR - 2020-01-15 17:54:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-15 17:54:39 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 332
ERROR - 2020-01-15 17:54:39 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 334
ERROR - 2020-01-15 17:54:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 785
ERROR - 2020-01-15 17:54:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1088
ERROR - 2020-01-15 17:54:49 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 17:54:49 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 17:54:49 --> Could not find the language line "hello"
ERROR - 2020-01-15 17:54:49 --> Could not find the language line "user_id"
ERROR - 2020-01-15 17:54:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-15 17:54:49 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 332
ERROR - 2020-01-15 17:54:49 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 334
ERROR - 2020-01-15 17:54:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 785
ERROR - 2020-01-15 17:54:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1088
ERROR - 2020-01-15 17:55:56 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 17:55:56 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 17:55:56 --> Could not find the language line "hello"
ERROR - 2020-01-15 17:55:56 --> Could not find the language line "user_id"
ERROR - 2020-01-15 17:55:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-15 17:55:56 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 332
ERROR - 2020-01-15 17:55:56 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 334
ERROR - 2020-01-15 17:55:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 785
ERROR - 2020-01-15 17:55:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1088
ERROR - 2020-01-15 17:56:18 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 17:56:18 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 17:56:18 --> Could not find the language line "hello"
ERROR - 2020-01-15 17:56:18 --> Could not find the language line "user_id"
ERROR - 2020-01-15 17:56:18 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-15 17:56:18 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 332
ERROR - 2020-01-15 17:56:18 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 334
ERROR - 2020-01-15 17:56:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 785
ERROR - 2020-01-15 17:56:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1088
ERROR - 2020-01-15 17:56:38 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 17:56:38 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 17:56:38 --> Could not find the language line "hello"
ERROR - 2020-01-15 17:56:38 --> Could not find the language line "user_id"
ERROR - 2020-01-15 17:56:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-15 17:56:38 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 332
ERROR - 2020-01-15 17:56:38 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 334
ERROR - 2020-01-15 17:56:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 786
ERROR - 2020-01-15 17:56:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1089
ERROR - 2020-01-15 17:57:37 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 17:57:37 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 17:57:37 --> Could not find the language line "hello"
ERROR - 2020-01-15 17:57:37 --> Could not find the language line "user_id"
ERROR - 2020-01-15 17:57:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-15 17:57:37 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 332
ERROR - 2020-01-15 17:57:37 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 334
ERROR - 2020-01-15 17:57:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 782
ERROR - 2020-01-15 17:57:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1085
ERROR - 2020-01-15 18:02:05 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 18:02:05 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 18:02:05 --> Could not find the language line "hello"
ERROR - 2020-01-15 18:02:05 --> Could not find the language line "user_id"
ERROR - 2020-01-15 18:02:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-15 18:02:05 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 332
ERROR - 2020-01-15 18:02:05 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 334
ERROR - 2020-01-15 18:02:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 782
ERROR - 2020-01-15 18:02:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1085
ERROR - 2020-01-15 18:03:37 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 18:03:37 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 18:03:37 --> Could not find the language line "hello"
ERROR - 2020-01-15 18:03:37 --> Could not find the language line "user_id"
ERROR - 2020-01-15 18:03:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-15 18:03:37 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 332
ERROR - 2020-01-15 18:03:37 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 334
ERROR - 2020-01-15 18:03:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 782
ERROR - 2020-01-15 18:03:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1085
ERROR - 2020-01-15 18:04:46 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 18:04:46 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 18:04:46 --> Could not find the language line "hello"
ERROR - 2020-01-15 18:04:46 --> Could not find the language line "user_id"
ERROR - 2020-01-15 18:04:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-15 18:04:46 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 332
ERROR - 2020-01-15 18:04:46 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 334
ERROR - 2020-01-15 18:04:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 782
ERROR - 2020-01-15 18:04:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1085
ERROR - 2020-01-15 18:05:35 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 18:05:35 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 18:05:35 --> Could not find the language line "hello"
ERROR - 2020-01-15 18:05:35 --> Could not find the language line "user_id"
ERROR - 2020-01-15 18:05:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-15 18:05:35 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 332
ERROR - 2020-01-15 18:05:35 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 334
ERROR - 2020-01-15 18:05:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 782
ERROR - 2020-01-15 18:05:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1085
ERROR - 2020-01-15 18:07:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 18:07:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 18:07:11 --> Could not find the language line "hello"
ERROR - 2020-01-15 18:07:11 --> Could not find the language line "user_id"
ERROR - 2020-01-15 18:07:11 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-15 18:07:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 332
ERROR - 2020-01-15 18:07:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 334
ERROR - 2020-01-15 18:07:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 782
ERROR - 2020-01-15 18:07:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1085
ERROR - 2020-01-15 18:07:16 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 18:07:16 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 18:07:16 --> Could not find the language line "hello"
ERROR - 2020-01-15 18:07:16 --> Could not find the language line "user_id"
ERROR - 2020-01-15 18:07:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-15 18:07:16 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 332
ERROR - 2020-01-15 18:07:16 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 334
ERROR - 2020-01-15 18:07:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 782
ERROR - 2020-01-15 18:07:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1085
ERROR - 2020-01-15 18:07:30 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 18:07:30 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 18:07:30 --> Could not find the language line "hello"
ERROR - 2020-01-15 18:07:30 --> Could not find the language line "user_id"
ERROR - 2020-01-15 18:07:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-15 18:07:30 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 332
ERROR - 2020-01-15 18:07:30 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 334
ERROR - 2020-01-15 18:07:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 782
ERROR - 2020-01-15 18:07:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1085
ERROR - 2020-01-15 18:08:44 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 207
ERROR - 2020-01-15 18:08:44 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 208
ERROR - 2020-01-15 18:08:44 --> Could not find the language line "hello"
ERROR - 2020-01-15 18:08:44 --> Could not find the language line "user_id"
ERROR - 2020-01-15 18:08:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-15 18:08:44 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 332
ERROR - 2020-01-15 18:08:44 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 334
ERROR - 2020-01-15 18:08:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 782
ERROR - 2020-01-15 18:08:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1085
