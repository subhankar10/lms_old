<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-04 15:43:35 --> Query error: Unknown column 'ust.first_name' in 'field list' - Invalid query: SELECT `q`.`quiz_name`, `q`.`quiz_price`, `s`.*, CONCAT(ue.first_name, " ", ue.last_name) AS examiner_name, CONCAT(ust.first_name, " ", ust.last_name) AS student_name, CONCAT(us.first_name, " ", us.last_name) AS scorer_name
FROM `kams_students_exam_subscription` `s`
LEFT JOIN `kams_quiz` `q` ON `q`.`quid` = `s`.`quiz_id`
LEFT JOIN `kams_users` `ue` ON `ue`.`uid` = `s`.`examiner_id`
LEFT JOIN `kams_users` `us` ON `us`.`uid` = `s`.`scorer_id`
WHERE `s`.`subscription_id` = 4
ERROR - 2020-03-04 15:43:35 --> Severity: error --> Exception: Call to a member function row_array() on boolean /var/www/html/equizAdmindesign/application/controllers/Student_subscriptionexam.php 243
ERROR - 2020-03-04 15:43:37 --> Query error: Unknown column 'ust.first_name' in 'field list' - Invalid query: SELECT `q`.`quiz_name`, `q`.`quiz_price`, `s`.*, CONCAT(ue.first_name, " ", ue.last_name) AS examiner_name, CONCAT(ust.first_name, " ", ust.last_name) AS student_name, CONCAT(us.first_name, " ", us.last_name) AS scorer_name
FROM `kams_students_exam_subscription` `s`
LEFT JOIN `kams_quiz` `q` ON `q`.`quid` = `s`.`quiz_id`
LEFT JOIN `kams_users` `ue` ON `ue`.`uid` = `s`.`examiner_id`
LEFT JOIN `kams_users` `us` ON `us`.`uid` = `s`.`scorer_id`
WHERE `s`.`subscription_id` = 4
ERROR - 2020-03-04 15:43:37 --> Severity: error --> Exception: Call to a member function row_array() on boolean /var/www/html/equizAdmindesign/application/controllers/Student_subscriptionexam.php 243
ERROR - 2020-03-04 15:43:38 --> Query error: Unknown column 'ust.first_name' in 'field list' - Invalid query: SELECT `q`.`quiz_name`, `q`.`quiz_price`, `s`.*, CONCAT(ue.first_name, " ", ue.last_name) AS examiner_name, CONCAT(ust.first_name, " ", ust.last_name) AS student_name, CONCAT(us.first_name, " ", us.last_name) AS scorer_name
FROM `kams_students_exam_subscription` `s`
LEFT JOIN `kams_quiz` `q` ON `q`.`quid` = `s`.`quiz_id`
LEFT JOIN `kams_users` `ue` ON `ue`.`uid` = `s`.`examiner_id`
LEFT JOIN `kams_users` `us` ON `us`.`uid` = `s`.`scorer_id`
WHERE `s`.`subscription_id` = 4
ERROR - 2020-03-04 15:43:38 --> Severity: error --> Exception: Call to a member function row_array() on boolean /var/www/html/equizAdmindesign/application/controllers/Student_subscriptionexam.php 243
ERROR - 2020-03-04 15:43:39 --> Query error: Unknown column 'ust.first_name' in 'field list' - Invalid query: SELECT `q`.`quiz_name`, `q`.`quiz_price`, `s`.*, CONCAT(ue.first_name, " ", ue.last_name) AS examiner_name, CONCAT(ust.first_name, " ", ust.last_name) AS student_name, CONCAT(us.first_name, " ", us.last_name) AS scorer_name
FROM `kams_students_exam_subscription` `s`
LEFT JOIN `kams_quiz` `q` ON `q`.`quid` = `s`.`quiz_id`
LEFT JOIN `kams_users` `ue` ON `ue`.`uid` = `s`.`examiner_id`
LEFT JOIN `kams_users` `us` ON `us`.`uid` = `s`.`scorer_id`
WHERE `s`.`subscription_id` = 5
ERROR - 2020-03-04 15:43:39 --> Severity: error --> Exception: Call to a member function row_array() on boolean /var/www/html/equizAdmindesign/application/controllers/Student_subscriptionexam.php 243
ERROR - 2020-03-04 15:58:02 --> Query error: Unknown column 'ust.first_name' in 'field list' - Invalid query: SELECT `q`.`quiz_name`, `q`.`quiz_price`, `s`.*, CONCAT(ue.first_name, " ", ue.last_name) AS examiner_name, CONCAT(ust.first_name, " ", ust.last_name) AS student_name, CONCAT(us.first_name, " ", us.last_name) AS scorer_name
FROM `kams_students_exam_subscription` `s`
LEFT JOIN `kams_quiz` `q` ON `q`.`quid` = `s`.`quiz_id`
LEFT JOIN `kams_users` `ue` ON `ue`.`uid` = `s`.`examiner_id`
LEFT JOIN `kams_users` `us` ON `us`.`uid` = `s`.`scorer_id`
WHERE `s`.`subscription_id` = 6
ERROR - 2020-03-04 15:58:02 --> Severity: error --> Exception: Call to a member function row_array() on boolean /var/www/html/equizAdmindesign/application/controllers/Student_subscriptionexam.php 243
ERROR - 2020-03-04 15:58:03 --> Query error: Unknown column 'ust.first_name' in 'field list' - Invalid query: SELECT `q`.`quiz_name`, `q`.`quiz_price`, `s`.*, CONCAT(ue.first_name, " ", ue.last_name) AS examiner_name, CONCAT(ust.first_name, " ", ust.last_name) AS student_name, CONCAT(us.first_name, " ", us.last_name) AS scorer_name
FROM `kams_students_exam_subscription` `s`
LEFT JOIN `kams_quiz` `q` ON `q`.`quid` = `s`.`quiz_id`
LEFT JOIN `kams_users` `ue` ON `ue`.`uid` = `s`.`examiner_id`
LEFT JOIN `kams_users` `us` ON `us`.`uid` = `s`.`scorer_id`
WHERE `s`.`subscription_id` = 6
ERROR - 2020-03-04 15:58:03 --> Severity: error --> Exception: Call to a member function row_array() on boolean /var/www/html/equizAdmindesign/application/controllers/Student_subscriptionexam.php 243
