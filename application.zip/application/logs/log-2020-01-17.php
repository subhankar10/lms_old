<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-17 10:29:32 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-01-17 11:13:54 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-01-17 12:47:18 --> Severity: error --> Exception: Unable to locate the model you have specified: Examiner_model /var/www/html/equizAdmin/system/core/Loader.php 348
ERROR - 2020-01-17 12:47:21 --> Severity: error --> Exception: Unable to locate the model you have specified: Examiner_model /var/www/html/equizAdmin/system/core/Loader.php 348
ERROR - 2020-01-17 12:47:37 --> Severity: error --> Exception: Unable to locate the model you have specified: Examiner_model /var/www/html/equizAdmin/system/core/Loader.php 348
ERROR - 2020-01-17 12:47:52 --> Severity: error --> Exception: Unable to locate the model you have specified: Examiner_model /var/www/html/equizAdmin/system/core/Loader.php 348
ERROR - 2020-01-17 12:48:25 --> Severity: error --> Exception: Unable to locate the model you have specified: Examiner_model /var/www/html/equizAdmin/system/core/Loader.php 348
ERROR - 2020-01-17 12:48:39 --> Severity: error --> Exception: Unable to locate the model you have specified: Examiner_model /var/www/html/equizAdmin/system/core/Loader.php 348
ERROR - 2020-01-17 13:12:32 --> Severity: error --> Exception: Call to a member function record_exist() on null /var/www/html/equizAdmin/application/controllers/Examiner.php 73
ERROR - 2020-01-17 13:12:57 --> Severity: error --> Exception: Call to a member function record_exist() on null /var/www/html/equizAdmin/application/controllers/Examiner.php 73
ERROR - 2020-01-17 13:13:01 --> Severity: error --> Exception: Call to a member function record_exist() on null /var/www/html/equizAdmin/application/controllers/Examiner.php 73
ERROR - 2020-01-17 13:13:27 --> Severity: error --> Exception: Call to a member function record_exist() on null /var/www/html/equizAdmin/application/controllers/Examiner.php 74
ERROR - 2020-01-17 13:13:50 --> Severity: error --> Exception: Call to a member function record_exist() on null /var/www/html/equizAdmin/application/controllers/Examiner.php 75
ERROR - 2020-01-17 13:14:58 --> Severity: error --> Exception: Call to a member function record_exist() on null /var/www/html/equizAdmin/application/controllers/Examiner.php 76
ERROR - 2020-01-17 13:24:38 --> Severity: error --> Exception: Call to a member function record_exist() on null /var/www/html/equizAdmin/application/controllers/Examiner.php 73
ERROR - 2020-01-17 13:25:59 --> Severity: error --> Exception: Call to a member function record_exist() on null /var/www/html/equizAdmin/application/controllers/Examiner.php 73
ERROR - 2020-01-17 13:26:07 --> Severity: error --> Exception: Call to a member function record_exist() on null /var/www/html/equizAdmin/application/controllers/Examiner.php 73
ERROR - 2020-01-17 13:26:33 --> Severity: error --> Exception: Call to a member function record_exist() on null /var/www/html/equizAdmin/application/controllers/Examiner.php 73
ERROR - 2020-01-17 13:26:42 --> Severity: error --> Exception: Call to a member function record_exist() on null /var/www/html/equizAdmin/application/controllers/Examiner.php 73
ERROR - 2020-01-17 13:27:14 --> Severity: error --> Exception: Call to a member function record_exist() on null /var/www/html/equizAdmin/application/controllers/Examiner.php 73
ERROR - 2020-01-17 13:27:29 --> Severity: error --> Exception: Call to a member function record_exist() on null /var/www/html/equizAdmin/application/controllers/Examiner.php 73
ERROR - 2020-01-17 13:27:44 --> Severity: error --> Exception: Call to a member function record_exist() on null /var/www/html/equizAdmin/application/controllers/Examiner.php 73
ERROR - 2020-01-17 14:38:49 --> Severity: error --> Exception: Call to undefined method Examiner_model::get_examiner() /var/www/html/equizAdmin/application/controllers/Examiner.php 54
ERROR - 2020-01-17 14:38:59 --> Severity: error --> Exception: Call to undefined method Examiner_model::get_examiner() /var/www/html/equizAdmin/application/controllers/Examiner.php 55
ERROR - 2020-01-17 14:52:39 --> Severity: Warning --> Illegal string offset 'result' /var/www/html/equizAdmin/application/controllers/Examiner.php 55
ERROR - 2020-01-17 14:52:39 --> Severity: Warning --> Illegal string offset 'title' /var/www/html/equizAdmin/application/controllers/Examiner.php 58
ERROR - 2020-01-17 14:52:39 --> Severity: Warning --> Illegal string offset 'account_type' /var/www/html/equizAdmin/application/controllers/Examiner.php 60
ERROR - 2020-01-17 14:52:39 --> Severity: Warning --> Illegal string offset 'exam_category' /var/www/html/equizAdmin/application/controllers/Examiner.php 61
ERROR - 2020-01-17 14:52:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/new_examiner.php 63
ERROR - 2020-01-17 14:52:42 --> Severity: Warning --> Illegal string offset 'result' /var/www/html/equizAdmin/application/controllers/Examiner.php 55
ERROR - 2020-01-17 14:52:42 --> Severity: Warning --> Illegal string offset 'title' /var/www/html/equizAdmin/application/controllers/Examiner.php 58
ERROR - 2020-01-17 14:52:42 --> Severity: Warning --> Illegal string offset 'account_type' /var/www/html/equizAdmin/application/controllers/Examiner.php 60
ERROR - 2020-01-17 14:52:42 --> Severity: Warning --> Illegal string offset 'exam_category' /var/www/html/equizAdmin/application/controllers/Examiner.php 61
ERROR - 2020-01-17 14:52:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/new_examiner.php 63
ERROR - 2020-01-17 14:53:16 --> Severity: Warning --> Illegal string offset 'result' /var/www/html/equizAdmin/application/controllers/Examiner.php 55
ERROR - 2020-01-17 14:53:16 --> Severity: Warning --> Illegal string offset 'title' /var/www/html/equizAdmin/application/controllers/Examiner.php 58
ERROR - 2020-01-17 14:53:16 --> Severity: Warning --> Illegal string offset 'account_type' /var/www/html/equizAdmin/application/controllers/Examiner.php 60
ERROR - 2020-01-17 14:53:16 --> Severity: Warning --> Illegal string offset 'exam_category' /var/www/html/equizAdmin/application/controllers/Examiner.php 61
ERROR - 2020-01-17 14:53:52 --> Severity: Warning --> Illegal string offset 'result' /var/www/html/equizAdmin/application/controllers/Examiner.php 55
ERROR - 2020-01-17 14:53:52 --> Severity: Warning --> Illegal string offset 'result' /var/www/html/equizAdmin/application/controllers/Examiner.php 56
ERROR - 2020-01-17 14:53:52 --> Severity: Warning --> Illegal string offset 'title' /var/www/html/equizAdmin/application/controllers/Examiner.php 59
ERROR - 2020-01-17 14:53:52 --> Severity: Warning --> Illegal string offset 'account_type' /var/www/html/equizAdmin/application/controllers/Examiner.php 61
ERROR - 2020-01-17 14:53:52 --> Severity: Warning --> Illegal string offset 'exam_category' /var/www/html/equizAdmin/application/controllers/Examiner.php 62
ERROR - 2020-01-17 14:53:54 --> Severity: Warning --> Illegal string offset 'result' /var/www/html/equizAdmin/application/controllers/Examiner.php 55
ERROR - 2020-01-17 14:53:54 --> Severity: Warning --> Illegal string offset 'result' /var/www/html/equizAdmin/application/controllers/Examiner.php 56
ERROR - 2020-01-17 14:53:54 --> Severity: Warning --> Illegal string offset 'title' /var/www/html/equizAdmin/application/controllers/Examiner.php 59
ERROR - 2020-01-17 14:53:54 --> Severity: Warning --> Illegal string offset 'account_type' /var/www/html/equizAdmin/application/controllers/Examiner.php 61
ERROR - 2020-01-17 14:53:54 --> Severity: Warning --> Illegal string offset 'exam_category' /var/www/html/equizAdmin/application/controllers/Examiner.php 62
ERROR - 2020-01-17 14:54:16 --> Severity: Warning --> Illegal string offset 'result' /var/www/html/equizAdmin/application/controllers/Examiner.php 55
ERROR - 2020-01-17 14:54:16 --> Severity: Warning --> Illegal string offset 'result' /var/www/html/equizAdmin/application/controllers/Examiner.php 56
ERROR - 2020-01-17 14:54:16 --> Severity: Warning --> Illegal string offset 'title' /var/www/html/equizAdmin/application/controllers/Examiner.php 59
ERROR - 2020-01-17 14:54:16 --> Severity: Warning --> Illegal string offset 'account_type' /var/www/html/equizAdmin/application/controllers/Examiner.php 61
ERROR - 2020-01-17 14:54:16 --> Severity: Warning --> Illegal string offset 'exam_category' /var/www/html/equizAdmin/application/controllers/Examiner.php 62
ERROR - 2020-01-17 14:54:41 --> Severity: Warning --> Illegal string offset 'result' /var/www/html/equizAdmin/application/controllers/Examiner.php 55
ERROR - 2020-01-17 14:54:41 --> Severity: Warning --> Illegal string offset 'title' /var/www/html/equizAdmin/application/controllers/Examiner.php 58
ERROR - 2020-01-17 14:54:41 --> Severity: Warning --> Illegal string offset 'account_type' /var/www/html/equizAdmin/application/controllers/Examiner.php 60
ERROR - 2020-01-17 14:54:41 --> Severity: Warning --> Illegal string offset 'exam_category' /var/www/html/equizAdmin/application/controllers/Examiner.php 61
ERROR - 2020-01-17 14:56:21 --> Severity: Warning --> Illegal string offset 'result' /var/www/html/equizAdmin/application/controllers/Examiner.php 55
ERROR - 2020-01-17 14:56:21 --> Severity: Warning --> Illegal string offset 'title' /var/www/html/equizAdmin/application/controllers/Examiner.php 58
ERROR - 2020-01-17 14:56:21 --> Severity: Warning --> Illegal string offset 'account_type' /var/www/html/equizAdmin/application/controllers/Examiner.php 60
ERROR - 2020-01-17 14:56:21 --> Severity: Warning --> Illegal string offset 'exam_category' /var/www/html/equizAdmin/application/controllers/Examiner.php 61
ERROR - 2020-01-17 14:57:08 --> Severity: Warning --> Illegal string offset 'result' /var/www/html/equizAdmin/application/controllers/Examiner.php 55
ERROR - 2020-01-17 14:57:08 --> Severity: Warning --> Illegal string offset 'title' /var/www/html/equizAdmin/application/controllers/Examiner.php 58
ERROR - 2020-01-17 14:57:08 --> Severity: Warning --> Illegal string offset 'account_type' /var/www/html/equizAdmin/application/controllers/Examiner.php 60
ERROR - 2020-01-17 14:57:08 --> Severity: Warning --> Illegal string offset 'exam_category' /var/www/html/equizAdmin/application/controllers/Examiner.php 61
ERROR - 2020-01-17 14:57:33 --> Severity: Warning --> Illegal string offset 'result' /var/www/html/equizAdmin/application/controllers/Examiner.php 56
ERROR - 2020-01-17 14:57:33 --> Severity: Warning --> Illegal string offset 'title' /var/www/html/equizAdmin/application/controllers/Examiner.php 59
ERROR - 2020-01-17 14:57:33 --> Severity: Warning --> Illegal string offset 'account_type' /var/www/html/equizAdmin/application/controllers/Examiner.php 61
ERROR - 2020-01-17 14:57:33 --> Severity: Warning --> Illegal string offset 'exam_category' /var/www/html/equizAdmin/application/controllers/Examiner.php 62
ERROR - 2020-01-17 14:57:55 --> Severity: Warning --> Illegal string offset 'result' /var/www/html/equizAdmin/application/controllers/Examiner.php 55
ERROR - 2020-01-17 14:57:55 --> Severity: Warning --> Illegal string offset 'result' /var/www/html/equizAdmin/application/controllers/Examiner.php 56
ERROR - 2020-01-17 14:57:55 --> Severity: Warning --> Illegal string offset 'title' /var/www/html/equizAdmin/application/controllers/Examiner.php 59
ERROR - 2020-01-17 14:57:55 --> Severity: Warning --> Illegal string offset 'account_type' /var/www/html/equizAdmin/application/controllers/Examiner.php 61
ERROR - 2020-01-17 14:57:55 --> Severity: Warning --> Illegal string offset 'exam_category' /var/www/html/equizAdmin/application/controllers/Examiner.php 62
ERROR - 2020-01-17 14:58:20 --> Severity: Warning --> Illegal string offset 'result' /var/www/html/equizAdmin/application/controllers/Examiner.php 55
ERROR - 2020-01-17 14:58:20 --> Severity: Warning --> Illegal string offset 'title' /var/www/html/equizAdmin/application/controllers/Examiner.php 58
ERROR - 2020-01-17 14:58:20 --> Severity: Warning --> Illegal string offset 'account_type' /var/www/html/equizAdmin/application/controllers/Examiner.php 60
ERROR - 2020-01-17 14:58:20 --> Severity: Warning --> Illegal string offset 'exam_category' /var/www/html/equizAdmin/application/controllers/Examiner.php 61
ERROR - 2020-01-17 14:58:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/new_examiner.php 64
ERROR - 2020-01-17 14:58:23 --> Severity: Warning --> Illegal string offset 'result' /var/www/html/equizAdmin/application/controllers/Examiner.php 55
ERROR - 2020-01-17 14:58:23 --> Severity: Warning --> Illegal string offset 'title' /var/www/html/equizAdmin/application/controllers/Examiner.php 58
ERROR - 2020-01-17 14:58:23 --> Severity: Warning --> Illegal string offset 'account_type' /var/www/html/equizAdmin/application/controllers/Examiner.php 60
ERROR - 2020-01-17 14:58:23 --> Severity: Warning --> Illegal string offset 'exam_category' /var/www/html/equizAdmin/application/controllers/Examiner.php 61
ERROR - 2020-01-17 14:58:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/new_examiner.php 64
ERROR - 2020-01-17 14:58:32 --> Severity: Warning --> Illegal string offset 'result' /var/www/html/equizAdmin/application/controllers/Examiner.php 55
ERROR - 2020-01-17 14:58:32 --> Severity: Warning --> Illegal string offset 'title' /var/www/html/equizAdmin/application/controllers/Examiner.php 58
ERROR - 2020-01-17 14:58:32 --> Severity: Warning --> Illegal string offset 'account_type' /var/www/html/equizAdmin/application/controllers/Examiner.php 60
ERROR - 2020-01-17 14:58:32 --> Severity: Warning --> Illegal string offset 'exam_category' /var/www/html/equizAdmin/application/controllers/Examiner.php 61
ERROR - 2020-01-17 14:59:13 --> Severity: Warning --> Illegal string offset 'result' /var/www/html/equizAdmin/application/controllers/Examiner.php 55
ERROR - 2020-01-17 14:59:13 --> Severity: Warning --> Illegal string offset 'result' /var/www/html/equizAdmin/application/controllers/Examiner.php 56
ERROR - 2020-01-17 14:59:13 --> Severity: Warning --> Illegal string offset 'title' /var/www/html/equizAdmin/application/controllers/Examiner.php 59
ERROR - 2020-01-17 14:59:13 --> Severity: Warning --> Illegal string offset 'account_type' /var/www/html/equizAdmin/application/controllers/Examiner.php 61
ERROR - 2020-01-17 14:59:13 --> Severity: Warning --> Illegal string offset 'exam_category' /var/www/html/equizAdmin/application/controllers/Examiner.php 62
ERROR - 2020-01-17 15:00:30 --> Severity: Warning --> Illegal string offset 'result' /var/www/html/equizAdmin/application/controllers/Examiner.php 55
ERROR - 2020-01-17 15:00:30 --> Severity: Warning --> Illegal string offset 'result' /var/www/html/equizAdmin/application/controllers/Examiner.php 56
ERROR - 2020-01-17 15:00:30 --> Severity: Warning --> Illegal string offset 'title' /var/www/html/equizAdmin/application/controllers/Examiner.php 59
ERROR - 2020-01-17 15:00:30 --> Severity: Warning --> Illegal string offset 'account_type' /var/www/html/equizAdmin/application/controllers/Examiner.php 61
ERROR - 2020-01-17 15:00:30 --> Severity: Warning --> Illegal string offset 'exam_category' /var/www/html/equizAdmin/application/controllers/Examiner.php 62
ERROR - 2020-01-17 15:03:44 --> Severity: Warning --> Illegal string offset 'result' /var/www/html/equizAdmin/application/controllers/Examiner.php 55
ERROR - 2020-01-17 15:03:44 --> Severity: Warning --> Illegal string offset 'result' /var/www/html/equizAdmin/application/controllers/Examiner.php 56
ERROR - 2020-01-17 15:03:44 --> Severity: Warning --> Illegal string offset 'title' /var/www/html/equizAdmin/application/controllers/Examiner.php 59
ERROR - 2020-01-17 15:03:44 --> Severity: Warning --> Illegal string offset 'account_type' /var/www/html/equizAdmin/application/controllers/Examiner.php 61
ERROR - 2020-01-17 15:03:44 --> Severity: Warning --> Illegal string offset 'exam_category' /var/www/html/equizAdmin/application/controllers/Examiner.php 62
ERROR - 2020-01-17 15:04:00 --> Severity: Warning --> Illegal string offset 'result' /var/www/html/equizAdmin/application/controllers/Examiner.php 55
ERROR - 2020-01-17 15:04:00 --> Severity: Warning --> Illegal string offset 'result' /var/www/html/equizAdmin/application/controllers/Examiner.php 56
ERROR - 2020-01-17 15:04:00 --> Severity: Warning --> Illegal string offset 'title' /var/www/html/equizAdmin/application/controllers/Examiner.php 59
ERROR - 2020-01-17 15:04:00 --> Severity: Warning --> Illegal string offset 'account_type' /var/www/html/equizAdmin/application/controllers/Examiner.php 61
ERROR - 2020-01-17 15:04:00 --> Severity: Warning --> Illegal string offset 'exam_category' /var/www/html/equizAdmin/application/controllers/Examiner.php 62
ERROR - 2020-01-17 16:10:48 --> Severity: error --> Exception: Too few arguments to function Examiner::new_examiner(), 0 passed in /var/www/html/equizAdmin/system/core/CodeIgniter.php on line 532 and exactly 1 expected /var/www/html/equizAdmin/application/controllers/Examiner.php 47
ERROR - 2020-01-17 16:10:56 --> Severity: error --> Exception: Too few arguments to function Examiner::new_examiner(), 0 passed in /var/www/html/equizAdmin/system/core/CodeIgniter.php on line 532 and exactly 1 expected /var/www/html/equizAdmin/application/controllers/Examiner.php 47
ERROR - 2020-01-17 16:11:26 --> Severity: error --> Exception: Too few arguments to function Examiner::new_examiner(), 0 passed in /var/www/html/equizAdmin/system/core/CodeIgniter.php on line 532 and exactly 1 expected /var/www/html/equizAdmin/application/controllers/Examiner.php 47
ERROR - 2020-01-17 16:11:28 --> Severity: error --> Exception: Too few arguments to function Examiner::new_examiner(), 0 passed in /var/www/html/equizAdmin/system/core/CodeIgniter.php on line 532 and exactly 1 expected /var/www/html/equizAdmin/application/controllers/Examiner.php 47
ERROR - 2020-01-17 16:11:31 --> Severity: error --> Exception: Too few arguments to function Examiner::new_examiner(), 0 passed in /var/www/html/equizAdmin/system/core/CodeIgniter.php on line 532 and exactly 1 expected /var/www/html/equizAdmin/application/controllers/Examiner.php 47
ERROR - 2020-01-17 16:11:43 --> Severity: error --> Exception: Too few arguments to function Examiner::new_examiner(), 0 passed in /var/www/html/equizAdmin/system/core/CodeIgniter.php on line 532 and exactly 1 expected /var/www/html/equizAdmin/application/controllers/Examiner.php 47
ERROR - 2020-01-17 16:12:10 --> Severity: error --> Exception: Too few arguments to function Examiner::new_examiner(), 0 passed in /var/www/html/equizAdmin/system/core/CodeIgniter.php on line 532 and exactly 1 expected /var/www/html/equizAdmin/application/controllers/Examiner.php 47
ERROR - 2020-01-17 16:12:18 --> Severity: error --> Exception: Too few arguments to function Examiner::new_examiner(), 0 passed in /var/www/html/equizAdmin/system/core/CodeIgniter.php on line 532 and exactly 1 expected /var/www/html/equizAdmin/application/controllers/Examiner.php 47
ERROR - 2020-01-17 16:12:20 --> Severity: error --> Exception: Too few arguments to function Examiner::new_examiner(), 0 passed in /var/www/html/equizAdmin/system/core/CodeIgniter.php on line 532 and exactly 1 expected /var/www/html/equizAdmin/application/controllers/Examiner.php 47
ERROR - 2020-01-17 16:12:55 --> Severity: error --> Exception: Too few arguments to function Examiner::new_examiner(), 0 passed in /var/www/html/equizAdmin/system/core/CodeIgniter.php on line 532 and exactly 1 expected /var/www/html/equizAdmin/application/controllers/Examiner.php 47
ERROR - 2020-01-17 16:13:09 --> Severity: error --> Exception: Too few arguments to function Examiner::new_examiner(), 0 passed in /var/www/html/equizAdmin/system/core/CodeIgniter.php on line 532 and exactly 1 expected /var/www/html/equizAdmin/application/controllers/Examiner.php 47
ERROR - 2020-01-17 16:14:11 --> Severity: error --> Exception: Too few arguments to function Examiner::new_examiner(), 0 passed in /var/www/html/equizAdmin/system/core/CodeIgniter.php on line 532 and exactly 1 expected /var/www/html/equizAdmin/application/controllers/Examiner.php 47
ERROR - 2020-01-17 16:14:12 --> Severity: error --> Exception: Too few arguments to function Examiner::new_examiner(), 0 passed in /var/www/html/equizAdmin/system/core/CodeIgniter.php on line 532 and exactly 1 expected /var/www/html/equizAdmin/application/controllers/Examiner.php 47
ERROR - 2020-01-17 16:14:41 --> Severity: error --> Exception: Too few arguments to function Examiner::new_examiner(), 0 passed in /var/www/html/equizAdmin/system/core/CodeIgniter.php on line 532 and exactly 1 expected /var/www/html/equizAdmin/application/controllers/Examiner.php 46
ERROR - 2020-01-17 16:39:49 --> Severity: error --> Exception: syntax error, unexpected '}' /var/www/html/equizAdmin/application/controllers/Examiner.php 109
ERROR - 2020-01-17 16:39:52 --> Severity: error --> Exception: syntax error, unexpected '}' /var/www/html/equizAdmin/application/controllers/Examiner.php 109
ERROR - 2020-01-17 16:46:48 --> Severity: error --> Exception: Too few arguments to function Examiner::new_examiner(), 0 passed in /var/www/html/equizAdmin/system/core/CodeIgniter.php on line 532 and exactly 1 expected /var/www/html/equizAdmin/application/controllers/Examiner.php 53
ERROR - 2020-01-17 17:15:11 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 118
ERROR - 2020-01-17 17:16:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 118
ERROR - 2020-01-17 17:17:06 --> Severity: Warning --> Illegal string offset 'uid' /var/www/html/equizAdmin/application/controllers/Examiner.php 109
ERROR - 2020-01-17 17:19:19 --> Severity: Warning --> Illegal string offset 'uid' /var/www/html/equizAdmin/application/controllers/Examiner.php 110
ERROR - 2020-01-17 17:20:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 17:20:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 17:20:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 17:21:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 17:22:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 17:24:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 17:28:13 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 17:37:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 120
ERROR - 2020-01-17 17:37:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 120
ERROR - 2020-01-17 17:38:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 17:39:13 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 17:39:46 --> Severity: Warning --> Illegal string offset 'uid' /var/www/html/equizAdmin/application/controllers/Examiner.php 110
ERROR - 2020-01-17 17:42:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 17:43:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 17:43:30 --> Severity: Warning --> Illegal string offset 'uid' /var/www/html/equizAdmin/application/controllers/Examiner.php 110
ERROR - 2020-01-17 17:43:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 17:45:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 17:49:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/controllers/Examiner.php 111
ERROR - 2020-01-17 17:49:36 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmin/application/controllers/Examiner.php 107
ERROR - 2020-01-17 17:49:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 17:49:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/controllers/Examiner.php 111
ERROR - 2020-01-17 17:50:40 --> Severity: Warning --> explode() expects parameter 2 to be string, array given /var/www/html/equizAdmin/application/controllers/Examiner.php 107
ERROR - 2020-01-17 17:50:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/controllers/Examiner.php 111
ERROR - 2020-01-17 17:50:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/controllers/Examiner.php 111
ERROR - 2020-01-17 17:51:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/controllers/Examiner.php 112
ERROR - 2020-01-17 17:52:23 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/equizAdmin/application/controllers/Examiner.php 107
ERROR - 2020-01-17 17:52:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 17:52:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 18:10:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 18:11:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 18:13:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 18:14:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 18:16:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 18:17:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 18:20:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 18:20:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 18:21:18 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 18:21:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 18:23:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 18:23:51 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 18:23:55 --> Severity: error --> Exception: Too few arguments to function CI_DB_driver::query(), 0 passed in /var/www/html/equizAdmin/application/controllers/Examiner.php on line 105 and at least 1 expected /var/www/html/equizAdmin/system/database/DB_driver.php 608
ERROR - 2020-01-17 18:24:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 18:24:26 --> Severity: error --> Exception: Too few arguments to function CI_DB_driver::query(), 0 passed in /var/www/html/equizAdmin/application/controllers/Examiner.php on line 105 and at least 1 expected /var/www/html/equizAdmin/system/database/DB_driver.php 608
ERROR - 2020-01-17 18:24:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 18:24:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 18:34:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 18:39:52 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 18:55:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 19:01:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 19:01:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 19:02:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 19:02:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 19:03:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 19:04:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 19:04:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 19:06:18 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 19:09:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 19:10:50 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
ERROR - 2020-01-17 23:09:58 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-01-17 23:10:13 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/examiner_list.php 119
