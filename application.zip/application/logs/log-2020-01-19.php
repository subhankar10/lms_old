<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-19 10:37:01 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-01-19 10:37:10 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-19 10:37:10 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-19 10:37:10 --> Could not find the language line "hello"
ERROR - 2020-01-19 10:37:10 --> Could not find the language line "user_id"
ERROR - 2020-01-19 10:37:10 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-19 10:37:10 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-19 10:37:10 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-19 10:37:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 828
ERROR - 2020-01-19 10:37:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1131
ERROR - 2020-01-19 10:37:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
WHERE `a`.`qid` IN('12,13,14')
AND `q`.`qid` IN('12,13,14')
AND `r`.`rid` = '1' at line 4 - Invalid query: SELECT `r`.`quid`, `a`.`score_u`, `q`.`question`
FROM `kams_result` `r`
LEFT JOIN `kams_answers` `a` ON `r`.`rid` = `a`.`rid`
LEFT JOIN `kams_qbank` `q` USING ()
WHERE `a`.`qid` IN('12,13,14')
AND `q`.`qid` IN('12,13,14')
AND `r`.`rid` = '153'
GROUP BY `q`.`qid`
ERROR - 2020-01-19 10:52:49 --> Query error: Expression #2 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'equiz.a.score_u' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `r`.`quid`, `a`.`score_u`, `q`.`question`
FROM `kams_result` `r`
LEFT JOIN `kams_answers` `a` ON `r`.`rid` = `a`.`rid`
LEFT JOIN `kams_qbank` `q` ON `q`.`question_module` = `a`.`exam_module`
WHERE `a`.`qid` IN('18,19,20')
AND `q`.`qid` IN('18,19,20')
AND `r`.`rid` = '153'
GROUP BY `q`.`qid`
ERROR - 2020-01-19 11:00:00 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-19 11:00:00 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-19 11:00:00 --> Could not find the language line "hello"
ERROR - 2020-01-19 11:00:00 --> Could not find the language line "user_id"
ERROR - 2020-01-19 11:00:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-19 11:00:00 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-19 11:00:00 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-19 11:00:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 828
ERROR - 2020-01-19 11:00:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1131
ERROR - 2020-01-19 11:00:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`IN18,19,20`
WHERE `r`.`rid` = '153'
GROUP BY `q`.`qid`' at line 3 - Invalid query: SELECT `r`.`quid`, `a`.`score_u`, `q`.`question`
FROM `kams_result` `r`
LEFT JOIN `kams_answers` `a` ON `r`.`rid` = `a`.`rid anda`.`qid` `IN18,19,20`
WHERE `r`.`rid` = '153'
GROUP BY `q`.`qid`
ERROR - 2020-01-19 11:00:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`15,16,17`
WHERE `r`.`rid` = '153'
GROUP BY `q`.`qid`' at line 3 - Invalid query: SELECT `r`.`quid`, `a`.`score_u`, `q`.`question`
FROM `kams_result` `r`
LEFT JOIN `kams_answers` `a` ON `r`.`rid` = `a`.`rid anda`.`qid IN` `15,16,17`
WHERE `r`.`rid` = '153'
GROUP BY `q`.`qid`
ERROR - 2020-01-19 11:01:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'anda.qid IN (15,16,17)
WHERE `r`.`rid` = '153'
GROUP BY `q`.`qid`' at line 3 - Invalid query: SELECT `r`.`quid`, `a`.`score_u`, `q`.`question`
FROM `kams_result` `r`
LEFT JOIN `kams_answers` `a` ON `r`.`rid` = a.rid anda.qid IN (15,16,17)
WHERE `r`.`rid` = '153'
GROUP BY `q`.`qid`
ERROR - 2020-01-19 11:15:43 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-19 11:15:43 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-19 11:15:43 --> Could not find the language line "hello"
ERROR - 2020-01-19 11:15:43 --> Could not find the language line "user_id"
ERROR - 2020-01-19 11:15:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-19 11:15:43 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-19 11:15:43 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-19 11:15:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 828
ERROR - 2020-01-19 11:15:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1131
ERROR - 2020-01-19 11:19:42 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-19 11:19:42 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-19 11:19:42 --> Could not find the language line "hello"
ERROR - 2020-01-19 11:19:42 --> Could not find the language line "user_id"
ERROR - 2020-01-19 11:19:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-19 11:19:42 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-19 11:19:42 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-19 11:19:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 828
ERROR - 2020-01-19 11:19:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1131
ERROR - 2020-01-19 11:21:45 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-19 11:21:45 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-19 11:21:45 --> Could not find the language line "hello"
ERROR - 2020-01-19 11:21:45 --> Could not find the language line "user_id"
ERROR - 2020-01-19 11:21:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-19 11:21:45 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-19 11:21:45 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-19 11:21:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 828
ERROR - 2020-01-19 11:21:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1131
ERROR - 2020-01-19 11:23:32 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-19 11:23:32 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-19 11:23:32 --> Could not find the language line "hello"
ERROR - 2020-01-19 11:23:32 --> Could not find the language line "user_id"
ERROR - 2020-01-19 11:23:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-19 11:23:32 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-19 11:23:32 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-19 11:23:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 828
ERROR - 2020-01-19 11:23:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1131
ERROR - 2020-01-19 11:23:35 --> Query error: Unknown column 'a*' in 'field list' - Invalid query: SELECT `r`.`quid`, `a*`, `q`.`question`
FROM `kams_result` `r`
LEFT JOIN `kams_answers` `a` ON `r`.`rid` = `a`.`rid` and `a`.`qid` IN (18,19,20)
LEFT JOIN `kams_qbank` `q` ON `q`.`question_module` = `a`.`exam_module` and `q`.`qid` IN (18,19,20)
WHERE `r`.`rid` = '153'
GROUP BY `q`.`qid`
ERROR - 2020-01-19 11:31:19 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-19 11:31:19 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-19 11:31:19 --> Could not find the language line "hello"
ERROR - 2020-01-19 11:31:19 --> Could not find the language line "user_id"
ERROR - 2020-01-19 11:31:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-19 11:31:19 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-19 11:31:19 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-19 11:31:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 828
ERROR - 2020-01-19 11:31:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1131
ERROR - 2020-01-19 11:31:23 --> Query error: Unknown column 'a*' in 'field list' - Invalid query: SELECT `r`.`quid`, `a*`, `q`.`question`
FROM `kams_result` `r`
LEFT JOIN `kams_answers` `a` ON `r`.`rid` = `a`.`rid` and `a`.`qid` IN (21,22,23)
LEFT JOIN `kams_qbank` `q` ON `q`.`qid` = `a`.`qid`
WHERE `r`.`rid` = '153'
GROUP BY `a`.`aid`
ERROR - 2020-01-19 11:32:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-19 11:32:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-19 11:32:11 --> Could not find the language line "hello"
ERROR - 2020-01-19 11:32:11 --> Could not find the language line "user_id"
ERROR - 2020-01-19 11:32:11 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-19 11:32:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-19 11:32:11 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-19 11:32:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 828
ERROR - 2020-01-19 11:32:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1131
ERROR - 2020-01-19 11:33:57 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-19 11:33:57 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-19 11:33:57 --> Could not find the language line "hello"
ERROR - 2020-01-19 11:33:57 --> Could not find the language line "user_id"
ERROR - 2020-01-19 11:33:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-19 11:33:57 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-19 11:33:57 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-19 11:33:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 828
ERROR - 2020-01-19 11:33:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1131
ERROR - 2020-01-19 11:44:53 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-19 11:44:53 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-19 11:44:53 --> Could not find the language line "hello"
ERROR - 2020-01-19 11:44:53 --> Could not find the language line "user_id"
ERROR - 2020-01-19 11:44:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-19 11:44:53 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-19 11:44:53 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-19 11:44:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 828
ERROR - 2020-01-19 11:44:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1131
ERROR - 2020-01-19 11:45:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-19 11:45:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-19 11:45:29 --> Could not find the language line "hello"
ERROR - 2020-01-19 11:45:29 --> Could not find the language line "user_id"
ERROR - 2020-01-19 11:45:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-19 11:45:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-19 11:45:29 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-19 11:45:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 828
ERROR - 2020-01-19 11:45:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1131
ERROR - 2020-01-19 11:46:55 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-19 11:46:55 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-19 11:46:55 --> Could not find the language line "hello"
ERROR - 2020-01-19 11:46:55 --> Could not find the language line "user_id"
ERROR - 2020-01-19 11:46:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-19 11:46:55 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-19 11:46:55 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-19 11:46:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 828
ERROR - 2020-01-19 11:46:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1131
ERROR - 2020-01-19 11:48:06 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 204
ERROR - 2020-01-19 11:48:06 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 205
ERROR - 2020-01-19 11:48:06 --> Could not find the language line "hello"
ERROR - 2020-01-19 11:48:06 --> Could not find the language line "user_id"
ERROR - 2020-01-19 11:48:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/view_result.php 322
ERROR - 2020-01-19 11:48:06 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 327
ERROR - 2020-01-19 11:48:06 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmin/application/views/view_result.php 329
ERROR - 2020-01-19 11:48:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 828
ERROR - 2020-01-19 11:48:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/view_result.php 1131
