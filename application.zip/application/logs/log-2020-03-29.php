<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-29 08:54:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/class/classroomList.php 174
ERROR - 2020-03-29 08:56:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/class/classroomList.php 174
ERROR - 2020-03-29 08:58:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/class/classroomList.php 174
ERROR - 2020-03-29 09:11:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 174
ERROR - 2020-03-29 09:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 174
ERROR - 2020-03-29 09:12:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 174
ERROR - 2020-03-29 10:43:24 --> Severity: error --> Exception: Call to a member function classroom_list() on null /var/www/html/onlineclassroom/application/controllers/Videoclassroom.php 108
ERROR - 2020-03-29 10:43:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 174
ERROR - 2020-03-29 10:44:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/class/classroomList.php 174
ERROR - 2020-03-29 10:48:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/class/classroomList.php 174
ERROR - 2020-03-29 11:01:18 --> Severity: error --> Exception: Call to undefined method Subject_model::classroom_list() /var/www/html/onlineclassroom/application/controllers/Videoclassroom.php 111
ERROR - 2020-03-29 11:01:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/subject/subjectList.php 174
ERROR - 2020-03-29 11:11:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/examiner_list.php 204
ERROR - 2020-03-29 11:14:38 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT *
FROM `kams_users`
WHERE `su` = 4
AND `status` = 1
ORDER BY `kams_users`.`first_name` ASC
ERROR - 2020-03-29 11:14:38 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/onlineclassroom/application/models/Videoclassroom_model.php 48
ERROR - 2020-03-29 11:16:11 --> Query error: Unknown column 'kams_users.status' in 'where clause' - Invalid query: SELECT *
FROM `kams_users`
WHERE `kams_users`.`su` = 4
AND `kams_users`.`status` = 1
ORDER BY `kams_users`.`first_name` ASC
ERROR - 2020-03-29 11:16:11 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/onlineclassroom/application/models/Videoclassroom_model.php 44
ERROR - 2020-03-29 11:16:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/examiner_list.php 204
ERROR - 2020-03-29 11:22:57 --> Query error: Unknown column 'date' in 'field list' - Invalid query: INSERT INTO `class` (`name`, `date`, `start_time`, `class_id`, `subject_id`, `description`, `teacher_id`, `status`, `add_date`) VALUES ('test', '2020-03-12', '01:00', '1', '1', 'Test', '', 1, '20-03-29 11:22:57')
ERROR - 2020-03-29 11:22:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/class/classroomList.php 174
ERROR - 2020-03-29 11:23:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 174
ERROR - 2020-03-29 11:26:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 174
ERROR - 2020-03-29 14:02:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/onlineclassroom/application/views/videoclass/classroomList.php 174
ERROR - 2020-03-29 14:17:37 --> Query error: Unknown column 'subject.uid' in 'on clause' - Invalid query: SELECT *
FROM `kams_video_classroom`
JOIN `kams_users` ON `kams_users`.`uid`=`kams_video_classroom`.`teacher_id`
LEFT JOIN `class` ON `class`.`id`=`kams_video_classroom`.`class_id`
LEFT JOIN `subject` ON `subject`.`uid`=`kams_video_classroom`.`subject_id`
ORDER BY `kams_video_classroom`.`id` DESC
ERROR - 2020-03-29 14:17:37 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /var/www/html/onlineclassroom/application/models/Videoclassroom_model.php 35
ERROR - 2020-03-29 14:48:11 --> Query error: Unknown column 'subject.uid' in 'on clause' - Invalid query: SELECT *
FROM `kams_video_classroom`
JOIN `kams_users` ON `kams_users`.`uid`=`kams_video_classroom`.`teacher_id`
LEFT JOIN `class` ON `class`.`id`=`kams_video_classroom`.`class_id`
LEFT JOIN `subject` ON `subject`.`uid`=`kams_video_classroom`.`subject_id`
ORDER BY `kams_video_classroom`.`id` DESC
ERROR - 2020-03-29 14:48:11 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/onlineclassroom/application/models/Videoclassroom_model.php 28
ERROR - 2020-03-29 14:49:08 --> Query error: Unknown column 'subject.uid' in 'on clause' - Invalid query: SELECT *
FROM `kams_video_classroom`
JOIN `kams_users` ON `kams_users`.`uid`=`kams_video_classroom`.`teacher_id`
LEFT JOIN `class` ON `class`.`id`=`kams_video_classroom`.`class_id`
LEFT JOIN `subject` ON `subject`.`uid`=`kams_video_classroom`.`subject_id`
ORDER BY `kams_video_classroom`.`id` DESC
ERROR - 2020-03-29 14:49:12 --> Query error: Unknown column 'subject.uid' in 'on clause' - Invalid query: SELECT *
FROM `kams_video_classroom`
JOIN `kams_users` ON `kams_users`.`uid`=`kams_video_classroom`.`teacher_id`
LEFT JOIN `class` ON `class`.`id`=`kams_video_classroom`.`class_id`
LEFT JOIN `subject` ON `subject`.`uid`=`kams_video_classroom`.`subject_id`
ORDER BY `kams_video_classroom`.`id` DESC
ERROR - 2020-03-29 14:49:47 --> Query error: Unknown column 'subject.uid' in 'on clause' - Invalid query: SELECT *
FROM `kams_video_classroom`
JOIN `kams_users` ON `kams_users`.`uid`=`kams_video_classroom`.`teacher_id`
LEFT JOIN `class` ON `class`.`id`=`kams_video_classroom`.`class_id`
LEFT JOIN `subject` ON `subject`.`uid`=`kams_video_classroom`.`subject_id`
ORDER BY `kams_video_classroom`.`id` DESC
ERROR - 2020-03-29 14:55:00 --> Query error: Unknown column 'kams_users.phone' in 'field list' - Invalid query: SELECT `kams_video_classroom`.*, `kams_users`.`first_name`, `kams_users`.`email`, `kams_users`.`phone`, `kams_users`.`last_name`, `class`.`name` AS `classname`, `subject`.`name` AS `subjectname`
FROM `kams_video_classroom`
JOIN `kams_users` ON `kams_users`.`uid`=`kams_video_classroom`.`teacher_id`
LEFT JOIN `class` ON `class`.`id`=`kams_video_classroom`.`class_id`
LEFT JOIN `subject` ON `subject`.`id`=`kams_video_classroom`.`subject_id`
ORDER BY `kams_video_classroom`.`id` DESC
ERROR - 2020-03-29 14:55:00 --> Severity: error --> Exception: Call to a member function result_array() on boolean /var/www/html/onlineclassroom/application/models/Videoclassroom_model.php 31
ERROR - 2020-03-29 14:55:05 --> Query error: Unknown column 'kams_users.phone' in 'field list' - Invalid query: SELECT `kams_video_classroom`.*, `kams_users`.`first_name`, `kams_users`.`email`, `kams_users`.`phone`, `kams_users`.`last_name`, `class`.`name` AS `classname`, `subject`.`name` AS `subjectname`
FROM `kams_video_classroom`
JOIN `kams_users` ON `kams_users`.`uid`=`kams_video_classroom`.`teacher_id`
LEFT JOIN `class` ON `class`.`id`=`kams_video_classroom`.`class_id`
LEFT JOIN `subject` ON `subject`.`id`=`kams_video_classroom`.`subject_id`
ORDER BY `kams_video_classroom`.`id` DESC
