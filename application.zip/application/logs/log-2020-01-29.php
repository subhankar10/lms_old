<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-29 10:02:07 --> Severity: Warning --> Division by zero /var/www/html/equizAdmin/application/views/dashboard.php 294
ERROR - 2020-01-29 13:25:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 217
ERROR - 2020-01-29 13:26:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 202
ERROR - 2020-01-29 13:26:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 202
ERROR - 2020-01-29 13:26:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 202
ERROR - 2020-01-29 13:26:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 202
ERROR - 2020-01-29 13:46:03 --> Severity: error --> Exception: Too few arguments to function Qbank_model::question_list(), 3 passed in /var/www/html/equizAdmin/application/controllers/Qbank.php on line 94 and exactly 4 expected /var/www/html/equizAdmin/application/models/Qbank_model.php 5
ERROR - 2020-01-29 13:46:49 --> Severity: error --> Exception: Too few arguments to function Qbank_model::question_list(), 3 passed in /var/www/html/equizAdmin/application/controllers/Qbank.php on line 94 and exactly 4 expected /var/www/html/equizAdmin/application/models/Qbank_model.php 5
ERROR - 2020-01-29 13:46:51 --> Severity: error --> Exception: Too few arguments to function Qbank_model::question_list(), 3 passed in /var/www/html/equizAdmin/application/controllers/Qbank.php on line 94 and exactly 4 expected /var/www/html/equizAdmin/application/models/Qbank_model.php 5
ERROR - 2020-01-29 14:40:55 --> Severity: error --> Exception: Too few arguments to function Qbank_model::question_list(), 3 passed in /var/www/html/equizAdmin/application/controllers/Qbank.php on line 93 and exactly 4 expected /var/www/html/equizAdmin/application/models/Qbank_model.php 5
ERROR - 2020-01-29 14:40:56 --> Severity: error --> Exception: Too few arguments to function Qbank_model::question_list(), 3 passed in /var/www/html/equizAdmin/application/controllers/Qbank.php on line 93 and exactly 4 expected /var/www/html/equizAdmin/application/models/Qbank_model.php 5
ERROR - 2020-01-29 14:41:19 --> Severity: error --> Exception: Too few arguments to function Qbank_model::question_list(), 3 passed in /var/www/html/equizAdmin/application/controllers/Qbank.php on line 93 and exactly 4 expected /var/www/html/equizAdmin/application/models/Qbank_model.php 5
ERROR - 2020-01-29 14:41:26 --> Severity: error --> Exception: Too few arguments to function Qbank_model::question_list(), 3 passed in /var/www/html/equizAdmin/application/controllers/Qbank.php on line 93 and exactly 4 expected /var/www/html/equizAdmin/application/models/Qbank_model.php 5
ERROR - 2020-01-29 14:41:40 --> Severity: error --> Exception: Too few arguments to function Qbank_model::question_list(), 3 passed in /var/www/html/equizAdmin/application/controllers/Qbank.php on line 93 and exactly 4 expected /var/www/html/equizAdmin/application/models/Qbank_model.php 5
ERROR - 2020-01-29 14:41:45 --> Severity: error --> Exception: Too few arguments to function Qbank_model::question_list(), 3 passed in /var/www/html/equizAdmin/application/controllers/Qbank.php on line 93 and exactly 4 expected /var/www/html/equizAdmin/application/models/Qbank_model.php 5
ERROR - 2020-01-29 14:41:46 --> Severity: error --> Exception: Too few arguments to function Qbank_model::question_list(), 3 passed in /var/www/html/equizAdmin/application/controllers/Qbank.php on line 93 and exactly 4 expected /var/www/html/equizAdmin/application/models/Qbank_model.php 5
ERROR - 2020-01-29 14:43:17 --> Severity: error --> Exception: Too few arguments to function Qbank_model::question_list(), 3 passed in /var/www/html/equizAdmin/application/controllers/Qbank.php on line 93 and exactly 4 expected /var/www/html/equizAdmin/application/models/Qbank_model.php 5
ERROR - 2020-01-29 14:43:19 --> Severity: error --> Exception: Too few arguments to function Qbank_model::question_list(), 3 passed in /var/www/html/equizAdmin/application/controllers/Qbank.php on line 93 and exactly 4 expected /var/www/html/equizAdmin/application/models/Qbank_model.php 5
ERROR - 2020-01-29 14:55:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/quiz_list.php 24
ERROR - 2020-01-29 14:55:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/quiz_list.php 39
ERROR - 2020-01-29 14:57:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/quiz_list.php 25
ERROR - 2020-01-29 14:57:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/quiz_list.php 40
ERROR - 2020-01-29 14:57:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/quiz_list.php 24
ERROR - 2020-01-29 14:57:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/quiz_list.php 39
ERROR - 2020-01-29 14:57:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/quiz_list.php 24
ERROR - 2020-01-29 14:57:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/quiz_list.php 39
ERROR - 2020-01-29 14:58:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/quiz_list.php 29
ERROR - 2020-01-29 14:58:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/quiz_list.php 44
ERROR - 2020-01-29 15:00:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/quiz_list.php 30
ERROR - 2020-01-29 15:00:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/quiz_list.php 45
ERROR - 2020-01-29 15:02:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/quiz_list.php 30
ERROR - 2020-01-29 15:02:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/quiz_list.php 45
ERROR - 2020-01-29 15:14:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/quiz_list.php 30
ERROR - 2020-01-29 15:14:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/quiz_list.php 45
ERROR - 2020-01-29 15:16:01 --> Could not find the language line "all_type"
ERROR - 2020-01-29 15:19:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmin/application/views/examiner_list.php 202
ERROR - 2020-01-29 15:36:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 32
ERROR - 2020-01-29 16:26:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 32
ERROR - 2020-01-29 16:33:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 32
ERROR - 2020-01-29 16:55:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 32
ERROR - 2020-01-29 16:58:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 32
ERROR - 2020-01-29 16:58:58 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 32
ERROR - 2020-01-29 17:01:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 32
ERROR - 2020-01-29 17:05:11 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 32
ERROR - 2020-01-29 17:07:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 32
ERROR - 2020-01-29 17:07:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 32
ERROR - 2020-01-29 17:08:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 32
ERROR - 2020-01-29 17:09:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 32
ERROR - 2020-01-29 17:11:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 32
ERROR - 2020-01-29 17:12:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 32
ERROR - 2020-01-29 17:16:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 32
ERROR - 2020-01-29 17:16:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 32
ERROR - 2020-01-29 17:16:50 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 32
ERROR - 2020-01-29 17:18:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 32
ERROR - 2020-01-29 17:20:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 32
ERROR - 2020-01-29 17:23:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 35
ERROR - 2020-01-29 17:23:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 35
ERROR - 2020-01-29 17:49:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 35
ERROR - 2020-01-29 18:00:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 35
ERROR - 2020-01-29 18:01:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 35
ERROR - 2020-01-29 18:19:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 35
ERROR - 2020-01-29 18:23:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 35
ERROR - 2020-01-29 18:30:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 35
ERROR - 2020-01-29 18:31:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 35
ERROR - 2020-01-29 18:32:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 35
ERROR - 2020-01-29 18:33:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 35
ERROR - 2020-01-29 18:33:18 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 35
ERROR - 2020-01-29 18:33:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 35
ERROR - 2020-01-29 18:34:14 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 35
ERROR - 2020-01-29 18:34:51 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 35
ERROR - 2020-01-29 18:40:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmin/application/views/exam_listing.php 41
