<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-06 18:10:33 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 294
ERROR - 2020-01-06 18:17:22 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 294
ERROR - 2020-01-06 18:18:37 --> Severity: Warning --> require_once(/var/www/html/equiz/application/controllers/Api.php): failed to open stream: Permission denied /var/www/html/equiz/system/core/CodeIgniter.php 411
ERROR - 2020-01-06 18:18:38 --> Severity: Compile Error --> require_once(): Failed opening required '/var/www/html/equiz/application/controllers/Api.php' (include_path='.:/usr/share/php') /var/www/html/equiz/system/core/CodeIgniter.php 411
ERROR - 2020-01-06 18:18:48 --> Severity: Warning --> require_once(/var/www/html/equiz/application/controllers/Api.php): failed to open stream: Permission denied /var/www/html/equiz/system/core/CodeIgniter.php 411
ERROR - 2020-01-06 18:18:48 --> Severity: Compile Error --> require_once(): Failed opening required '/var/www/html/equiz/application/controllers/Api.php' (include_path='.:/usr/share/php') /var/www/html/equiz/system/core/CodeIgniter.php 411
ERROR - 2020-01-06 18:19:18 --> Severity: Warning --> require_once(/var/www/html/equiz/application/controllers/Api.php): failed to open stream: Permission denied /var/www/html/equiz/system/core/CodeIgniter.php 411
ERROR - 2020-01-06 18:19:18 --> Severity: Compile Error --> require_once(): Failed opening required '/var/www/html/equiz/application/controllers/Api.php' (include_path='.:/usr/share/php') /var/www/html/equiz/system/core/CodeIgniter.php 411
ERROR - 2020-01-06 18:19:27 --> Severity: Warning --> require_once(/var/www/html/equiz/application/controllers/Api.php): failed to open stream: Permission denied /var/www/html/equiz/system/core/CodeIgniter.php 411
ERROR - 2020-01-06 18:19:27 --> Severity: Compile Error --> require_once(): Failed opening required '/var/www/html/equiz/application/controllers/Api.php' (include_path='.:/usr/share/php') /var/www/html/equiz/system/core/CodeIgniter.php 411
ERROR - 2020-01-06 18:21:06 --> Severity: Warning --> require_once(/var/www/html/equiz/application/controllers/Api.php): failed to open stream: Permission denied /var/www/html/equiz/system/core/CodeIgniter.php 411
ERROR - 2020-01-06 18:21:06 --> Severity: Compile Error --> require_once(): Failed opening required '/var/www/html/equiz/application/controllers/Api.php' (include_path='.:/usr/share/php') /var/www/html/equiz/system/core/CodeIgniter.php 411
ERROR - 2020-01-06 18:30:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equiz/application/views/dashboard.php 234
ERROR - 2020-01-06 18:30:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/dashboard.php 243
ERROR - 2020-01-06 18:30:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/dashboard.php 271
ERROR - 2020-01-06 18:30:23 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 294
ERROR - 2020-01-06 18:30:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equiz/application/views/dashboard.php 374
ERROR - 2020-01-06 18:30:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equiz/application/views/dashboard.php 398
ERROR - 2020-01-06 18:30:35 --> Severity: Warning --> Division by zero /var/www/html/equiz/application/views/dashboard.php 294
ERROR - 2020-01-06 18:46:31 --> Severity: Warning --> mysqli::__construct(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) /var/www/html/equiz/application/config/config.php 515
ERROR - 2020-01-06 19:01:43 --> Severity: Warning --> mysqli::__construct(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) /var/www/html/equiz/application/config/config.php 515
ERROR - 2020-01-06 19:02:21 --> Severity: Warning --> mysqli::__construct(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) /var/www/html/equiz/application/config/config.php 515
ERROR - 2020-01-06 19:02:41 --> Severity: Warning --> mysqli::__construct(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) /var/www/html/equiz/application/config/config.php 515
