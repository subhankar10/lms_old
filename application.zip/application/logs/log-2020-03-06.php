<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-06 11:41:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-06 11:41:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/header.php 155
ERROR - 2020-03-06 11:41:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/equizAdmindesign/application/views/dashboard.php 196
ERROR - 2020-03-06 11:41:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/dashboard.php 201
ERROR - 2020-03-06 11:41:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:41:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:41:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:41:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:41:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:41:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:41:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:41:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:41:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:41:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:41:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:41:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:41:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:41:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:41:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:41:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:41:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:41:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:41:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:41:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:41:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:41:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:41:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:41:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:41:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:41:53 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:44:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:44:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:44:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:44:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:44:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:44:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:44:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:44:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:44:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:44:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:44:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:44:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:44:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:44:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:44:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:44:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:44:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:44:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:44:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:44:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:44:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:44:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:44:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:44:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:44:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 11:44:13 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /var/www/html/equizAdmindesign/application/views/roles_permission.php 50
ERROR - 2020-03-06 13:23:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/new_agency.php 73
ERROR - 2020-03-06 13:38:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 184
ERROR - 2020-03-06 14:55:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 184
ERROR - 2020-03-06 14:56:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 184
ERROR - 2020-03-06 15:47:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 184
ERROR - 2020-03-06 15:51:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/new_agency.php 73
ERROR - 2020-03-06 15:53:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/new_agency.php 73
ERROR - 2020-03-06 16:00:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/new_agency.php 73
ERROR - 2020-03-06 16:21:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 184
ERROR - 2020-03-06 16:27:52 --> Severity: error --> Exception: Call to undefined method CI_Loader::lang_line() /var/www/html/equizAdmindesign/application/views/examiner_list.php 47
ERROR - 2020-03-06 16:27:54 --> Severity: error --> Exception: Call to undefined method CI_Loader::lang_line() /var/www/html/equizAdmindesign/application/views/examiner_list.php 47
ERROR - 2020-03-06 16:28:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 188
ERROR - 2020-03-06 16:28:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 188
ERROR - 2020-03-06 16:28:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 188
ERROR - 2020-03-06 16:28:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 188
ERROR - 2020-03-06 16:30:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 188
ERROR - 2020-03-06 16:32:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 188
ERROR - 2020-03-06 16:49:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 188
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/inline_renderer.cls.php 109
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/inline_renderer.cls.php 109
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/inline_renderer.cls.php 47
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/inline_renderer.cls.php 109
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/inline_renderer.cls.php 47
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/inline_renderer.cls.php 109
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:50:21 --> Severity: Warning --> A non-numeric value encountered /var/www/html/equizAdmindesign/application/libraries/dompdf/include/style.cls.php 1280
ERROR - 2020-03-06 16:51:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 188
ERROR - 2020-03-06 17:01:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 188
ERROR - 2020-03-06 17:01:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 188
ERROR - 2020-03-06 17:02:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 188
ERROR - 2020-03-06 17:02:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 188
ERROR - 2020-03-06 17:03:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 188
ERROR - 2020-03-06 17:04:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 188
ERROR - 2020-03-06 17:04:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 188
ERROR - 2020-03-06 17:04:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 188
ERROR - 2020-03-06 17:04:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 188
ERROR - 2020-03-06 17:05:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 188
ERROR - 2020-03-06 17:05:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 188
ERROR - 2020-03-06 17:05:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 188
ERROR - 2020-03-06 17:07:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 188
ERROR - 2020-03-06 17:09:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 188
ERROR - 2020-03-06 17:31:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/management_user_list.php 190
ERROR - 2020-03-06 17:40:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 188
ERROR - 2020-03-06 17:42:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/equizAdmindesign/application/views/examiner_list.php 188
