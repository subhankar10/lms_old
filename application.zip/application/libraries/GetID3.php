<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class GetID3 {  

    function __construct ( $options = array() )
    {
        require_once( APPPATH . 'libraries/getid3/getid3.php' );
    }

    public function __get( $var ) { return get_instance()->$var; }
}