<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Room_manage extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->database();
        $this->load->helper('url');
        $this->lang->load('basic', $this->config->item('language'));
        $this->load->library("pagination");
        $this->config->load('masterdata');
        // redirect if not loggedin
        if (!$this->session->userdata('logged_in')) {
            redirect('login');
        }
        $logged_in = $this->session->userdata('logged_in');
        if ($logged_in['base_url'] != base_url()) {
            $this->session->unset_userdata('logged_in');
            redirect('login');
        }
    }
    
    public function room_page(){
        $this->load->view('create_room');
    }
    
    public function create_room(){
        $server = "https://raysha.in/bigbluebutton/";
        $secret = "v5h6qLnW3lbjzrc1wVv77YeEo98yeLj0jKKqGnpenT8";
        $mid = $_POST['mid'];
        $name = $_POST['mid'];
        $stupw = $_POST['stupw'];
        $teapw = $_POST['teapw'];
        $record = $_POST['record'];
        $autosr = $_POST['autosr'];
        $voiceb = '71346';
        $tempstr='allowStartStopRecording=true&attendeePW='.$stupw.'&autoStartRecording='.$autosr.'&duration=60&meetingID='.$mid.'&moderatorPW='.$teapw.'&name='.$name.'&record='.$record.'&voiceBridge='.$voiceb;
        $tempstr1='createallowStartStopRecording=true&attendeePW='.$stupw.'&autoStartRecording='.$autosr.'&duration=60&meetingID='.$mid.'&moderatorPW='.$teapw.'&name='.$name.'&record='.$record.'&voiceBridge='.$voiceb.$secret;
        $sha1_key = sha1($tempstr1);
        $url = $server.'api/create?'.$tempstr.'&checksum='.$sha1_key;
        $ch = curl_init();

        //set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        // print_r($result);
        if($result){
            echo json_encode(array($mid,$teapw));
        }else{
            echo json_encode(array($result));
        }
        // echo json_encode(array($server.'api/create?'.$tempstr.'&checksum='.$sha1_key,$mid,$teapw));
        
    }
    
    public function join_teacher(){
        $server = "https://raysha.in/bigbluebutton/";
        $secret = "v5h6qLnW3lbjzrc1wVv77YeEo98yeLj0jKKqGnpenT8";
        $clienturl = 'https%3A%2F%2Fraysha.in%2Fhtml5client%2Fjoin';
        $meetid = $_POST['meetid'];
        $teacherpass = $_POST['teach'];
        $rempstr = 'clientURL='.$clienturl.'&fullName=rathin&meetingID='.$meetid.'&password='.$teacherpass.'&redirect=true';
        $rempstr1 = 'join'.$rempstr.$secret;
        $sha1key = sha1($rempstr1);
        echo json_encode(array($server.'api/join?'.$rempstr.'&checksum='.$sha1key));
    }
    
    public function student_page(){
        $this->load->view('student_join');
    }
    
    public function join_student(){
        $server = "https://raysha.in/bigbluebutton/";
        $secret = "v5h6qLnW3lbjzrc1wVv77YeEo98yeLj0jKKqGnpenT8";
        $clienturl = 'https%3A%2F%2Fraysha.in%2Fhtml5client%2Fjoin';
        $rempstr = 'clientURL='.$clienturl.'&fullName=durga&meetingID=java1234&password=ap&redirect=true';
        $rempstr1 = 'join'.$rempstr.$secret;
        $sha1key = sha1($rempstr1);
        echo json_encode(array($server.'api/join?'.$rempstr.'&checksum='.$sha1key));
    }
    
}