<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Student_cont extends CI_Controller {
      function __construct() {
        parent::__construct();
        $this->load->database();
        $this->load->helper('url');
        $this->load->model("user_model");
        $this->load->model("account_model");
        $this->load->model("examiner_model");
        $this->load->model("classroom_model");
        $this->config->load("masterdata");
        $this->lang->load('basic', $this->config->item('language'));
        $this->load->library("pagination");
        // redirect if not loggedin
        if (!$this->session->userdata('logged_in')) {
            redirect('login');
        }
        $logged_in = $this->session->userdata('logged_in');
        if ($logged_in['base_url'] != base_url()) {
            $this->session->unset_userdata('logged_in');
            redirect('login');
        }
    }
  
    public function new_userstudent() {
       $this->load->view('header');
       $this->load->view('student/studentdoc');
        $this->load->view('footer');
    }
     
     
    public function add_user() {
        $this->load->model("Student_model");  
        $data['first_name']=$_POST['first_name'];
	    $data['contact_no']=$_POST['contact_no'];
	    $data['email']=$_POST['email'];
	    $data['last_name']=$_POST['last_name'];
	    $data['qualification']=$_POST['qualification'];
	    $data['country']=$_POST['country'];
	    $data['city']=$_POST['city'];
	    $data['state']=$_POST['state'];
	    $data['status']=$_POST['status'];
	    $data['gender']=$_POST['gender'];
	    $data['dob']=$_POST['dob'];
	    $data['p_assword']=$_POST['password'];
          $data['student_list'] = $this->Student_model->student_add($data);
          $this->load->view('header');
       $this->load->view('student/studentdoc');
        $this->load->view('footer');
    }
   
    public function check_valid_email(){
        $this->load->model("Student_model"); 
          $data['email']=$_POST['email'];
        $data['student_email'] = $this->Student_model->student_emailid($data);
        echo json_encode($data['student_email']);
        // echo json_encode(1);
    }
        
    
 
    public function show_studentlist_view(){
        $this->load->model("Student_model");
	    $data['cate_list'] = $this->Student_model->show_studentlist();
	    
	    $this->load->view('header',$data);
        $this->load->view('student_list',$data);
        $this->load->view('footer',$data);
    }
    
     public function show_course(){
      
	     $this->load->model("Course_model");  
        $data['categorie'] = $this->Course_model->choice_categorie();
	    $this->load->view('header',$data);
        $this->load->view('student_buypage',$data);
        $this->load->view('footer',$data);
    }
     public function lession_start(){
      
	    $this->load->model("Course_model");  
        $data['categorie'] = $this->Course_model->choice_categorie();
	    $this->load->view('header',$data);
        $this->load->view('reading',$data);
        $this->load->view('footer',$data);
    }
    //   public function nav_catagory() {
    //     $this->load->model("Course_model");  
    //     $data['categorie'] = $this->Course_model->choice_categorie();
    //     print_r($data['categorie']);
    //     $this->load->view('header',$data);
      
    //  }
    //       public function my_course(){
    //       $this->load->model("Student_model");  
    //       $data['cou_id']=$_POST['cou_id'];
    //       $data['my_course'] = $this->Student_model->my_course($data);
    // }
    public function student_home(){
         $this->load->model("Video_model"); 
        $data['video_view'] = $this->Video_model->show_mainvideoview();
        $data['path'] = $_SERVER['HTTP_HOST'].'/assetsimg/';
        // $geo = new Geoip();
        // $js = $geo->geolocalization($_SERVER['REMOTE_ADDR']);
        // $data['c_code'] = $geo->info()->currency->symbol;
          $this->load->model("Course_model");
          $this->load->model('Cart_model');
            $data['categorie'] = $this->Course_model->choice_categorie();
	    $this->load->view('header',$data);
        $this->load->view('home_student',$data);
        $this->load->view('footer',$data);
    }
}