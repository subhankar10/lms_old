<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Teacher_cont extends CI_Controller {
   function __construct() {
        parent::__construct();
        $this->load->database();
        $this->load->helper('url');
        $this->lang->load('basic', $this->config->item('language'));
    }

 public function new_teacheradd(){
     
     $this->load->view('header');
        $this->load->view('teacher_add');
        $this->load->view('footer');
     
 }
 
 public function teacher_add(){
     $this->load->model("Teacher_model"); 
     $data['first_name']=$_POST['first_name'];
     $data['contact_no']=$_POST['contact_no'];
     $data['id_city']=$_POST['id_city'];
     $data['state']=$_POST['state'];
     $data['last_name']=$_POST['last_name'];
     $data['email']=$_POST['email'];
     $data['country']=$_POST['country'];
     $data['p_assword']=$_POST['password'];
     $data['dob']=$_POST['dob'];
          $data['qualification']=$_POST['qualification'];
     $data['gender']=$_POST['gender'];
     $data['teacher_list'] = $this->Teacher_model->teacher_add($data);
     $this->load->view('header');
        $this->load->view('teacher_add');
        $this->load->view('footer');
 
 }
 
 
  public function check_valid_userid(){
        $this->load->model("Teacher_model"); 
          $data['email']=$_POST['email'];
        $data['teacher_email'] = $this->Teacher_model->teacher_emailid($data);
        echo json_encode($data['teacher_email']);
        // echo json_encode(1);
    }
 
  public function show_teacherlist_view(){
        $this->load->model("Teacher_model");
	    $data['cate_list'] = $this->Teacher_model->show_teacherlist();
	    
	    $this->load->view('header',$data);
        $this->load->view('teacher_list',$data);
        $this->load->view('footer',$data);
    }
 
 
}