<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Cart extends CI_Controller {
      function __construct() {
        parent::__construct();
        $this->load->database();
        include APPPATH . 'libraries/getid3/getid3.php';
        $this->db2 = $this->load->database('serverdb2', TRUE);
        $this->load->helper('url');
        $this->load->helper('form');
        $this->lang->load('basic', $this->config->item('language'));
        $this->load->library("pagination");
        // redirect if not loggedin
        // if (!$this->session->userdata('logged_in')) {
        //     redirect('login');
        // }
        // $logged_in = $this->session->userdata('logged_in');
        // if ($logged_in['base_url'] != base_url()) {
        //     $this->session->unset_userdata('logged_in');
        //     redirect('login');
        // }
    }
    
    public function billing(){
        $this->load->model('Cart_model');
        $data['cou_id'] = $_POST['cou_id'];
        $data['result_cart'] = $this->Cart_model->cart($data);
        $data['addToCart'] = $this->Cart_model->AddToCart($data);
        if($data['addToCart'][0]['id']==0){
            redirect('Login');
        }else{
            if (!$this->session->userdata('logged_in')) {
                redirect('Login/userLogin');
            }else{
                $this->load->view('cart',$data);
            }
        }
    }
    
    public function cart_billing(){
        $this->load->model("Course_model");  
         $this->load->model('Cart_model');
        $data['categorie'] = $this->Course_model->choice_categorie();
            $data['su_user'] = $this->session->userdata('logged_in')['uid'];
            $data['student_cart'] = $this->Cart_model->student_cart_add($data);
            $data['cart_count'] = $this->Cart_model->cart_count($data);
            $data['course_list'] = $this->Cart_model->course_list($data);
            $data['cou_id'] = $_POST['cou_id'];
            $data['course_price'] = $this->Cart_model->course_price($data);
        $this->load->view('header',$data);
        $this->load->view('cart',$data);
        $this->load->view('footer',$data);
    }
    
     public function my_course(){
        $this->load->model("Course_model");
        $this->load->model('Cart_model');
        $data['course_id'] = $_POST['cart_id'];
        $data['categorie'] = $this->Course_model->choice_categorie();
        $data['su_user'] = $this->session->userdata('logged_in')['uid'];
        $data['result'] = $this->Cart_model->purchase_course($data);
        $data['cart_count'] = $this->Cart_model->cart_count($data);
        $data['course_list'] = $this->Cart_model->course_list($data);
            
        $this->load->view('header',$data);
        $this->load->view('sucess',$data);
        $this->load->view('footer',$data);   
     }
     
      public function my_course_chapter(){
        $this->load->model("Course_model");
        $this->load->model('Cart_model');
        $this->load->model('Video_model');
        
        $data['course_id'] = $_GET['course_id'];
        $data['categorie'] = $this->Course_model->choice_categorie();
        $data['su_user'] = $this->session->userdata('logged_in')['uid'];
        // $data['result'] = $this->Cart_model->purchase_course($data);
        $data['cart_count'] = $this->Cart_model->cart_count($data);
        $data['my_course'] = $this->Cart_model->my_course($data);
        $data['my_lession'] = $this->Cart_model->my_video_lession($data);
        
        
        $data['cou_id'] = $data['course_id'];
        $data['video_chapter'] = $this->Video_model->course_chapter($data);
        
        $data['path'] = $_SERVER['HTTP_HOST'].'/assetsimg/';
        $data['path_video'] = $_SERVER['HTTP_HOST'].'/coursevideo/';
        $this->load->view('header',$data);
        $this->load->view('my_course_lession',$data);
        $this->load->view('footer',$data);    
      }
      
      public function mycourse_list(){
            $this->load->model("Course_model");  
         $this->load->model('Cart_model');
        $data['categorie'] = $this->Course_model->choice_categorie();
            $data['su_user'] = $this->session->userdata('logged_in')['uid'];
            $data['student_cart'] = $this->Cart_model->student_cart_add($data);
            $data['cart_count'] = $this->Cart_model->cart_count($data);
            $data['course_list'] = $this->Cart_model->course_list($data);
            $data['path'] = $_SERVER['HTTP_HOST'].'/assetsimg/';
            $data['mycourse_listview'] = $this->Cart_model->mycourse_listview($data);
        $this->load->view('header',$data);
        $this->load->view('my_course_list',$data);
        $this->load->view('footer',$data);    
      }
    
}