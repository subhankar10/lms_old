<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Video extends CI_Controller {
      function __construct() {
        parent::__construct();
        $this->load->database();
        include APPPATH . 'libraries/getid3/getid3.php';
        $this->db2 = $this->load->database('serverdb2', TRUE);
        $this->load->helper('url');
        $this->load->helper('form');
        $this->lang->load('basic', $this->config->item('language'));
        $this->load->library("pagination");
        // redirect if not loggedin
        if (!$this->session->userdata('logged_in')) {
            redirect('login');
        }
        $logged_in = $this->session->userdata('logged_in');
        if ($logged_in['base_url'] != base_url()) {
            $this->session->unset_userdata('logged_in');
            redirect('login');
        }
    }
    
    public function videoview(){
        $this->load->model('Video_model');
        $data['cou_id'] = $_POST['cou_id'];
        $data['result'] = $this->Video_model->course_chapter($data);
        $data['info_course'] = $this->Video_model->info_courselist1($data);
        $data['path'] = $_SERVER['HTTP_HOST'].'/coursevideo/';
        $this->load->view('header',$data);
        $this->load->view('videoview',$data);
        $this->load->view('footer',$data);
     }
     
    public function chapterVideo(){
        $this->load->model('Video_model');
        $data['chapterId'] = $_POST['chapterId'];
        $data['result'] = $this->Video_model->chapter_video($data);
        $data['finalResult'] = $this->retriveDuration($data['result']);
        echo json_encode($data['finalResult']);
    }
    
    function retriveDuration($file_result){
        $count = count($file_result);
        $with_duration = array();
        $file_path = $_SERVER['HTTP_HOST'].'/coursevideo/';
        $getID3 = new getID3;
        for($i=0;$i<$count;$i++){
            $tempArray = array();
            $file_name = 'https://'.$file_path.$file_result[$i]['course_video'];
            $arr = explode('.',$file_name);
            $file_type = strtolower($arr[sizeof($arr)-1]);
            if($file_type == 'mp4'){
            if ($fp_remote = fopen($file_name, 'rb')) {
            $localtempfilename = tempnam('/tmp', 'getID3');
            if ($fp_local = fopen($localtempfilename, 'wb')) {
                while ($buffer = fread($fp_remote, 8192)) {
                fwrite($fp_local, $buffer);
                }
            fclose($fp_local);
            // Initialize getID3 engine
            $getID3 = new getID3;
            $ThisFileInfo = $getID3->analyze($localtempfilename);
            $tempArray['video_description'] = $file_result[$i]['video_description'];
            $tempArray['course_video'] = $file_result[$i]['course_video'];
            $tempArray['duration'] = $ThisFileInfo['playtime_string'];
            // Delete temporary file
            unlink($localtempfilename);
            }
                fclose($fp_remote);
            }
            array_push($with_duration,$tempArray);
        }else{
            $tempArray['video_description'] = $file_result[$i]['video_description'];
            $tempArray['course_video'] = $file_result[$i]['course_video'];
            array_push($with_duration,$tempArray);
        }
        }
        return $with_duration;
    }
    
   
    
    
    
    
}