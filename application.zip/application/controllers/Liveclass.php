<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Liveclass extends CI_Controller {

    function __construct() {
        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Headers: *");
        parent::__construct();
        $this->load->database();
        $this->load->helper('url');

        $controller = $this->router->fetch_class();
        $method = $this->router->fetch_method();

        ini_set('display_errors', 0);
        if (version_compare(PHP_VERSION, '5.3', '>=')) {
            error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED & ~E_STRICT & ~E_USER_NOTICE & ~E_USER_DEPRECATED);
        } else {
            error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT & ~E_USER_NOTICE);
        }

        $this->config->load('masterdata');
        $this->lang->load('basic', $this->config->item('language'));
    }

    public function index($api_key = '0') {
        exit('I am fine, No syntex error');
    }

    private function saudidateformate($date) {
        $datef = explode("-", $date); //yy-mm-dd
        return $datef[2] . "/" . $datef[1] . "/" . $datef[0]; //mm/dd/yy
    }

    private function sauditimeformate($time) {
        $datef = explode(":", $time); //yy-mm-dd
        $hour = (int) $datef[0];
        if ($hour < 12) {
            $time = $hour < 10 ? "0" . $hour . " AM" : $hour . " AM";
        } else {
            $hour = $hour - 12;
            $time = $hour < 10 ? "0" . $hour . " PM" : $hour . " PM";
        }
        return $time; //mm/dd/yy
    }

    public function testEmail() {
        $subject = "Kams Global - Contact Us";
        $dataEmail = array();
        $dataEmail['name'] = "Pramodini"; //$data_ins['firstname'];
        $dataEmail['link'] = "Link";
        $body = $this->load->view('mail/contactus', $dataEmail, true);
        $to = "applicantelpt2020@gmail.com";
        $a = $this->sendEmail($subject, $body, $to);
        print $a;
    }

    public function sendEmail($subject, $body, $to, $cc = null, $filepath = null, $flg = 0) {
        //$flg = 1;
        if (!$to || !$subject || !$body) {
            return true;
        }

        $config = Array(
            'protocol' => 'smtp',
            'smtp_host' => 'lnx25.securehostdns.com',
            // 'smtp_host' => 'ssl://smtp.zoho.com',
            'smtp_port' => 587,
            'smtp_user' => 'smtp@thoughtspheres.com',
            'smtp_pass' => 'smtp@#$2016',
            'mailtype' => 'html',
                //'smtp_user' => 'alert@iliftserviceapp.com',
                //'smtp_pass' => 'Ali#241@dkj'
        );
        $config2 = Array(
            'protocol' => 'tls',
            'smtp_host' => 'smtp.gmail.com',
            // 'smtp_host' => 'ssl://smtp.zoho.com',
            'smtp_port' => 587,
            'smtp_user' => 'smptelpt2020@gmail.com',
            'smtp_pass' => 'Pass@1234',
            'mailtype' => 'html',
                //'smtp_user' => 'alert@iliftserviceapp.com',
                //'smtp_pass' => 'Ali#241@dkj'
        );


        $this->load->library('email', $config);
        $this->email->set_newline("\r\n");
        $this->email->from('smtpgoamrut@gmail.com', 'Admin');
        if ($to) {
            $this->email->to($to);
        }

        if ($cc) {
            $this->email->cc($cc);
        }
        if ($filepath) {
            $this->email->attach($filepath);
        }

        $this->email->subject($subject);
        $this->email->message($body);

        if ($flg) {
            if (!$this->email->send()) {
                print_r($this->email->print_debugger());
            } else {
                echo 'Your e-mail has been sent!';
            }
        } else {
            return $this->email->send();
        }


        return true;
    }

    private function createpdf($rid) {
        $this->load->library('pdf');
        $this->load->model("result_model");
        $data = array();
        $data['result'] = $this->result_model->get_result($rid);
        // print_r($data); exit();
        $data['exam_category'] = $this->config->item('exam_category');
        $data['dob'] = date('d/m/Y', strtotime($data['result']['dob']));
        $data['start_date'] = date('d/m/Y', strtotime($data['result']['start_date_result']));
        $startdate = strtotime($data['result']['start_date_result']);
        $data['expirydate'] = date('d/m/Y', strtotime('+15 years', $startdate));
//        $a = $this->load->view('mypdf', $data,true);
//        print $a; exit();
        $this->pdf->load_view('mypdf', $data);
        $this->load->helper('file');
        $this->pdf->render();
        $output = $this->pdf->output();
        $pdfroot = base_url();
        $filename = time() . ".pdf";
        file_put_contents('./result_pdf/' . $filename, $output);

        $this->db->where('rid', $rid);
        $this->db->update('kams_result', array("report_pdf" => $filename));
        return true;
    }
    
    public function insertClassroom(){
        //print "11"; exit();
        $this->createclassroom(1);
    }

    private function createclassroom($rid) {
//        ini_set('display_errors', 1);
//        ini_set('display_startup_errors', 1);
//        error_reporting(E_ALL);
        define('VIIRTUALCLASSROOMPATH', $_SERVER['DOCUMENT_ROOT'] . '/onlineclassroom/WiZiQClassAPI/'); // OR exit('No direct script access allowed');
        
        $access_key = "022QF06E7MXBSH9DHM02"; //"<<your access key>>";
        $secretAcessKey = "kWcrlUX5JEDGM/LtmEENI/aVmYvHNif5zB+d9+ct"; //"<<your secret key>>";
        $webServiceUrl = "http://classapi.wiziqxt.com/apimanager.ashx";
        
        require_once(VIIRTUALCLASSROOMPATH . "create.php");
        $obj = new ScheduleClass($secretAcessKey, $access_key, $webServiceUrl);

        $myfile = fopen("newfile.txt", "a+") or die("Unable to open file!");
        $txt = print_r($obj, true);
        fwrite($myfile, $txt);
        $txt = print_r($roomdetails, true);
        fwrite($myfile, $txt);
        $txt = $this->db->last_query();
        fwrite($myfile, $txt);
        fclose($myfile);

        return $roomID;
    }

    public function getRecord() {
        $roomID = $_GET['roomid'];
        $login = '5e316b0f90ef809cde545f05';
        $password = 'uyVynu3u3y2aDejumyLy9ezu5uReYuWaYevy';
        $url = 'https://api.enablex.io/v1/archive/room/' . $roomID;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        curl_setopt($ch, CURLOPT_USERPWD, "$login:$password");
        $result = curl_exec($ch);

        curl_close($ch);
        $res = json_decode($result, true);
        //echo($result);
        print "<pre>";
        print_r($res);
    }

}
