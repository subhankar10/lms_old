<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Categories_controller extends CI_Controller {
    function __construct() {
        parent::__construct();
        $this->load->database();
        $this->load->helper('url');
        $this->lang->load('basic', $this->config->item('language'));
    }
    public function add_categorie_page(){
        $this->load->view('header');
        $this->load->view('add_categories');
        $this->load->view('footer');
    }
    public function add_categorie(){
        $this->load->model("Categorie_model");
        $data['pname']=$_POST['pname'];
	    $data['cate_list'] = $this->Categorie_model->categories_add($data);
	    echo json_encode($data['cate_list']);
    }
    
    public function add_categorie_pid(){
        $this->load->model("Categorie_model");
        $data['pname']=$_POST['pname'];
        $data['pid']=$_POST['pid'];
	    $data['cate_list_pid'] = $this->Categorie_model->categories_add_pid($data);
	    echo json_encode($data['cate_list_pid']);
    }
    
    public function show_categorie(){
        $this->load->model("Categorie_model");
	    $data['cate_list'] = $this->Categorie_model->show_categories();
	    echo json_encode($data['cate_list']);
    }
    
    public function update_categorie(){
        $this->load->model("Categorie_model");
        $data['sid']=$_POST['sid'];
        $data['pname']=$_POST['pname'];
	    $data['update_list'] = $this->Categorie_model->categories_update($data);
	    echo json_encode($data['update_list']);
    }
    
    public function delete_categorie(){
        $this->load->model("Categorie_model");
        $data['sid']=$_POST['sid'];
	    $data['delete_list'] = $this->Categorie_model->categories_delete($data);
	    echo json_encode($data['delete_list']);
    }
    
    public function sub_categorie(){
        $this->load->model("Categorie_model");
        $data['cate1'] = $_POST['value'];
        $data['result'] = $this->Categorie_model->sub_categorie($data);
        echo json_encode($data['result']);
    }
    
}