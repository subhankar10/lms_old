<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Course_cont extends CI_Controller {
      function __construct() {
        parent::__construct();
        $this->load->database();
        $this->db2 = $this->load->database('serverdb2', TRUE);
        $this->load->helper('url');
        $this->load->helper('form');
        $this->lang->load('basic', $this->config->item('language'));
        $this->load->library("pagination");
        // redirect if not loggedin
        if (!$this->session->userdata('logged_in')) {
            redirect('login');
        }
        $logged_in = $this->session->userdata('logged_in');
        if ($logged_in['base_url'] != base_url()) {
            $this->session->unset_userdata('logged_in');
            redirect('login');
        }
    }
    
     public function new_course() {
        $this->load->model("Course_model");  
        $data['categorie'] = $this->Course_model->choice_categorie();
        $this->load->view('header',$data);
        $this->load->view('courseadd',$data);
        $this->load->view('footer',$data);
     }
     
       public function new_course2() {
            $this->load->model("Course_model");  
            $data['user'] = $this->session->userdata('logged_in')['uid'];
            $data['name']=$_POST['name'];
            $data['course_subtitle']=$_POST['course_subtitle'];
            $data['course_description']=$_POST['course_description'];
            $data['category']=$_POST['category'];
            $data['time']=$_POST['time'];
            // $data['tag']=$_POST['tag'];
            $data['categorie1']=$_POST['categorie1'];
            $data['categorie2']=$_POST['categorie2'];
            $data['course_add1'] = $this->Course_model->course_add1($data);
            $this->load->view('header',$data);
            $this->load->view('courseadd2',$data);
            $this->load->view('footer',$data);
       }
       
       
        public function upload_image($fileName,$filename){
		$config['file_name'] = $filename;
		$config['overwrite'] = TRUE;
		$config['upload_path'] = $_SERVER['DOCUMENT_ROOT'].'/assetsimg/';
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
		$this->load->library('upload', $config);
		$this->upload->initialize($config);
		if($this->upload->do_upload($fileName)){
			return $filename;
		}
	}
	
	
	public function upload_promovideo($file_name,$filename){
		$config['file_name'] = $filename;
		$config['overwrite'] = TRUE;
		$config['upload_path'] = $_SERVER['DOCUMENT_ROOT'].'/promotionalvideo/';
        $config['allowed_types'] = 'mkv|mp4|3gp';
		$this->load->library('upload', $config);
		$this->upload->initialize($config);
		if($this->upload->do_upload($file_name)){
			return $filename;
		}
	}
       
       public function new_course3() {
            $this->load->model("Course_model");
            $data['cou_id'] = $_POST['course_id'];
            $name1 = $_FILES["image"]["name"];
            $videoname = $_FILES["video"]["name"];
            
            $exten = explode('.',$name1)[1];
            $exten1 = explode('.',$videoname)[1];
            
            $data['course_image'] = "image".$data['cou_id'].'.'.$exten;
            $data['promotional_video'] = "video".$data['cou_id'].'.'.$exten1;
            
		    $data['img_name1'] = $this->upload_image('image',$data['course_image']);
		    $data['video_name1'] = $this->upload_promovideo('video',$data['promotional_video']);
		    
		    $data['video_save'] = $this->Course_model->video_save_course3($data);
		    
            $this->load->view('header');
            $this->load->view('courseadd3',$data);
            $this->load->view('footer');
       }
      
     	public function upload_coursevideo($file_name,$filename){
		$config['file_name'] = $filename;
		$config['overwrite'] = TRUE;
		$config['upload_path'] = $_SERVER['DOCUMENT_ROOT'].'/coursevideo';
        $config['allowed_types'] = 'mkv|mp4|3gp|pdf';
		$this->load->library('upload', $config);
		$this->upload->initialize($config);
		if($this->upload->do_upload($file_name)){
		    $this->upload->data();
			return $filename;
		}
	}
     
     public function show_courselist_view(){
          $this->load->model("Course_model");
           $data['cou_id'] = $_POST['course_id'];
            $title = $_POST['alltitledes'];
            $fides = $_POST['allvideodes'];
            $novideo = $_POST['noofvideo'];
            
            $arrtitle = explode(',',$title[0]);
            $arrfides = explode(',',$fides[0]);
            $arrnovideo = explode(',',$novideo[0]);
            
            $dataTotal = $this->uploadImage();
            
            for($i=0;$i<count($arrtitle);$i++){
                $temptitle = $arrtitle[$i];
                $sequence = $i+1;
                $chapterid = $this->Course_model->chapter_add($data['cou_id'],$sequence,$temptitle);
                
                for($j=0;$j<$arrnovideo[$i];$j++){
                    $filedes = $arrfides[0];
                    $storefile = $dataTotal[0];
                    
                    $data['chapter_id'] = $chapterid[0]['id'];
                    $data['course_details_id'] = $data['cou_id'];
                    $data['course_video'] = $storefile;
                    $data['video_description'] = $filedes;
                    
                    $this->Course_model->video_save($data);
                    
                    array_splice($dataTotal,0,1);
                    array_splice($arrfides,0,1);
                }
            }
        $data['path'] = $_SERVER['HTTP_HOST'].'/assetsimg/';
        $data['price']=$_POST['price'];
      $data['video_list'] = $this->Course_model->show_videolist($data);
      $this->load->view('header',$data);
      $this->load->view('courseview',$data);
      $this->load->view('footer',$data);
     }
     
     public function uploadImage() { 
   
      $data = [];
      $count = count($_FILES['allvideo']['name']);
      for($i=0;$i<$count;$i++){
          
          if(end(explode('.',$_FILES['allvideo']['name'][$i]))=='pdf'){
          
        if(!empty($_FILES['allvideo']['name'][$i])){
    
          $_FILES['file']['name'] = $_FILES['allvideo']['name'][$i];
          $_FILES['file']['type'] = $_FILES['allvideo']['name'][$i];
          $_FILES['file']['tmp_name'] = $_FILES['allvideo']['tmp_name'][$i];
          $_FILES['file']['error'] = $_FILES['allvideo']['error'][$i];
          $_FILES['file']['size'] = $_FILES['allvideo']['size'][$i];
        unset($config);
          $config['upload_path'] = $_SERVER['DOCUMENT_ROOT'].'/coursevideo'; 
          $config['allowed_types'] = 'mkv|mp4|3gp|pdf';
        //   $config['max_size'] = '5000';
          $config['file_name'] = 'v='.uniqid().'.'.end(explode('.',$_FILES['file']['name']));
          $this->load->library('upload',$config); 
            $this->upload->initialize($config);
          if($this->upload->do_upload('file')){
            $uploadData = $this->upload->data();
            $filename = $uploadData['file_name'];
   
            $data['totalFiles'][] = $filename;
          }
        }
        
      }else{
          
          if(!empty($_FILES['allvideo']['name'][$i])){
    
          $_FILES['file']['name'] = $_FILES['allvideo']['name'][$i];
          $_FILES['file']['type'] = $_FILES['allvideo']['name'][$i];
          $_FILES['file']['tmp_name'] = $_FILES['allvideo']['tmp_name'][$i];
          $_FILES['file']['error'] = $_FILES['allvideo']['error'][$i];
          $_FILES['file']['size'] = $_FILES['allvideo']['size'][$i];
        unset($config2);
          $config2['upload_path'] = $_SERVER['DOCUMENT_ROOT'].'/coursevideo'; 
          $config2['allowed_types'] = 'mkv|mp4|3gp';
        //   $config['max_size'] = '5000';
          $config2['file_name'] = 'v='.uniqid().'.'.end(explode('.',$_FILES['file']['name']));
          $this->load->library('upload',$config2); 
            $this->upload->initialize($config2);
          if($this->upload->do_upload('file')){
            $uploadData = $this->upload->data();
            $filename = $uploadData['file_name'];
   
            $data['totalFiles'][] = $filename;
          }
        }
          
      }
   
      }
   return $data['totalFiles'];
   }
    
    
     public function show_courselistshow(){
       $this->load->model("Course_model");  
      $data['video_list'] = $this->Course_model->show_teachercourselist();
      $data['path'] = $_SERVER['HTTP_HOST'].'/assetsimg/';
      $this->load->view('header',$data);
      $this->load->view('courseview',$data);
      $this->load->view('footer',$data);
         
     }
     
    public function adminlist(){
         $this->load->model("Course_model"); 
        $data['cou'] = $_GET['course'];
        $data['result'] = $this->Course_model->show_adminlist($data);
        echo 1;
    }
    
    
    
      public function submitvideo(){
         $this->load->model("Course_model"); 
        $data['cou'] = $_GET['view'];
        $data['result'] = $this->Course_model->submitvideo($data);
        echo json_encode($data['result']);
    }
     
     
     public function show_admincourselist(){
       $this->load->model("Course_model"); 
       $data['admin_list'] = $this->Course_model->show_adminlistdata();
       $data['path'] = $_SERVER['HTTP_HOST'].'/assetsimg/';
       $this->load->view('header',$data);
       $this->load->view('admincourseview',$data);
       $this->load->view('footer',$data);
         
     }
     
     
    //   public function show_mainvideoview(){
    //   $this->load->model("Course_model"); 
    //   $data['video_view'] = $this->Course_model->show_mainvideoview();
    //   $data['path'] = $_SERVER['HTTP_HOST'].'/assetsimg/';
    //   $this->load->view('home',$data);
    //  }
     
     
     
     
     
     
     public function show_videoclass_student(){
         
       $this->load->view('header');
       $this->load->view('student_video_course_list');
       $this->load->view('footer');
     }
     
      public function show_textclass_student(){
         
       $this->load->view('header');
       $this->load->view('student_text_course_list');
       $this->load->view('footer');
     }
     
     
      public function my_course(){
        $this->load->model("Course_model");  
        $data['categorie'] = $this->Course_model->choice_categorie();
       $this->load->view('header',$data);
       $this->load->view('my_course');
       $this->load->view('footer');
     }
     
     
   
     
}