<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->database();
        $this->load->helper('url');
        $this->load->model("user_model");
        $this->load->model("account_model");
        $this->load->model("examiner_model");
        $this->load->model("classroom_model");
        $this->config->load("masterdata");
        $this->lang->load('basic', $this->config->item('language'));
        $this->load->library("pagination");
        // redirect if not loggedin
        if (!$this->session->userdata('logged_in')) {
            redirect('login');
        }
        $logged_in = $this->session->userdata('logged_in');
        if ($logged_in['base_url'] != base_url()) {
            $this->session->unset_userdata('logged_in');
            redirect('login');
        }
    }

    public function paginatelinks() {
        $config['full_tag_open'] = '<div class="dataTables_paginate paging_bs_normal pull-right" id="datatable-default_paginate"><ul class="pagination justify-content-end p-4">';
        $config['full_tag_close'] = '</ul></div><!--pagination-->';

        $config['first_link'] = '&laquo; First';
        $config['first_tag_open'] = '<li class="page-item">';
        $config['first_tag_close'] = '</li>';

        $config['last_link'] = 'Last &raquo;';
        $config['last_tag_open'] = '<li class="page-item">';
        $config['last_tag_close'] = '</li>';

        $config['next_link'] = '<span class="page-link">&GT;</span>';
        $config['next_tag_open'] = '<li class="page-item">';
        $config['next_tag_close'] = '</li>';

        $config['prev_link'] = '<span class="page-link">&LT;</span>';
        $config['prev_tag_open'] = '<li class="page-item">';
        $config['prev_tag_close'] = '</li>';

        $config['cur_tag_open'] = '<li class="active"><span class="page-link-active">';
        $config['cur_tag_close'] = '</span></li>';

        $config['num_tag_open'] = '<li class="page-item"><span class="page-link">';
        $config['num_tag_close'] = '</span></li>';
        return $config;
    }

    public function index() {
        $logged_in = $this->session->userdata('logged_in');

        /*$user_p = explode(',', $logged_in['users']);
        if (!in_array('List_all', $user_p)) {
            exit($this->lang->line('permission_denied'));
        }*/


        $data['limit'] = $limit;
        $data['title'] = $this->lang->line('userlist');
        // fetching user list
        //search user
        $search = array();

        $inputname = $this->uri->segment(3) ? $this->uri->segment(3) : "Name";
        $inputphone = $this->uri->segment(4) ? $this->uri->segment(4) : "Phone";
        $inputemail = $this->uri->segment(5) ? $this->uri->segment(5) : "Email";

        $inputname = urldecode($inputname);
        $inputphone = urldecode($inputphone);
        $inputemail = urldecode($inputemail);

        $name = $this->input->get('username') ? $this->input->get('username') : $inputname;
        $phone = $this->input->get('phone') ? $this->input->get('phone') : $inputphone;
        $email = $this->input->get('email') ? $this->input->get('email') : $inputemail;

        $user = array();
        if ($name != "Name")
            $user['username'] = $name;
        if ($phone != "Phone")
            $user['phone'] = $phone;
        if ($email != "Email")
            $user['email'] = $email;

        //pagination links
        $config = array();
        $config = $this->paginatelinks();
        $config["base_url"] = site_url("user/index/$name/$phone/$email");
        $cnt_flg = "1";
        $config["total_rows"] = $this->user_model->user_list($config["per_page"], $start, $cnt_flg = 1, $user);
        $config["per_page"] = 10;
        $config["uri_segment"] = 6;
        $choice = $config["total_rows"] / $config["per_page"];
        $config["num_links"] = round($choice);
        $this->pagination->initialize($config);
        $page = ($this->uri->segment(6)) ? $this->uri->segment(6) : 0;
        $start = $page;
        $data["links"] = $this->pagination->create_links();
//        $data['exam_category'] = $this->config->item('exam_category');
        $data['classList'] = $this->classroom_model->dataListingKeyvalue("class", "id", "name");
        //pagination links
        $data["result"] = $this->user_model->user_list($config["per_page"], $start, $cnt_flg = "", $user);
        $data['user'] = $user;
        $data['logged_in'] = $logged_in;
//        $data['role_menu'] = $this->config->item('role_menu')['applicant'];
       
        $this->load->view('header', $data);
        $this->load->view('user_list', $data);
        $this->load->view('footer', $data);
    }

    public function new_user($uid = "") {
        $logged_in = $this->session->userdata('logged_in');
        $user_p = explode(',', $logged_in['users']);
//        print "1111";exit();
//        if (!in_array('Add', $user_p)) {
//            exit($this->lang->line('permission_denied'));
//        }
        
        if ($uid) {
            $data = array();
            $data['result'] = $this->user_model->get_studentdetails($uid);
        }
        
        $data['title'] = $this->lang->line('add_new') . ' ' . "Student";
        // fetching group list
        $data['group_list'] = $this->user_model->group_list();
        $data['account_type'] = $this->account_model->account_list(0);
        $data['student_userrole'] = $this->config->item('student_userrole');
        $data['classList'] = $this->classroom_model->dataListingKeyvalue("class", "id", "name");
        $data['city_list'] = $this->examiner_model->dataListingKeyvalue("kams_city", "id_city", "city_name");
        $this->load->view('header', $data);
        $this->load->view('user/new_user', $data);
        $this->load->view('footer', $data);
    }
    
    
    
     public function insert_user() {
        $logged_in = $this->session->userdata('logged_in');
        $user_p = explode(',', $logged_in['users']);
//        if (!in_array('Add', $user_p)) {
//            exit($this->lang->line('permission_denied'));
//        }
        if ($this->user_model->insert_user()) {
            $this->session->set_flashdata('message', "<div class='alert alert-success'>" . $this->lang->line('data_added_successfully') . " </div>");
        } else {
            $this->session->set_flashdata('message', "<div class='alert alert-danger'>" . $this->lang->line('error_to_add_data') . " </div>");
        }
        redirect('user/');
//        $email = $this->input->post('email');
//        $this->load->library('form_validation');
//        $this->form_validation->set_rules($email, 'Email', 'required|is_unique[kams_users.email]');
//        if ($this->form_validation->run() == FALSE) {
//            echo "12424";exit();
//            $this->session->set_flashdata('message', "<div class='alert alert-danger'>" . validation_errors() . " </div>");
//            redirect('user/new_user/');
//        } else {
//            
//        }
    }

   

    public function changeVerificationStatus() {
        $uid = $this->input->post('uid');
        $status_val = $this->input->post('status_val');
        $tbl_name = $this->input->post('tbl_name');
        $update_field = $this->input->post('update_field');
        $userdata_status = array('' . $update_field . '' => $status_val);
        $this->db->where('uid', $uid);
        $result = $this->db->update($tbl_name, $userdata_status);
        echo "success";
        exit();
    }

    public function remove_user() {
        $logged_in = $this->session->userdata('logged_in');
        $user_p = explode(',', $logged_in['users']);
        if (!in_array('Remove', $user_p)) {
            exit($this->lang->line('permission_denied'));
        }
//        if ($uid == '1') {
//            exit($this->lang->line('permission_denied'));
//        }
        $uid = $this->input->get('id_applicant');
        $this->db->where('uid', $uid);
        if ($this->db->delete('kams_users')) {
            $this->session->set_flashdata('message', "<div class='alert alert-success'>Record deleted successfully!</div>");
        } else {
            $this->session->set_flashdata('message', "<div class='alert alert-danger'>Error in deletion!</div>");
        }
        redirect('user/');
    }

    public function edit_user_fill_custom($uid, $rid) {
        if ($this->input->post('custom')) {

            foreach ($_POST['custom'] as $ck => $cv) {
                if ($cv != '') {
                    $this->db->where('uid', $uid);
                    $this->db->where('field_id', $ck);
                    $this->db->delete('kams_users_custom');


                    $kams_users_custom = array(
                        'field_id' => $ck,
                        'uid' => $uid,
                        'field_values' => $cv
                    );
                    $this->db->insert('kams_users_custom', $kams_users_custom);
                }
            }
            redirect('result/view_result/' . $rid);
        }
        $data['uid'] = $uid;
        $data['rid'] = $rid;
        $data['title'] = $this->lang->line('fill_custom_msg');
        // fetching user
        $data['result'] = $this->user_model->get_user($uid);
        $data['custom_form_user'] = $this->user_model->custom_form_user($uid);

        $data['custom_form'] = $this->user_model->custom_form('Result');

        $this->load->view('header', $data);
        $this->load->view('custom_form', $data);

        $this->load->view('footer', $data);
    }

    public function edit_user($uid) {

        $logged_in = $this->session->userdata('logged_in');
        $user_p = explode(',', $logged_in['users']);

        if (!in_array('Edit', $user_p)) {
            if (in_array('Myaccount', $user_p)) {
                $uid = $logged_in['uid'];
            } else {
                exit($this->lang->line('permission_denied'));
            }
        }



        $data['uid'] = $uid;
        $data['title'] = $this->lang->line('edit') . ' ' . $this->lang->line('user');
        // fetching user
        $data['result'] = $this->user_model->get_user($uid);
        $data['custom_form_user'] = $this->user_model->custom_form_user($uid);

        $data['custom_form'] = $this->user_model->custom_form('All');
        $this->load->model("payment_model");
        $data['payment_history'] = $this->payment_model->get_payment_history($uid);
        // fetching group list
        $data['group_list'] = $this->user_model->group_list();
        $data['account_type'] = $this->account_model->account_list(0);
        $this->load->view('header', $data);
        if ($logged_in['su'] == '1') {
            $this->load->view('edit_user', $data);
        } else {
            $this->load->view('myaccount', $data);
        }
        $this->load->view('footer', $data);
    }

    public function update_user($uid) {


        $logged_in = $this->session->userdata('logged_in');

//        if ($logged_in['su'] != '1') {
//            $uid = $logged_in['uid'];
//        }
        $this->load->library('form_validation');
        $this->form_validation->set_rules('email', 'Email', 'required');
        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('message', "<div class='alert alert-danger'>" . validation_errors() . " </div>");
            redirect('user/new_user/' . $uid);
        } else {
            if ($this->user_model->update_user($uid)) {
                $this->session->set_flashdata('message', "<div class='alert alert-success'>" . $this->lang->line('data_updated_successfully') . " </div>");
            } else {
                $this->session->set_flashdata('message', "<div class='alert alert-danger'>" . $this->lang->line('error_to_update_data') . " </div>");
            }
            redirect('user/edit_user/' . $uid);
        }
    }

    public function group_list() {

        $logged_in = $this->session->userdata('logged_in');
        $setting_p = explode(',', $logged_in['setting']);
        if (!in_array('All', $setting_p)) {
            exit($this->lang->line('permission_denied'));
        }
        // fetching group list
        $data['group_list'] = $this->user_model->group_list();
        $data['title'] = $this->lang->line('group_list');
        $this->load->view('header', $data);
        $this->load->view('group_list', $data);
        $this->load->view('footer', $data);
    }

    public function add_new_group() {

        $logged_in = $this->session->userdata('logged_in');
        $setting_p = explode(',', $logged_in['setting']);
        if (!in_array('All', $setting_p)) {
            exit($this->lang->line('permission_denied'));
        }



        if ($this->input->post('group_name')) {
            if ($this->user_model->insert_group()) {
                $this->session->set_flashdata('message', "<div class='alert alert-success'>" . $this->lang->line('data_added_successfully') . " </div>");
            } else {
                $this->session->set_flashdata('message', "<div class='alert alert-danger'>" . $this->lang->line('error_to_update_data') . " </div>");
            }
            redirect('user/group_list');
        }
        // fetching group list
        $data['title'] = $this->lang->line('add_group');
        $this->load->view('header', $data);
        $this->load->view('add_group', $data);
        $this->load->view('footer', $data);
    }

    public function edit_group($gid) {
        $logged_in = $this->session->userdata('logged_in');
        $setting_p = explode(',', $logged_in['setting']);
        if (!in_array('All', $setting_p)) {
            exit($this->lang->line('permission_denied'));
        }

        if ($this->input->post('group_name')) {
            if ($this->user_model->update_group($gid)) {
                $this->session->set_flashdata('message', "<div class='alert alert-success'>" . $this->lang->line('data_updated_successfully') . " </div>");
            } else {
                $this->session->set_flashdata('message', "<div class='alert alert-danger'>" . $this->lang->line('error_to_update_data') . " </div>");
            }
            redirect('user/group_list');
        }
        // fetching group list
        $data['group'] = $this->user_model->get_group($gid);
        $data['gid'] = $gid;
        $data['title'] = $this->lang->line('edit_group');
        $this->load->view('header', $data);
        $this->load->view('edit_group', $data);
        $this->load->view('footer', $data);
    }

    public function upgid($gid) {
        $logged_in = $this->session->userdata('logged_in');
        $uid = $logged_in['uid'];
        $user = $this->user_model->get_user($uid);
        $gids = explode(',', $user['gid']);
        if (!in_array($gid, $gids)) {
            $group = $this->user_model->get_group($gid);
            if ($group['price'] != '0') {
                redirect('payment_gateway_2/subscribe/' . $gid . '/' . $logged_in['uid']);
            } else {
                $subscription_expired = time() + (365 * 20 * 24 * 60 * 60);
                $gids[] = $gid;
            }

            $userdata = array(
                'gid' => implode(',', $gids),
                'subscription_expired' => $subscription_expired
            );

            $this->db->where('uid', $uid);
            $this->db->update('kams_users', $userdata);
            $this->session->set_flashdata('message', "<div class='alert alert-success'>" . $this->lang->line('group_updated_successfully') . " </div>");
        } else {
            $this->session->set_flashdata('message', "<div class='alert alert-success'>You already subscribed this group! </div>");
        }

        redirect('user/edit_user/' . $logged_in['uid']);
    }

    public function switch_group() {

        $logged_in = $this->session->userdata('logged_in');
        if (!$this->config->item('allow_switch_group')) {
            redirect('user/edit_user/' . $logged_in['uid']);
        }
        $data['title'] = $this->lang->line('select_package');
        // fetching group list
        $data['group_list'] = $this->user_model->group_list();
        $this->load->view('header', $data);
        $this->load->view('change_group', $data);
        $this->load->view('footer', $data);
    }

    public function pre_remove_group($gid) {
        $data['gid'] = $gid;
        // fetching group list
        $data['group_list'] = $this->user_model->group_list();
        $data['title'] = $this->lang->line('remove_group');
        $this->load->view('header', $data);
        $this->load->view('pre_remove_group', $data);
        $this->load->view('footer', $data);
    }

    public function insert_group() {


        $logged_in = $this->session->userdata('logged_in');
        $setting_p = explode(',', $logged_in['setting']);
        if (!in_array('All', $setting_p)) {
            exit($this->lang->line('permission_denied'));
        }

        if ($this->user_model->insert_group()) {
            $this->session->set_flashdata('message', "<div class='alert alert-success'>" . $this->lang->line('data_added_successfully') . " </div>");
        } else {
            $this->session->set_flashdata('message', "<div class='alert alert-danger'>" . $this->lang->line('error_to_add_data') . " </div>");
        }
        redirect('user/group_list/');
    }

    public function update_group($gid) {


        $logged_in = $this->session->userdata('logged_in');
        $setting_p = explode(',', $logged_in['setting']);
        if (!in_array('All', $setting_p)) {
            exit($this->lang->line('permission_denied'));
        }

        if ($this->user_model->update_group($gid)) {
            echo "<div class='alert alert-success'>" . $this->lang->line('data_updated_successfully') . " </div>";
        } else {
            echo "<div class='alert alert-danger'>" . $this->lang->line('error_to_update_data') . " </div>";
        }
    }

    function get_expiry($gid) {

        echo $this->user_model->get_expiry($gid);
    }

    public function remove_group($gid) {

        $logged_in = $this->session->userdata('logged_in');
        $acp = explode(',', $logged_in['setting']);
        if (!in_array('All', $acp)) {
            exit($this->lang->line('permission_denied'));
        }

        $mgid = $this->input->post('mgid');
        $this->db->query(" update kams_users set gid='$mgid' where gid='$gid' ");



        if ($this->user_model->remove_group($gid)) {
            $this->session->set_flashdata('message', "<div class='alert alert-success'>" . $this->lang->line('removed_successfully') . " </div>");
        } else {
            $this->session->set_flashdata('message', "<div class='alert alert-danger'>" . $this->lang->line('error_to_remove') . " </div>");
        }
        redirect('user/group_list');
    }

    function remove_custom($field_id) {
        $logged_in = $this->session->userdata('logged_in');
        $acp = explode(',', $logged_in['setting']);
        if (!in_array('All', $acp)) {
            exit($this->lang->line('permission_denied'));
        }
        $this->user_model->remove_custom($field_id);
        $this->session->set_flashdata('message', "<div class='alert alert-danger'>" . $this->lang->line('removed_successfully') . " </div>");

        redirect('user/custom_fields');
    }

    function custom_fields() {
        $logged_in = $this->session->userdata('logged_in');
        $acp = explode(',', $logged_in['setting']);
        if (!in_array('All', $acp)) {
            exit($this->lang->line('permission_denied'));
        }

        if ($this->input->post()) {
            $this->user_model->insert_custom();


            $this->session->set_flashdata('message', "<div class='alert alert-success'>" . $this->lang->line('data_added_successfully') . " </div>");

            redirect('user/custom_fields');
        }

        $data['custom_fields_list'] = $this->user_model->custom_fields_list();
        $data['title'] = $this->lang->line('custom_forms');
        $this->load->view('header', $data);
        $this->load->view('custom_fields_list', $data);
        $this->load->view('footer', $data);
    }

    function edit_custom($field_id) {
        $logged_in = $this->session->userdata('logged_in');
        $acp = explode(',', $logged_in['setting']);
        if (!in_array('All', $acp)) {
            exit($this->lang->line('permission_denied'));
        }

        if ($this->input->post()) {
            $this->user_model->update_custom($field_id);


            $this->session->set_flashdata('message', "<div class='alert alert-success'>" . $this->lang->line('data_updated_successfully') . " </div>");

            redirect('user/custom_fields');
        }

        $data['custom'] = $this->user_model->get_custom($field_id);

        $data['title'] = $this->lang->line('custom_forms');
        $this->load->view('header', $data);
        $this->load->view('edit_custom', $data);
        $this->load->view('footer', $data);
    }

    function logout() {

        $this->session->unset_userdata('logged_in');
        if ($this->session->userdata('logged_in_raw')) {
            $this->session->unset_userdata('logged_in_raw');
        }
        redirect('login');
    }
    
    public function changeStatus() {
        $fld_name = $this->input->post('fld_name');
        $fld_val = $this->input->post('id');
        $tbl = $this->input->post('tbl_name');
        $user = array();
        $user['user_status'] = $this->input->post('status_val');
        
        $this->user_model->changeStatus($tbl, $user, $fld_name, $fld_val);
    }

}