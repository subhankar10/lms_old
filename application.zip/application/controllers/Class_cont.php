<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Class_cont extends CI_Controller {
      function __construct() {
        parent::__construct();
        $this->load->database();
        $this->db2 = $this->load->database('serverdb2', TRUE);
        $this->load->helper('url');
        $this->load->helper('form');
        $this->lang->load('basic', $this->config->item('language'));
        $this->load->library("pagination");
        // redirect if not loggedin
        if (!$this->session->userdata('logged_in')) {
            redirect('login');
        }
        $logged_in = $this->session->userdata('logged_in');
        if ($logged_in['base_url'] != base_url()) {
            $this->session->unset_userdata('logged_in');
            redirect('login');
        }
    }
    
    public function addclass() {
        $this->load->view('header');
        $this->load->view('addclass');
        $this->load->view('footer');
     }
     
     public function insert_class(){
         $this->load->model('Class_model');
         $data['c_name'] = $_POST['name'];
         $data['c_description'] = $_POST['description'];
         $data['add_date'] = date("y-m-d H:i:s");
         $data['status'] = 1;
         $data['result'] = $this->Class_model->insert_class($data);
         $data['class_list'] = $this->Class_model->retrieve_class();
         $this->load->view('header',$data);
        $this->load->view('classlist',$data);
        $this->load->view('footer',$data);
     }
     
     public function classlist() {
        $this->load->model('Class_model');
        $data['class_list'] = $this->Class_model->retrieve_class();
        $this->load->view('header',$data);
        $this->load->view('classlist',$data);
        $this->load->view('footer',$data);
     }
}