<?php
$sq_base_url = 'https://www.studieson.com/';
$sq_hostname = 'localhost';
$sq_dbname='studieso_elpt';
//$sq_dbname = 'managementpanel';
$sq_dbusername = 'studieso_elpt';
$sq_dbpassword = 'p455w0rd';
//$sq_dbpassword = 'skyco@dbpass';